import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 4: OPERATOR SOBEL
# ============================================
print("=" * 50)
print("MODUL 4: DETEKSI TEPI DENGAN SOBEL")
print("=" * 50)

# Baca gambar grayscale dengan Smart Path (Foto kamu)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# SOBEL X (Deteksi tepi vertikal)
# ============================================
print("\n[SOBEL X - Deteksi Tepi Vertikal]")
sobel_x = cv2.Sobel(citra, cv2.CV_64F, 1, 0, ksize=3)
sobel_x_abs = np.abs(sobel_x)
sobel_x_abs = np.clip(sobel_x_abs, 0, 255).astype(np.uint8)

# ============================================
# SOBEL Y (Deteksi tepi horizontal)
# ============================================
print("\n[SOBEL Y - Deteksi Tepi Horizontal]")
sobel_y = cv2.Sobel(citra, cv2.CV_64F, 0, 1, ksize=3)
sobel_y_abs = np.abs(sobel_y)
sobel_y_abs = np.clip(sobel_y_abs, 0, 255).astype(np.uint8)

# ============================================
# GABUNGAN SOBEL (Magnitude)
# ============================================
print("\n[GABUNGAN SOBEL X & Y]")
sobel_magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
sobel_magnitude = np.clip(sobel_magnitude, 0, 255).astype(np.uint8)

# ============================================
# SOBEL DENGAN UKURAN KERNEL BERBEDA
# ============================================
print("\n[EKSPLORASI UKURAN KERNEL SOBEL]")
ukuran_kernel = [3, 5, 7, 9]
sobel_variasi = []
for k in ukuran_kernel:
    sx = cv2.Sobel(citra, cv2.CV_64F, 1, 0, ksize=k)
    sy = cv2.Sobel(citra, cv2.CV_64F, 0, 1, ksize=k)
    mag = np.sqrt(sx**2 + sy**2)
    mag = np.clip(mag, 0, 255).astype(np.uint8)
    sobel_variasi.append(mag)

# ============================================
# TAMPILKAN HASIL (Menggunakan Grid 2x4 agar tidak error)
# ============================================
plt.figure(figsize=(18, 9))

# Original
plt.subplot(2, 4, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

# Sobel X
plt.subplot(2, 4, 2)
plt.imshow(sobel_x_abs, cmap='gray')
plt.title("Sobel X (Tepi Vertikal)")
plt.axis('off')

# Sobel Y
plt.subplot(2, 4, 3)
plt.imshow(sobel_y_abs, cmap='gray')
plt.title("Sobel Y (Tepi Horizontal)")
plt.axis('off')

# Sobel Magnitude
plt.subplot(2, 4, 4)
plt.imshow(sobel_magnitude, cmap='gray')
plt.title("Sobel Magnitude (Gabungan)")
plt.axis('off')

# Variasi kernel size (Mengisi baris kedua: indeks 5, 6, 7, 8)
for i, (k, mag) in enumerate(zip(ukuran_kernel, sobel_variasi)):
    plt.subplot(2, 4, 5 + i)
    plt.imshow(mag, cmap='gray')
    plt.title(f"Sobel Kernel {k}x{k}")
    plt.axis('off')

plt.suptitle("Operator Sobel: Deteksi Tepi tingkat Lanjut", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# ANALISIS ARAH TEPI
# ============================================
print("\n[ANALISIS ARAH TEPI]")
print("Dari gradien Gx dan Gy, kita bisa menghitung ARAH tepi:")
print("Sudut = arctan(Gy / Gx)")

# Hitung sudut (dalam derajat)
sudut = np.arctan2(sobel_y, sobel_x) * 180 / np.pi
sudut = np.where(sudut < 0, sudut + 180, sudut) # Normalisasi 0-180 derajat

# Visualisasi arah tepi (hanya untuk tepi yang kuat)
threshold = 50
arah_tepi = sudut.copy()
arah_tepi[sobel_magnitude < threshold] = 0 # Abaikan area datar (bukan tepi)

plt.figure(figsize=(14, 5))

plt.subplot(1, 2, 1)
plt.imshow(sobel_magnitude, cmap='gray')
plt.title("Kekuatan Tepi (Magnitude)")
plt.axis('off')

plt.subplot(1, 2, 2)
# BUG FIX: Menggunakan objek im agar colobar tidak memicu RuntimeError
im = plt.imshow(arah_tepi, cmap='hsv')
plt.title("Arah Tepi (Warna berbeda = sudut berbeda)")
plt.axis('off')
plt.colorbar(im, label='Sudut (derajat)')

plt.suptitle("Informasi Arah Tepi dari Operator Sobel", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN SOBEL]")
print("-" * 40)
print("✅ Sobel X: mendeteksi tepi VERTIKAL (perubahan horizontal)")
print("✅ Sobel Y: mendeteksi tepi HORIZONTAL (perubahan vertikal)")
print("✅ Magnitude: kekuatan tepi total (tidak peduli arah)")
print("✅ Sudut: informasi arah tepi (0° = horizontal, 90° = vertikal)")
print("\nUkuran kernel: lebih besar = tepi lebih tebal tapi kurang presisi")
print("\n✅ Modul 4 - Bagian 2 selesai!")