import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 4: OPERATOR LAPLACIAN
# ============================================
print("=" * 50)
print("MODUL 4: DETEKSI TEPI DENGAN LAPLACIAN")
print("=" * 50)

# Baca gambar menggunakan Smart Path (Foto kamu)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# APA ITU LAPLACIAN?
# ============================================
print("\n[LAPLACIAN - Turunan Kedua]")
print("Jika Sobel adalah turunan PERTAMA (gradien),")
print("maka Laplacian adalah turunan KEDUA")
print("\nKernel Laplacian yang umum:")
print("Variant 1: [[0, -1, 0], [-1, 4, -1], [0, -1, 0]]")
print("Variant 2: [[-1, -1, -1], [-1, 8, -1], [-1, -1, -1]]")

# ============================================
# LAPLACIAN DENGAN OPENCV
# ============================================
print("\n[MENERAPKAN LAPLACIAN]")
# Laplacian standar (kernel 3x3)
laplacian = cv2.Laplacian(citra, cv2.CV_64F, ksize=3)
laplacian_abs = np.abs(laplacian)
laplacian_abs = np.clip(laplacian_abs, 0, 255).astype(np.uint8)

# Laplacian dengan kernel lebih besar
laplacian_5 = cv2.Laplacian(citra, cv2.CV_64F, ksize=5)
laplacian_5_abs = np.abs(laplacian_5)
laplacian_5_abs = np.clip(laplacian_5_abs, 0, 255).astype(np.uint8)

# ============================================
# MEMBUAT KERNEL LAPLACIAN SENDIRI
# ============================================
print("\n[MEMBUAT KERNEL LAPLACIAN CUSTOM]")
# Laplacian variant 1 (4-tetangga)
laplacian_kernel1 = np.array([
    [ 0, -1,  0],
    [-1,  4, -1],
    [ 0, -1,  0]
], dtype=np.float32)

# Laplacian variant 2 (8-tetangga, lebih kuat)
laplacian_kernel2 = np.array([
    [-1, -1, -1],
    [-1,  8, -1],
    [-1, -1, -1]
], dtype=np.float32)

# Laplacian dengan bobot diagonal
laplacian_kernel3 = np.array([
    [ 1, -2,  1],
    [-2,  4, -2],
    [ 1, -2,  1]
], dtype=np.float32)

hasil_laplacian1 = cv2.filter2D(citra.astype(np.float32), -1, laplacian_kernel1)
hasil_laplacian1 = np.abs(hasil_laplacian1)
hasil_laplacian1 = np.clip(hasil_laplacian1, 0, 255).astype(np.uint8)

hasil_laplacian2 = cv2.filter2D(citra.astype(np.float32), -1, laplacian_kernel2)
hasil_laplacian2 = np.abs(hasil_laplacian2)
hasil_laplacian2 = np.clip(hasil_laplacian2, 0, 255).astype(np.uint8)

hasil_laplacian3 = cv2.filter2D(citra.astype(np.float32), -1, laplacian_kernel3)
hasil_laplacian3 = np.abs(hasil_laplacian3)
hasil_laplacian3 = np.clip(hasil_laplacian3, 0, 255).astype(np.uint8)

# ============================================
# TAMPILKAN SEMUA HASIL (Jendela 1)
# ============================================
plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(laplacian_abs, cmap='gray')
plt.title("Laplacian (OpenCV, ksize=3)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(laplacian_5_abs, cmap='gray')
plt.title("Laplacian (OpenCV, ksize=5)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(hasil_laplacian1, cmap='gray')
plt.title("Laplacian Custom 1\n(4-tetangga)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(hasil_laplacian2, cmap='gray')
plt.title("Laplacian Custom 2\n(8-tetangga, lebih kuat)")
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(hasil_laplacian3, cmap='gray')
plt.title("Laplacian Custom 3\n(Dengan diagonal)")
plt.axis('off')

plt.suptitle("Perbandingan Operator Laplacian", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# PERBANDINGAN SOBEL vs LAPLACIAN (Jendela 2)
# ============================================
print("\n[PERBANDINGAN SOBEL vs LAPLACIAN]")

# Hitung Sobel Magnitude sebagai pembanding
sobel_x = cv2.Sobel(citra, cv2.CV_64F, 1, 0, ksize=3)
sobel_y = cv2.Sobel(citra, cv2.CV_64F, 0, 1, ksize=3)
sobel_mag = np.sqrt(sobel_x**2 + sobel_y**2)
sobel_mag = np.clip(sobel_mag, 0, 255).astype(np.uint8)

# Ambil sampel satu baris horizontal di tengah gambar untuk dianalisis profilnya
baris_ke = citra.shape[0] // 2
intensitas_asli = citra[baris_ke, :]
intensitas_sobel = sobel_mag[baris_ke, :]
intensitas_laplacian = laplacian_abs[baris_ke, :]

plt.figure(figsize=(15, 10))

# Gambar hasil perbandingan peta tepi
plt.subplot(2, 2, 1)
plt.imshow(sobel_mag, cmap='gray')
plt.title("Sobel (Magnitude)")
plt.axis('off')

plt.subplot(2, 2, 2)
plt.imshow(laplacian_abs, cmap='gray')
plt.title("Laplacian (OpenCV)")
plt.axis('off')

# Plot profil grafik intensitas baris tengah
plt.subplot(2, 2, 3)
plt.plot(intensitas_asli, 'k-', linewidth=1, label='Original')
plt.plot(intensitas_sobel, 'r-', linewidth=1, label='Sobel')
plt.title("Profil Intensitas (Baris Tengah) - Sobel")
plt.xlabel("Kolom")
plt.ylabel("Intensitas")
plt.legend()
plt.grid(True, alpha=0.3)

plt.subplot(2, 2, 4)
plt.plot(intensitas_asli, 'k-', linewidth=1, label='Original')
plt.plot(intensitas_sobel, 'b-', linewidth=1, label='Laplacian')
plt.title("Profil Intensitas (Baris Tengah) - Laplacian")
plt.xlabel("Kolom")
plt.ylabel("Intensitas")
plt.legend()
plt.grid(True, alpha=0.3)

plt.suptitle("Perbandingan Sinyal Teoretis: Sobel vs Laplacian", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[PERBANDINGAN SUMMARY]")
print("-" * 40)
print("SOBEL:")
print(" - Mendeteksi tepi berdasarkan arah (Gx dan Gy gabungan).")
print(" - Memberikan respon puncak (peak) tepat di tengah lereng perubahan warna.")
print(" - Lebih kebal terhadap noise bintik.")
print("\nLAPLACIAN:")
print(" - Mendeteksi tepi tanpa arah (isotropik), langsung dalam satu matriks.")
print(" - Memberikan efek 'zero-crossing' (lompatan ekstrem naik-turun di batas tepi).")
print(" - Sangat sensitif terhadap noise halus.")
print(" - Mampu menghasilkan garis tepi sketsa yang jauh lebih tipis dan tajam.")
print("\n✅ Modul 4 - Bagian 3 selesai!")