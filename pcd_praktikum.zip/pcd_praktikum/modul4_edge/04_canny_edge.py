import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 4: CANNY EDGE DETECTION
# ============================================
print("=" * 50)
print("MODUL 4: CANNY EDGE DETECTION")
print("=" * 50)

# Baca gambar menggunakan Smart Path (Foto kamu)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

print("Canny adalah metode deteksi tepi TERBAIK dan TERPOPULER")
print("\nTahapan internal Algoritma Canny:")
print("1. Gaussian Blur (Menghilangkan noise mikro)")
print("2. Hitung Magnitudo & Arah Gradien (Menggunakan konsep Sobel)")
print("3. Non-Maximum Suppression (Menipiskan garis tepi hingga setebal 1 piksel)")
print("4. Hysteresis Thresholding (Menyambungkan garis putus-putus berdasarkan batas)")

# ============================================
# APLIKASI CANNY DENGAN BERBAGAI PARAMETER
# ============================================
print("\n[EKSPLORASI PARAMETER CANNY]")
print("Parameter: threshold1 (lower) dan threshold2 (upper)")

# Variasi pasangan threshold (batas bawah, batas atas)
thresholds = [
    (30, 90),    # Rendah (banyak menangkap tepi halus)
    (50, 150),   # Sedang (Rekomendasi default)
    (100, 200),  # Tinggi (Hanya mengambil tepi yang sangat kuat)
    (150, 250),  # Sangat tinggi (Hanya tepi struktural utama)
]

canny_results = []
for th1, th2 in thresholds:
    hasil = cv2.Canny(citra, th1, th2)
    canny_results.append(hasil)

# ============================================
# PENGARUH BLUR SEBELUM CANNY
# ============================================
print("\n[PENGARUH BLUR SEBELUM CANNY]")
citra_blur_ringan = cv2.GaussianBlur(citra, (3, 3), 0)
citra_blur_sedang = cv2.GaussianBlur(citra, (5, 5), 0)
citra_blur_kuat = cv2.GaussianBlur(citra, (9, 9), 0)

canny_tanpa_blur = cv2.Canny(citra, 50, 150)
canny_blur_ringan = cv2.Canny(citra_blur_ringan, 50, 150)
canny_blur_sedang = cv2.Canny(citra_blur_sedang, 50, 150)
canny_blur_kuat = cv2.Canny(citra_blur_kuat, 50, 150)

# ============================================
# TAMPILKAN HASIL VARIASI THRESHOLD (Jendela 1)
# ============================================
plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

for i, (hasil, (th1, th2)) in enumerate(zip(canny_results, thresholds), 2):
    plt.subplot(2, 3, i)
    plt.imshow(hasil, cmap='gray')
    plt.title(f"Canny (th1={th1}, th2={th2})")
    plt.axis('off')

plt.suptitle("Pengaruh Nilai Hysteresis Threshold pada Canny Edge Detection", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# TAMPILKAN HASIL VARIASI BLUR (Jendela 2)
# ============================================
plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(canny_tanpa_blur, cmap='gray')
plt.title("Canny (Tanpa Blur)\n(Noise terdeteksi sebagai tepi)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(canny_blur_ringan, cmap='gray')
plt.title("Canny (Blur 3x3)\n(Noise berkurang)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(canny_blur_sedang, cmap='gray')
plt.title("Canny (Blur 5x5)\n(Hasil optimal & bersih)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(canny_blur_kuat, cmap='gray')
plt.title("Canny (Blur 9x9)\n(Tepi hilang, terlalu halus)")
plt.axis('off')

plt.suptitle("Pengaruh Tahap Gaussian Blur Sebelum Canny", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# CANNY DENGAN APLIKASI REAL (Jendela 3)
# ============================================
print("\n[CANNY UNTUK APLIKASI NYATA]")

# Buat gambar dengan noise artifisial pasir (High ISO Simulation)
noise = np.random.randint(-40, 40, citra.shape, dtype=np.int16)
citra_noise = np.clip(citra.astype(np.int16) + noise, 0, 255).astype(np.uint8)

# Canny dengan pre-processing optimal
blur_optimal = cv2.GaussianBlur(citra_noise, (5, 5), 0)
canny_optimal = cv2.Canny(blur_optimal, 50, 150)

plt.figure(figsize=(12, 8))

plt.subplot(2, 2, 1)
plt.imshow(citra_noise, cmap='gray')
plt.title("Gambar Asli + Noise Pasir")
plt.axis('off')

plt.subplot(2, 2, 2)
plt.imshow(cv2.Canny(citra_noise, 50, 150), cmap='gray')
plt.title("Canny Langsung (Tanpa Blur)\n(Gagal! Garis wajah tertutup noise)")
plt.axis('off')

plt.subplot(2, 2, 3)
plt.imshow(blur_optimal, cmap='gray')
plt.title("Proses Denosing (Gaussian Blur 5x5)")
plt.axis('off')

plt.subplot(2, 2, 4)
plt.imshow(canny_optimal, cmap='gray')
plt.title("Canny Akhir\n(Sketsa bersih sempurna!)")
plt.axis('off')

plt.suptitle("Praktik Terbaik: Alur Pipeline Pre-processing Canny", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[PANDUAN PARAMETER CANNY]")
print("-" * 40)
print("Untuk gambar bersih            : th1=50, th2=150")
print("Untuk gambar banyak noise/kasar: th1=100, th2=200 (Batas diperketat)")
print("Untuk mengambil detail tipis  : th1=30, th2=90 (Batas diperlonggar)")
print("\nRasio th2 : th1 sekitar 2:1 hingga 3:1 umumnya adalah rasio optimal.")
print("\n✅ Modul 4 - Bagian 4 selesai!")