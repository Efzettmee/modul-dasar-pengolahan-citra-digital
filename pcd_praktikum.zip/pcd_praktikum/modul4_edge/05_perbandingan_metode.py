import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 4: PERBANDINGAN SEMUA METODE
# ============================================
print("=" * 50)
print("MODUL 4: PERBANDINGAN METODE DETEKSI TEPI")
print("=" * 50)

# Baca gambar menggunakan Smart Path (Foto kamu)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# Pre-processing: blur ringan untuk mengurangi noise mikro
citra_pre = cv2.GaussianBlur(citra, (3, 3), 0)

# ============================================
# SEMUA METODE DETEKSI TEPI
# ============================================
print("\n[MENERAPKAN BERBAGAI METODE]")

# 1. Sobel
sobel_x = cv2.Sobel(citra_pre, cv2.CV_64F, 1, 0, ksize=3)
sobel_y = cv2.Sobel(citra_pre, cv2.CV_64F, 0, 1, ksize=3)
sobel = np.sqrt(sobel_x**2 + sobel_y**2)
sobel = np.clip(sobel, 0, 255).astype(np.uint8)

# 2. Laplacian
laplacian = cv2.Laplacian(citra_pre, cv2.CV_64F, ksize=3)
laplacian = np.abs(laplacian)
laplacian = np.clip(laplacian, 0, 255).astype(np.uint8)

# 3. Canny (default)
canny_default = cv2.Canny(citra_pre, 50, 150)

# 4. Canny (aggressive - lebih banyak tepi)
canny_aggressive = cv2.Canny(citra_pre, 30, 90)

# 5. Canny (conservative - hanya tepi kuat)
canny_conservative = cv2.Canny(citra_pre, 100, 200)

# 6. Roberts Cross (Pencarian Gradien Diagonal Sederhana)
roberts_kernel_x = np.array([[1, 0], [0, -1]], dtype=np.float32)
roberts_kernel_y = np.array([[0, 1], [-1, 0]], dtype=np.float32)
roberts_x = cv2.filter2D(citra_pre.astype(np.float32), -1, roberts_kernel_x)
roberts_y = cv2.filter2D(citra_pre.astype(np.float32), -1, roberts_kernel_y)
roberts = np.sqrt(roberts_x**2 + roberts_y**2)
roberts = np.clip(roberts, 0, 255).astype(np.uint8)

# 7. Prewitt (Pencarian Gradien Berbasis Rataan)
prewitt_x = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]], dtype=np.float32)
prewitt_y = np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]], dtype=np.float32)
prewitt_x_res = cv2.filter2D(citra_pre.astype(np.float32), -1, prewitt_x)
prewitt_y_res = cv2.filter2D(citra_pre.astype(np.float32), -1, prewitt_y)
prewitt = np.sqrt(prewitt_x_res**2 + prewitt_y_res**2)
prewitt = np.clip(prewitt, 0, 255).astype(np.uint8)

# ============================================
# TAMPILKAN PERBANDINGAN VISUAL
# ============================================
plt.figure(figsize=(18, 12))

plt.subplot(3, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("1. Original")
plt.axis('off')

plt.subplot(3, 3, 2)
plt.imshow(sobel, cmap='gray')
plt.title("2. Sobel\n(Garis tepi halus & tebal)")
plt.axis('off')

plt.subplot(3, 3, 3)
plt.imshow(laplacian, cmap='gray')
plt.title("3. Laplacian\n(Sketsa tipis, sensitif noise)")
plt.axis('off')

plt.subplot(3, 3, 4)
plt.imshow(canny_default, cmap='gray')
plt.title("4. Canny Default\n(th1=50, th2=150)")
plt.axis('off')

plt.subplot(3, 3, 5)
plt.imshow(canny_aggressive, cmap='gray')
plt.title("5. Canny Aggressive\n(th1=30, th2=90)")
plt.axis('off')

plt.subplot(3, 3, 6)
plt.imshow(canny_conservative, cmap='gray')
plt.title("6. Canny Conservative\n(th1=100, th2=200)")
plt.axis('off')

plt.subplot(3, 3, 7)
plt.imshow(roberts, cmap='gray')
plt.title("7. Roberts Cross\n(Garis patah-patah & cepat)")
plt.axis('off')

plt.subplot(3, 3, 8)
plt.imshow(prewitt, cmap='gray')
plt.title("8. Prewitt\n(Mirip Sobel tapi lebih tajam)")
plt.axis('off')

plt.suptitle("Perbandingan Semua Metode Deteksi Tepi pada Foto", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# ANALISIS PERFORMA
# ============================================
print("\n[ANALISIS PERBANDINGAN]")
print("=" * 65)
print(f"{'Metode':<12} | {'Kecepatan':<10} | {'Kualitas':<10} | {'Noise Robust':<12} | {'Direction Info':<15}")
print("-" * 65)
print(f"{'Sobel':<12} | {'Cepat':<10} | {'Sedang':<10} | {'Sedang':<12} | {'✅ Ya':<15}")
print(f"{'Laplacian':<12} | {'Cepat':<10} | {'Sedang':<10} | {'Buruk':<12} | {'❌ Tidak':<15}")
print(f"{'Canny':<12} | {'Lambat':<10} | {'Terbaik':<10} | {'Baik':<12} | {'✅ Ya (implisit)':<15}")
print(f"{'Roberts':<12} | {'Tercepat':<10} | {'Rendah':<10} | {'Buruk':<12} | {'✅ Ya':<15}")
print(f"{'Prewitt':<12} | {'Cepat':<10} | {'Sedang':<10} | {'Sedang':<12} | {'✅ Ya':<15}")
print("=" * 65)

print("\n[REKOMENDASI]")
print("-" * 40)
print("📌 Untuk hasil TERBAIK: Canny Edge Detection")
print("📌 Untuk aplikasi REAL-TIME: Sobel atau Roberts")
print("📌 Untuk gambar BERNOISE: Canny dengan blur preprocessing")
print("📌 Untuk analisis ARAH tepi: Sobel")
print("📌 Untuk kesederhanaan: Prewitt")
print("\n✅ Modul 4 - Bagian 5 selesai!")