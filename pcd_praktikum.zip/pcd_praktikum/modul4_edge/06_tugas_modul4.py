import cv2
import matplotlib.pyplot as plt
import numpy as np
import os

# ============================================
# TUGAS MODUL 4: PRAKTIK MANDIRI
# ============================================
print("=" * 50)
print("TUGAS MODUL 4")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# TUGAS 1: Cari parameter Canny terbaik
# ============================================
print("\n[TUGAS 1] Mencari Parameter Canny Terbaik")
print("Silakan coba berbagai kombinasi (th1, th2)")
print("Rekomendasi: coba (30,90), (50,150), (70,180), (100,200)")

param_coba = [(30, 90), (50, 150), (70, 180), (100, 200)]

plt.figure(figsize=(15, 10))
plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

for i, (th1, th2) in enumerate(param_coba, 2):
    canny = cv2.Canny(citra, th1, th2)
    plt.subplot(2, 3, i)
    plt.imshow(canny, cmap='gray')
    plt.title(f"Canny (th1={th1}, th2={th2})")
    plt.axis('off')

plt.suptitle("TUGAS 1: Eksplorasi Parameter Canny", fontsize=16)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Parameter mana yang memberikan hasil terbaik?")
print("Jawab: th1=50, th2=150 atau th1=70, th2=180")
print("Mengapa? Karena rasio hiteresis 1:3 memberikan keseimbangan optimal. Batas ini cukup rendah untuk menangkap kontur penting wajah dan pakaian, tetapi cukup tinggi untuk menyaring noise latar belakang yang mengganggu.")

# ============================================
# TUGAS 2: Deteksi tepi pada gambar ber-noise
# ============================================
print("\n[TUGAS 2] Deteksi Tepi pada Gambar Ber-Noise")

# Buat gambar dengan noise salt-and-pepper ekstrem
citra_noise = citra.copy()
salt = np.random.random(citra.shape) < 0.02
pepper = np.random.random(citra.shape) < 0.02
citra_noise[salt] = 255
citra_noise[pepper] = 0

# Coba berbagai metode langsung tanpa filter awal
sobel_noise = cv2.Sobel(citra_noise, cv2.CV_64F, 1, 1, ksize=3)
sobel_noise = np.clip(np.abs(sobel_noise), 0, 255).astype(np.uint8)

laplacian_noise = cv2.Laplacian(citra_noise, cv2.CV_64F)
laplacian_noise = np.clip(np.abs(laplacian_noise), 0, 255).astype(np.uint8)

canny_noise = cv2.Canny(citra_noise, 50, 150)

# Metode Solusi: Dengan preprocessing blur
blur = cv2.GaussianBlur(citra_noise, (5, 5), 0)
canny_preprocess = cv2.Canny(blur, 50, 150)

plt.figure(figsize=(15, 10))
plt.subplot(2, 3, 1)
plt.imshow(citra_noise, cmap='gray')
plt.title("Gambar dengan Noise Salt-Pepper")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(sobel_noise, cmap='gray')
plt.title("Sobel (Noise Terdeteksi!)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(laplacian_noise, cmap='gray')
plt.title("Laplacian (Sangat Noise)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(canny_noise, cmap='gray')
plt.title("Canny Langsung (Masih Noise)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(blur, cmap='gray')
plt.title("Setelah Gaussian Blur 5x5")
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(canny_preprocess, cmap='gray')
plt.title("Canny + Preprocessing (Bersih!)")
plt.axis('off')

plt.suptitle("TUGAS 2: Menangani Noise pada Deteksi Tepi", fontsize=16)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Metode mana yang paling efektif untuk gambar ber-noise?")
print("Jawab: Kombinasi Gaussian Blur (5x5) dilanjutkan dengan Canny Edge Detection (Canny + Preprocessing). Filter Gaussian meredam lonceng intensitas bising impulsif (salt & pepper) menjadi area halus, sehingga saat algoritma Canny mencari gradien hiteresis, bercak tersebut tidak lagi dianggap sebagai tepi objek asli.")

# ============================================
# TUGAS 3: Kombinasi tepi dari berbagai metode
# ============================================
print("\n[TUGAS 3] Kombinasi Tepi dari Berbagai Metode")

# Hitung tepi dengan berbagai metode
canny1 = cv2.Canny(citra, 30, 90)    # Banyak memuat detail tepi halus (Aggressive)
canny2 = cv2.Canny(citra, 100, 200)  # Hanya memuat kerangka tepi kuat (Conservative)

sobel_edge = cv2.Sobel(citra, cv2.CV_64F, 1, 1, ksize=3)
sobel_edge = np.clip(np.abs(sobel_edge), 0, 255).astype(np.uint8)

# Kombinasi: AND (Tepi yang muncul di KEDUA metode)
kombinasi_and = cv2.bitwise_and(canny1, canny2)

# Kombinasi: OR (Tepi dari SALAH SATU metode)
kombinasi_or = cv2.bitwise_or(canny1, canny2)

plt.figure(figsize=(15, 10))
plt.subplot(2, 3, 1)
plt.imshow(canny1, cmap='gray')
plt.title("Canny (Low Threshold)")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(canny2, cmap='gray')
plt.title("Canny (High Threshold)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(sobel_edge, cmap='gray')
plt.title("Sobel")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(kombinasi_and, cmap='gray')
plt.title("Kombinasi AND\n(Tepi yang pasti/valid)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(kombinasi_or, cmap='gray')
plt.title("Kombinasi OR\n(Semua kemungkinan tepi)")
plt.axis('off')

plt.suptitle("TUGAS 3: Kombinasi Logika Biner Deteksi Tepi", fontsize=16)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Kapan kombinasi AND berguna? Kapan kombinasi OR berguna?")
print("Jawab:")
print("- Kombinasi AND berguna saat kita membutuhkan akurasi dan kepastian tinggi (High Confidence) untuk mendeteksi kerangka struktural utama objek tanpa gangguan noise halus. Hanya piksel yang divalidasi oleh kedua threshold yang akan dipertahankan.")
print("- Kombinasi OR berguna saat kita melakukan segmentasi objek detail yang rapuh atau tipis (seperti pembuluh darah medis atau jalan raya satelit) di mana kita ingin mengumpulkan sebanyak mungkin informasi kontur tekstur yang kontinu tanpa takut kehilangan data.")

# ============================================
# TUGAS 4: Simpan hasil terbaik
# ============================================
print("\n[TUGAS 4] Simpan Hasil Deteksi Tepi Terbaik")

# Buat folder output jika belum tersedia
folder_output = 'hasil_output'
if not os.path.exists(folder_output):
    os.makedirs(folder_output)
    if os.path.exists('../hasil_output'):
        folder_output = '../hasil_output'

# Pilih hasil terbaik (Canny dengan preprocessing optimal)
optimal_blur = cv2.GaussianBlur(citra, (5, 5), 0)
hasil_terbaik = cv2.Canny(optimal_blur, 50, 150)

path_simpan = os.path.join(folder_output, 'modul4_hasil_tepi.jpg')
cv2.imwrite(path_simpan, hasil_terbaik)
print(f"✅ Hasil deteksi tepi disimpan di: {path_simpan}")

plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(hasil_terbaik, cmap='gray')
plt.title("Hasil Deteksi Tepi Terbaik\n(Canny + Gaussian Blur 5x5)")
plt.axis('off')

plt.suptitle("Tugas 4: Ekspor Sketsa Tepi", fontsize=16)
plt.show()

# ============================================
# RINGKASAN MODUL 4
# ============================================
print("\n" + "=" * 50)
print("RINGKASAN MODUL 4")
print("=" * 50)
print("\n✅ Yang sudah dipelajari:")
print("1. Konsep gradien dan laju perubahan intensitas tepi")
print("2. Operator Sobel (Gx = tepi vertikal, Gy = tepi horizontal)")
print("3. Operator Laplacian (turunan kedua, bersifat isotropik tanpa arah)")
print("4. Canny Edge Detection (metode terbaik, multi-tahap hiteresis)")
print("5. Roberts Cross dan Prewitt (metode matriks dasar & cepat)")
print("6. Pengaruh parameter threshold dan filter blur")
print("7. Kombinasi bitwise untuk manipulasi peta biner tepi")

print("\n💡 Tips Utama Implementasi:")
print("- Gunakan Canny untuk akurasi sketsa bentuk visual terbaik.")
print("- Selalu lakukan Gaussian Blur SEBELUM proses deteksi tepi agar terbebas dari bercak noise.")
print("- Setel threshold rendah untuk mencari tekstur, setel threshold tinggi untuk mencari bentuk geometri.")
print("- Sobel tetap menjadi pilihan terbaik jika aplikasi robotikmu butuh kalkulasi vektor arah sudut kemiringan.")

print("\n🎉 SELAMAT! MODUL 4 DAN SELURUH PROYEK PCD KAMU TELAH SELESAI DENGAN SEMPURNA! 🎉")