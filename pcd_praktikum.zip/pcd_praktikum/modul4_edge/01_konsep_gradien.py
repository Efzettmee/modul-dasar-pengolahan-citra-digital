import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 4: KONSEP GRADIEN UNTUK DETEKSI TEPI
# ============================================
print("=" * 50)
print("MODUL 4: MEMAHAMI GRADIEN")
print("=" * 50)

# Baca gambar grayscale menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)
print(f"Dimensi gambar: {citra.shape}")

# ============================================
# APA ITU GRADIEN?
# ============================================
print("\n[KONSEP GRADIEN]")
print("-" * 40)
print("Tepi adalah area di mana terjadi PERUBAHAN INTENSITAS yang drastis")
print("Gradien = laju perubahan intensitas (seperti turunan dalam kalkulus)")
print(" - Gradien besar = tepi yang kuat")
print(" - Gradien kecil = daerah yang halus")

# ============================================
# DEMO: MEMBUAT GAMBAR DENGAN TEPI JELAS
# ============================================
print("\n[DEMO: MEMBUAT GAMBAR SEDERHANA]")
# Buat gambar kotak putih di atas hitam
gambar_sederhana = np.zeros((200, 200), dtype=np.uint8)
gambar_sederhana[50:150, 50:150] = 255

# Hitung gradien sederhana secara manual (perbedaan piksel tetangga)
# Gradien horizontal (perbedaan kiri-kanan)
gradien_x = np.zeros_like(gambar_sederhana, dtype=np.float32)
for y in range(200):
    for x in range(1, 199):
        gradien_x[y, x] = float(gambar_sederhana[y, x+1]) - float(gambar_sederhana[y, x-1])

# Gradien vertikal (perbedaan atas-bawah)
gradien_y = np.zeros_like(gambar_sederhana, dtype=np.float32)
for y in range(1, 199):
    for x in range(200):
        gradien_y[y, x] = float(gambar_sederhana[y+1, x]) - float(gambar_sederhana[y-1, x])

# Magnitude gradien (kekuatan tepi)
magnitude = np.sqrt(gradien_x**2 + gradien_y**2)
magnitude = np.clip(magnitude, 0, 255).astype(np.uint8)

# Tampilkan Demo Gambar Sederhana
plt.figure(figsize=(15, 5))
plt.subplot(1, 4, 1)
plt.imshow(gambar_sederhana, cmap='gray')
plt.title("1. Gambar Sederhana\n(Kotak putih)")
plt.axis('off')

plt.subplot(1, 4, 2)
plt.imshow(np.abs(gradien_x), cmap='gray')
plt.title("2. Gradien X\n(Tepi vertikal)")
plt.axis('off')

plt.subplot(1, 4, 3)
plt.imshow(np.abs(gradien_y), cmap='gray')
plt.title("3. Gradien Y\n(Tepi horizontal)")
plt.axis('off')

plt.subplot(1, 4, 4)
plt.imshow(magnitude, cmap='gray')
plt.title("4. Magnitude Gradien\n(Kekuatan tepi)")
plt.axis('off')

plt.suptitle("Konsep Gradien untuk Deteksi Tepi", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[PENJELASAN]")
print("- Gradien X menangkap tepi VERTIKAL (perubahan kiri-kanan)")
print("- Gradien Y menangkap tepi HORIZONTAL (perubahan atas-bawah)")
print("- Magnitude = √(Gx² + Gy²) = kekuatan tepi total")

# ============================================
# DEMO GRADIEN PADA GAMBAR ASLI
# ============================================
print("\n[APPLY GRADIEN PADA GAMBAR ASLI]")
# Hitung gradien dengan Sobel (lebih halus daripada metode manual)
sobel_x = cv2.Sobel(citra, cv2.CV_64F, 1, 0, ksize=3)
sobel_y = cv2.Sobel(citra, cv2.CV_64F, 0, 1, ksize=3)
magnitude_sobel = np.sqrt(sobel_x**2 + sobel_y**2)
magnitude_sobel = np.clip(magnitude_sobel, 0, 255).astype(np.uint8)

# Tampilkan Demo Gambar Asli
plt.figure(figsize=(15, 5))
plt.subplot(1, 4, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

plt.subplot(1, 4, 2)
plt.imshow(np.abs(sobel_x), cmap='gray')
plt.title("Gradien X\n(Tepi vertikal dominan)")
plt.axis('off')

plt.subplot(1, 4, 3)
plt.imshow(np.abs(sobel_y), cmap='gray')
plt.title("Gradien Y\n(Tepi horizontal dominan)")
plt.axis('off')

plt.subplot(1, 4, 4)
plt.imshow(magnitude_sobel, cmap='gray')
plt.title("Magnitude Gradien\n(Semua tepi)")
plt.axis('off')

plt.suptitle("Gradien pada Gambar Asli (dengan Sobel)", fontsize=16)
plt.tight_layout()
plt.show()

print("\n✅ Perhatikan: tepi vertikal (seperti hidung/bahu) muncul di gradien X")
print("   tepi horizontal (seperti bibir/mata) muncul di gradien Y")
print("\n✅ Modul 4 - Bagian 1 selesai!")