import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# PERSIAPAN: Membaca Gambar
# ============================================
print("=" * 50)
print("LATIHAN MODUL 1: RANGKUMAN")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra = cv2.imread('images/saya.jpg')
if citra is None:
    citra = cv2.imread('../images/saya.jpg')

# Jika gagal, buat gambar dummy acak
if citra is None:
    print("Gambar tidak ditemukan, menggunakan dummy acak...")
    citra = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_rgb = cv2.cvtColor(citra, cv2.COLOR_BGR2RGB)

# ============================================
# LATIHAN 1: Perbedaan shape RGB vs Grayscale
# ============================================
print("\n[LATIHAN 1]")
citra_gray = cv2.cvtColor(citra, cv2.COLOR_BGR2GRAY)
print(f"Shape RGB: {citra_rgb.shape}")
print(f"Shape Grayscale: {citra_gray.shape}")

# ============================================
# LATIHAN 2: Crop 4 bagian sama besar
# ============================================
print("\n[LATIHAN 2]")
# Ambil ukuran total (Tinggi dan Lebar)
h, w = citra_rgb.shape[0], citra_rgb.shape[1]

# Cari titik tengah persisnya
tengah_h, tengah_w = h // 2, w // 2

# Lakukan proses slicing / pemotongan
kiri_atas = citra_rgb[0:tengah_h, 0:tengah_w]
kanan_atas = citra_rgb[0:tengah_h, tengah_w:w]
kiri_bawah = citra_rgb[tengah_h:h, 0:tengah_w]
kanan_bawah = citra_rgb[tengah_h:h, tengah_w:w]

# Tampilkan ke 4 gambar menggunakan subplot
plt.figure(figsize=(10, 10))

plt.subplot(2, 2, 1)
plt.imshow(kiri_atas)
plt.title("Kiri Atas")
plt.axis('off')

plt.subplot(2, 2, 2)
plt.imshow(kanan_atas)
plt.title("Kanan Atas")
plt.axis('off')

plt.subplot(2, 2, 3)
plt.imshow(kiri_bawah)
plt.title("Kiri Bawah")
plt.axis('off')

plt.subplot(2, 2, 4)
plt.imshow(kanan_bawah)
plt.title("Kanan Bawah")
plt.axis('off')

plt.suptitle("Hasil Crop 4 Bagian Sama Besar")
plt.tight_layout()
plt.show()

# ============================================
# LATIHAN 5: Gradien warna kiri ke kanan
# ============================================
print("\n[LATIHAN 5]")
# Buat kanvas kosong ukuran 300x500 piksel dengan 3 Channel warna
gradien = np.zeros((300, 500, 3), dtype=np.uint8)

# Looping mengisi warna per kolom (sumbu x / lebar)
for x in range(500):
    # Channel Merah (Index 0 di Matplotlib): Nilainya semakin tinggi (0 -> 255) saat ke kanan
    gradien[:, x, 0] = int(x * 255 / 500)
    
    # Channel Biru (Index 2 di Matplotlib): Nilainya terbalik (255 -> 0) alias redup saat ke kanan
    gradien[:, x, 2] = 255 - int(x * 255 / 500)

plt.figure(figsize=(10, 3))
plt.imshow(gradien)
plt.title("Gradien Warna (Merah ke Biru)")
plt.axis('off')
plt.show()