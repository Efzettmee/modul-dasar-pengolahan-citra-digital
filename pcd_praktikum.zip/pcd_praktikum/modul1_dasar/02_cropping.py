import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# BAGIAN 2: CROPPING (MEMOTONG GAMBAR)
# ============================================
print("=" * 50)
print("MODUL 2: CROPPING GAMBAR")
print("=" * 50)

# Baca gambar dengan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

# Pengecekan jika gambar gagal dimuat
if citra_bgr is None:
    print("ERROR: Gambar tidak ditemukan!")
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

# Konversi ke RGB untuk ditampilkan dengan Matplotlib
citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
tinggi, lebar = citra_rgb.shape[0], citra_rgb.shape[1]
print(f"Dimensi asli: {tinggi} x {lebar} piksel")

# ============================================
# CROPPING: memotong dengan slicing array
# Format: gambar[baris_atas:baris_bawah, kolom_kiri:kolom_kanan]
# ============================================

# 1. Crop bagian tengah (25% sampai 75% dari ukuran)
print("\n[1. Crop bagian tengah]")
mulai_y = tinggi // 4     # mulai dari 25% dari atas
akhir_y = 3 * tinggi // 4 # sampai 75% dari atas
mulai_x = lebar // 4
akhir_x = 3 * lebar // 4
potongan_tengah = citra_rgb[mulai_y:akhir_y, mulai_x:akhir_x]
print(f"Ukuran potongan tengah: {potongan_tengah.shape[0]} x {potongan_tengah.shape[1]}")

# 2. Crop bagian wajah (Catatan: Koordinat ini mungkin meleset tergantung letak wajah di fotomu)
print("\n[2. Crop area wajah (perkiraan)]")
potongan_wajah = citra_rgb[150:450, 300:600] 
print(f"Ukuran potongan wajah: {potongan_wajah.shape[0]} x {potongan_wajah.shape[1]}")

# 3. Crop bagian mata (Diperkecil area crop-nya)
print("\n[3. Crop area detail/mata]")
potongan_mata = citra_rgb[250:320, 380:480] 
print(f"Ukuran potongan mata: {potongan_mata.shape[0]} x {potongan_mata.shape[1]}")

# ============================================
# TAMPILKAN SEMUA HASIL (Gambar 1 sampai 4)
# ============================================
plt.figure(figsize=(12, 8))

# Gambar asli
plt.subplot(2, 2, 1)
plt.imshow(citra_rgb)
plt.title(f"1. Gambar Asli\n{tinggi} x {lebar}")
plt.axis('off')

# Potongan tengah
plt.subplot(2, 2, 2)
plt.imshow(potongan_tengah)
plt.title(f"2. Potongan Tengah\n{potongan_tengah.shape[0]} x {potongan_tengah.shape[1]}")
plt.axis('off')

# Potongan wajah
plt.subplot(2, 2, 3)
plt.imshow(potongan_wajah)
plt.title(f"3. Potongan Wajah\n{potongan_wajah.shape[0]} x {potongan_wajah.shape[1]}")
plt.axis('off')

# Potongan mata (diperbesar)
plt.subplot(2, 2, 4)
plt.imshow(potongan_mata)
plt.title(f"4. Potongan Mata (Detail)\n{potongan_mata.shape[0]} x {potongan_mata.shape[1]}")
plt.axis('off')

plt.suptitle("Modul 2: Cropping (Memotong Gambar)", fontsize=14)
plt.tight_layout()
plt.show()

# ============================================
# EKSPERIMEN: Coba crop area berbeda
# ============================================
print("\n" + "=" * 50)
print("EKSPERIMEN: Coba crop area berbeda!")
print("=" * 50)

# EKSPERIMEN BARU: Mencoba memotong area "Cangkir Kopi" atau bagian bawah foto
# (Silakan ubah angka ini nanti jika lokasinya belum pas)
y1, y2 = 600, 900  # Baris atas (y1) dan bawah (y2)
x1, x2 = 350, 700  # Kolom kiri (x1) dan kanan (x2)

print(f"\nMencoba crop area: y={y1}-{y2}, x={x1}-{x2}")
if y2 <= tinggi and x2 <= lebar:
    potongan_eksperimen = citra_rgb[y1:y2, x1:x2]
    
    plt.figure(figsize=(10, 5))
    
    # Jendela Kiri: Tandai area crop di gambar asli
    plt.subplot(1, 2, 1)
    citra_tanda = citra_rgb.copy()
    # Membuat kotak biru dengan ketebalan 8 px agar terlihat jelas
    cv2.rectangle(citra_tanda, (x1, y1), (x2, y2), (0, 0, 255), 8) 
    plt.imshow(citra_tanda)
    plt.title("Area yang akan di-crop (Kotak Biru)")
    plt.axis('off')
    
    # Jendela Kanan: Hasil Potongannya
    plt.subplot(1, 2, 2)
    plt.imshow(potongan_eksperimen)
    plt.title(f"Hasil Crop\n{potongan_eksperimen.shape[0]} x {potongan_eksperimen.shape[1]}")
    plt.axis('off')
    
    plt.show()
else:
    print("ERROR: Koordinat crop melebihi ukuran gambar!")