import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# TUGAS MINI: MEMBUAT CITRA KOTAK-KOTAK
# ============================================
print("=" * 50)
print("TUGAS MINI: MEMBUAT CHECKERBOARD")
print("=" * 50)

# 1. Buat checkerboard 8x8 (masing-masing kotak 50x50 piksel)
ukuran_kotak = 50  # piksel
jumlah_kotak_per_baris = 8
total_piksel = ukuran_kotak * jumlah_kotak_per_baris # Total 400x400 piksel

# Buat array kosong (hitam semua) - 1 Channel untuk Grayscale
checkerboard = np.zeros((total_piksel, total_piksel), dtype=np.uint8)

# Isi kotak-kotak putih (nilai 255)
for i in range(jumlah_kotak_per_baris):      # baris kotak
    for j in range(jumlah_kotak_per_baris):  # kolom kotak
        # Tentukan apakah kotak ini harus putih (genap)
        if (i + j) % 2 == 0:
            # Hitung posisi piksel
            y_start = i * ukuran_kotak
            y_end = (i + 1) * ukuran_kotak
            x_start = j * ukuran_kotak
            x_end = (j + 1) * ukuran_kotak
            # Isi area dengan warna putih
            checkerboard[y_start:y_end, x_start:x_end] = 255

# ============================================
# BUAT VARIASI: CHECKERBOARD WARNA (Asli)
# ============================================
# Buat array 3D (3 Channel untuk RGB)
checkerboard_warna = np.zeros((total_piksel, total_piksel, 3), dtype=np.uint8)

for i in range(jumlah_kotak_per_baris):
    for j in range(jumlah_kotak_per_baris):
        y_start = i * ukuran_kotak
        y_end = (i + 1) * ukuran_kotak
        x_start = j * ukuran_kotak
        x_end = (j + 1) * ukuran_kotak
        
        if (i + j) % 2 == 0:
            # Warna merah di Matplotlib (RGB): [255, 0, 0]
            checkerboard_warna[y_start:y_end, x_start:x_end] = [255, 0, 0]
        else:
            # Warna biru di Matplotlib (RGB): [0, 0, 255]
            checkerboard_warna[y_start:y_end, x_start:x_end] = [0, 0, 255]

# ============================================
# EKSPERIMEN: VERSI KUSTOMISASI KITA
# ============================================
uk_kustom = 30  # Lebih kecil
jm_kustom = 10  # Jadi 10x10 kotak
tot_kustom = uk_kustom * jm_kustom # Total 300x300 piksel

checker_kustom = np.zeros((tot_kustom, tot_kustom, 3), dtype=np.uint8)

for i in range(jm_kustom):
    for j in range(jm_kustom):
        y_start = i * uk_kustom
        y_end = (i + 1) * uk_kustom
        x_start = j * uk_kustom
        x_end = (j + 1) * uk_kustom
        
        if (i + j) % 2 == 0:
            # Warna Kuning (Merah + Hijau): [255, 255, 0]
            checker_kustom[y_start:y_end, x_start:x_end] = [255, 255, 0]
        else:
            # Warna Ungu Gelap: [128, 0, 128]
            checker_kustom[y_start:y_end, x_start:x_end] = [128, 0, 128]

# ============================================
# TAMPILKAN HASIL
# ============================================
plt.figure(figsize=(15, 5)) # Diperlebar agar muat 3 gambar

plt.subplot(1, 3, 1)
plt.imshow(checkerboard, cmap='gray')
plt.title(f"1. Checkerboard Grayscale\n{ukuran_kotak}px, {jumlah_kotak_per_baris}x{jumlah_kotak_per_baris}")
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(checkerboard_warna)
plt.title(f"2. Checkerboard Warna\nMerah & Biru")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(checker_kustom)
plt.title(f"3. Versi Kustomisasi\nKuning & Ungu ({uk_kustom}px, {jm_kustom}x{jm_kustom})")
plt.axis('off')

plt.suptitle("Tugas Mini: Membuat Citra Kotak-Kotak (Checkerboard)", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[TUGAS SELESAI]")
print("Anda telah berhasil membuat citra checkerboard dan versi kustomnya!")