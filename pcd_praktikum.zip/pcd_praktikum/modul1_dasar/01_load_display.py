import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# BAGIAN 1: MEMBACA DAN MENAMPILKAN GAMBAR
# ============================================
print("=" * 50)
print("MODUL 1: FONDASI CITRA DIGITAL")
print("=" * 50)

# 1. Membaca gambar
# --- PERBAIKAN PATH GAMBAR ---
# Coba baca dengan asumsi VS Code berjalan di folder utama (PCD_PRAKTIKUM)
citra_bgr = cv2.imread('images/saya.jpg')

# Jika gagal, coba baca dengan asumsi VS Code berjalan di dalam folder (modul1_dasar)
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

# Cek apakah gambar benar-benar berhasil dibaca setelah dua percobaan
if citra_bgr is None:
    print("ERROR: Gambar tetap tidak ditemukan!")
    print("Pastikan nama file benar-benar 'saya.jpg' (huruf kecil semua) dan lokasinya ada di dalam folder 'images'.")
    print("Membuat gambar dummy sebagai alternatif...")
    # Buat gambar dummy berwarna gradien
    citra_bgr = np.zeros((300, 400, 3), dtype=np.uint8)
    for i in range(300):
        citra_bgr[i, :, 0] = i * 85 // 300 # Komponen Biru
        citra_bgr[i, :, 1] = i * 170 // 300 # Komponen Hijau
        citra_bgr[i, :, 2] = i * 255 // 300 # Komponen Merah
    print("Gambar dummy berhasil dibuat!")
else:
    print("SUKSES: Gambar foto kamu berhasil dimuat!")

# 2. Menampilkan informasi gambar
print(f"\n[INFORMASI GAMBAR]")
print(f"Tipe data: {citra_bgr.dtype}") # uint8 (0-255)
print(f"Dimensi (shape): {citra_bgr.shape}") # (tinggi, lebar, channel)
print(f"Jumlah channel: {citra_bgr.shape[2]} (B, G, R)")

# 3. Konversi BGR ke RGB (karena OpenCV pakai BGR, Matplotlib pakai RGB)
citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)

# 4. Menampilkan gambar dengan matplotlib
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(citra_bgr) # Ini akan salah warna (karena masih BGR)
plt.title("SALAH: Masih Format BGR")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(citra_rgb) # Ini benar (sudah RGB)
plt.title("BENAR: Format RGB")
plt.axis('off')

plt.suptitle("Perbedaan Format Warna BGR vs RGB", fontsize=14)
plt.show()

# 5. Menampilkan nilai piksel tertentu
tinggi, lebar = citra_rgb.shape[0], citra_rgb.shape[1]
print(f"\n[NILAI PIKSEL]")
print(f"Piksel pojok kiri atas (0,0): {citra_rgb[0, 0]}")
print(f"Piksel tengah ({tinggi//2}, {lebar//2}): {citra_rgb[tinggi//2, lebar//2]}")

# Eksperimen Interpolasi nilai piksel lainnya
print(f"Piksel pojok kanan atas (0, {lebar-1}): {citra_rgb[0, lebar-1]}")
print(f"Piksel pojok kiri bawah ({tinggi-1}, 0): {citra_rgb[tinggi-1, 0]}")
print(f"Piksel pojok kanan bawah ({tinggi-1}, {lebar-1}): {citra_rgb[tinggi-1, lebar-1]}")