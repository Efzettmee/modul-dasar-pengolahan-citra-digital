import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# BAGIAN 3: KONVERSI WARNA
# ============================================
print("=" * 50)
print("MODUL 3: KONVERSI WARNA")
print("=" * 50)

# Baca gambar dengan Smart Path (Panggil foto saya.jpg)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

# Cek jika gambar masih gagal dimuat
if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.zeros((300, 400, 3), dtype=np.uint8)
    # Buat gradien warna
    for i in range(300):
        citra_bgr[i, :, 0] = i * 85 // 300  # Biru
        citra_bgr[i, :, 1] = i * 170 // 300 # Hijau
        citra_bgr[i, :, 2] = i * 255 // 300 # Merah

citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)

# ============================================
# KONVERSI KE GRAYSCALE
# ============================================
# Cara 1: Menggunakan OpenCV
citra_grayscale_cv = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# Cara 2: Manual dengan rumus luminansi (jika penasaran)
# Menggunakan bobot sensitivitas mata manusia terhadap warna
r = citra_rgb[:, :, 0].astype(np.float32)
g = citra_rgb[:, :, 1].astype(np.float32)
b = citra_rgb[:, :, 2].astype(np.float32)
citra_grayscale_manual = (0.299 * r + 0.587 * g + 0.114 * b).astype(np.uint8)

# ============================================
# EKSTRAKSI CHANNEL WARNA (R, G, B terpisah)
# ============================================
# Ambil masing-masing channel (Bentuknya matriks 2D)
channel_merah = citra_rgb[:, :, 0] # Channel Red
channel_hijau = citra_rgb[:, :, 1] # Channel Green
channel_biru  = citra_rgb[:, :, 2] # Channel Blue

# Buat citra yang hanya menampilkan 1 warna (Mempertahankan matriks 3D)
hanya_merah = citra_rgb.copy()
hanya_merah[:, :, 1] = 0 # Matikan Hijau (Set nilai ke 0)
hanya_merah[:, :, 2] = 0 # Matikan Biru  (Set nilai ke 0)

hanya_hijau = citra_rgb.copy()
hanya_hijau[:, :, 0] = 0 # Matikan Merah
hanya_hijau[:, :, 2] = 0 # Matikan Biru

hanya_biru = citra_rgb.copy()
hanya_biru[:, :, 0] = 0 # Matikan Merah
hanya_biru[:, :, 1] = 0 # Matikan Hijau

# ============================================
# TAMPILKAN SEMUA HASIL KONVERSI
# ============================================
plt.figure(figsize=(14, 10))

# Baris 1: Gambar asli dan grayscale
plt.subplot(3, 3, 1)
plt.imshow(citra_rgb)
plt.title("1. Asli (RGB)")
plt.axis('off')

plt.subplot(3, 3, 2)
plt.imshow(citra_grayscale_cv, cmap='gray')
plt.title("2. Grayscale (OpenCV)")
plt.axis('off')

plt.subplot(3, 3, 3)
plt.imshow(citra_grayscale_manual, cmap='gray')
plt.title("3. Grayscale (Manual)")
plt.axis('off')

# Baris 2: Channel warna terpisah (Peta Intensitas)
plt.subplot(3, 3, 4)
plt.imshow(channel_merah, cmap='Reds')
plt.title("4. Channel Merah (Intensitas)")
plt.axis('off')

plt.subplot(3, 3, 5)
plt.imshow(channel_hijau, cmap='Greens')
plt.title("5. Channel Hijau (Intensitas)")
plt.axis('off')

plt.subplot(3, 3, 6)
plt.imshow(channel_biru, cmap='Blues')
plt.title("6. Channel Biru (Intensitas)")
plt.axis('off')

# Baris 3: Hanya satu warna
plt.subplot(3, 3, 7)
plt.imshow(hanya_merah)
plt.title("7. Hanya Merah")
plt.axis('off')

plt.subplot(3, 3, 8)
plt.imshow(hanya_hijau)
plt.title("8. Hanya Hijau")
plt.axis('off')

plt.subplot(3, 3, 9)
plt.imshow(hanya_biru)
plt.title("9. Hanya Biru")
plt.axis('off')

plt.suptitle("Modul 3: Konversi Warna dan Ekstraksi Channel", fontsize=14)
plt.tight_layout()
plt.show()

# ============================================
# EKSPERIMEN: KONVERSI WARNA LAINNYA (HSV)
# ============================================
print("\n" + "=" * 50)
print("EKSPERIMEN: Konversi ke Warna HSV")
print("=" * 50)
# HSV (Hue, Saturation, Value) sangat bagus untuk mendeteksi objek bercahaya
citra_hsv = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2HSV)

plt.figure(figsize=(6, 4))
plt.imshow(citra_hsv)
plt.title("Eksperimen: Format HSV\n(Warna terlihat neon karena dibaca sebagai RGB oleh plt)")
plt.axis('off')
plt.show()

# ============================================
# INFORMASI TAMBAHAN
# ============================================
print("\n[INFORMASI UKURAN]")
print(f"Citra RGB : {citra_rgb.shape}")
print(f"Citra Grayscale: {citra_grayscale_cv.shape}")

print("\n[PERBANDINGAN]")
print("Citra RGB memiliki 3 channel (R, G, B)")
print("Citra Grayscale memiliki 1 channel (intensitas cahaya)")

print("\n[KOMBINASI CHANNEL]")
print("- Channel Merah + Hijau = Kuning")
print("- Channel Merah + Biru = Magenta")
print("- Channel Hijau + Biru = Cyan")