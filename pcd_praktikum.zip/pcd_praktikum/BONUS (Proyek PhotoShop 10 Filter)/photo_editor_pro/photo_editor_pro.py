"""
Photo Editor Pro - Python Version
Proyek PCD (Pengolahan Citra Digital)
Fitur: Filter, Brightness, Contrast, Saturation, Blur, Sharpen,
       Edge Detection, Emboss, Rotate, Flip, Crop, Save
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk, ImageFilter, ImageEnhance, ImageOps
import numpy as np
import copy
import os


# ──────────────────────────────────────────────
#  KONSTANTA PRESET
# ──────────────────────────────────────────────
PRESETS = {
    "Normal":       dict(brightness=1.0, contrast=1.0, saturation=1.0, blur=0, sharpen=0, mode=None),
    "Grayscale":    dict(brightness=1.0, contrast=1.1, saturation=0.0, blur=0, sharpen=0, mode="grayscale"),
    "Sepia":        dict(brightness=1.05, contrast=1.05, saturation=0.2, blur=0, sharpen=0, mode="sepia"),
    "Invert":       dict(brightness=1.0, contrast=1.0, saturation=1.0, blur=0, sharpen=0, mode="invert"),
    "Warm":         dict(brightness=1.1, contrast=1.05, saturation=1.2, blur=0, sharpen=0, mode="warm"),
    "Cool":         dict(brightness=1.0, contrast=1.05, saturation=1.1, blur=0, sharpen=0, mode="cool"),
    "Vivid":        dict(brightness=1.1, contrast=1.25, saturation=1.6, blur=0, sharpen=1, mode=None),
    "Edge Detect":  dict(brightness=1.0, contrast=1.0, saturation=1.0, blur=0, sharpen=0, mode="edge"),
    "Emboss":       dict(brightness=1.0, contrast=1.0, saturation=1.0, blur=0, sharpen=0, mode="emboss"),
    "Fade":         dict(brightness=1.2, contrast=0.7, saturation=0.7, blur=0, sharpen=0, mode=None),
}


# ──────────────────────────────────────────────
#  FUNGSI PEMROSESAN CITRA
# ──────────────────────────────────────────────

def apply_sepia(img: Image.Image) -> Image.Image:
    """Konversi gambar ke tone sepia."""
    img_rgb = img.convert("RGB")
    arr = np.array(img_rgb, dtype=np.float32)
    r = np.clip(arr[:,:,0]*0.393 + arr[:,:,1]*0.769 + arr[:,:,2]*0.189, 0, 255)
    g = np.clip(arr[:,:,0]*0.349 + arr[:,:,1]*0.686 + arr[:,:,2]*0.168, 0, 255)
    b = np.clip(arr[:,:,0]*0.272 + arr[:,:,1]*0.534 + arr[:,:,2]*0.131, 0, 255)
    sepia_arr = np.stack([r, g, b], axis=2).astype(np.uint8)
    return Image.fromarray(sepia_arr)


def apply_warm(img: Image.Image) -> Image.Image:
    """Tambahkan tone hangat (merah+, biru-)."""
    img_rgb = img.convert("RGB")
    arr = np.array(img_rgb, dtype=np.int16)
    arr[:,:,0] = np.clip(arr[:,:,0] + 20, 0, 255)   # R +20
    arr[:,:,2] = np.clip(arr[:,:,2] - 15, 0, 255)   # B -15
    return Image.fromarray(arr.astype(np.uint8))


def apply_cool(img: Image.Image) -> Image.Image:
    """Tambahkan tone dingin (biru+, merah-)."""
    img_rgb = img.convert("RGB")
    arr = np.array(img_rgb, dtype=np.int16)
    arr[:,:,2] = np.clip(arr[:,:,2] + 20, 0, 255)   # B +20
    arr[:,:,0] = np.clip(arr[:,:,0] - 10, 0, 255)   # R -10
    return Image.fromarray(arr.astype(np.uint8))


def apply_edge_detection(img: Image.Image) -> Image.Image:
    """Deteksi tepi menggunakan Sobel operator."""
    gray = img.convert("L")
    arr = np.array(gray, dtype=np.float32)
    sobel_x = np.array([[-1,0,1],[-2,0,2],[-1,0,1]], dtype=np.float32)
    sobel_y = np.array([[-1,-2,-1],[0,0,0],[1,2,1]], dtype=np.float32)
    from scipy.ndimage import convolve
    gx = convolve(arr, sobel_x)
    gy = convolve(arr, sobel_y)
    magnitude = np.clip(np.sqrt(gx**2 + gy**2), 0, 255).astype(np.uint8)
    return Image.fromarray(magnitude).convert("RGB")


def apply_edge_detection_manual(img: Image.Image) -> Image.Image:
    """Deteksi tepi menggunakan Sobel manual (tanpa scipy)."""
    gray = img.convert("L")
    arr = np.array(gray, dtype=np.float32)
    h, w = arr.shape
    out = np.zeros_like(arr)
    sobel_x = np.array([[-1,0,1],[-2,0,2],[-1,0,1]], dtype=np.float32)
    sobel_y = np.array([[-1,-2,-1],[0,0,0],[1,2,1]], dtype=np.float32)
    for y in range(1, h-1):
        for x in range(1, w-1):
            patch = arr[y-1:y+2, x-1:x+2]
            gx = np.sum(patch * sobel_x)
            gy = np.sum(patch * sobel_y)
            out[y, x] = min(255, np.sqrt(gx**2 + gy**2))
    return Image.fromarray(out.astype(np.uint8)).convert("RGB")


def apply_sobel_fast(img: Image.Image) -> Image.Image:
    """Deteksi tepi cepat menggunakan filter PIL bawaan."""
    gray = img.convert("L")
    edge = gray.filter(ImageFilter.FIND_EDGES)
    return edge.convert("RGB")


def apply_emboss(img: Image.Image) -> Image.Image:
    """Efek emboss."""
    return img.filter(ImageFilter.EMBOSS).convert("RGB")


def apply_sharpen_level(img: Image.Image, level: int) -> Image.Image:
    """Penajaman bertingkat (0-5)."""
    if level == 0:
        return img
    factor = level * 0.3
    kernel = ImageFilter.Kernel(
        size=3,
        kernel=[0, -int(factor*10), 0,
                -int(factor*10), 1 + 4*int(factor*10), -int(factor*10),
                0, -int(factor*10), 0],
        scale=1,
        offset=0
    )
    # Gunakan UnsharpMask sebagai alternatif lebih stabil
    radius = level * 0.5
    percent = int(50 + level * 30)
    threshold = max(0, 3 - level)
    return img.filter(ImageFilter.UnsharpMask(radius=radius, percent=percent, threshold=threshold))


def process_image(
    base_img: Image.Image,
    brightness: float,
    contrast: float,
    saturation: float,
    blur: int,
    sharpen: int,
    mode: str,
    rotation: int,
    flip_h: bool,
    flip_v: bool
) -> Image.Image:
    """
    Terapkan seluruh pemrosesan ke gambar.
    Urutan: mode khusus → saturation → contrast → brightness → sharpen → blur → transform
    """
    img = base_img.convert("RGB").copy()

    # 1. Mode khusus (filter)
    if mode == "grayscale":
        img = ImageOps.grayscale(img).convert("RGB")
    elif mode == "sepia":
        img = apply_sepia(img)
    elif mode == "invert":
        img = ImageOps.invert(img)
    elif mode == "warm":
        img = apply_warm(img)
    elif mode == "cool":
        img = apply_cool(img)
    elif mode == "edge":
        img = apply_sobel_fast(img)
        # Transformasi lalu return langsung (tidak perlu adjustment warna)
        img = _transform(img, rotation, flip_h, flip_v)
        return img
    elif mode == "emboss":
        img = apply_emboss(img)
        img = _transform(img, rotation, flip_h, flip_v)
        return img

    # 2. Saturation
    if saturation != 1.0:
        img = ImageEnhance.Color(img).enhance(saturation)

    # 3. Contrast
    if contrast != 1.0:
        img = ImageEnhance.Contrast(img).enhance(contrast)

    # 4. Brightness
    if brightness != 1.0:
        img = ImageEnhance.Brightness(img).enhance(brightness)

    # 5. Sharpen
    if sharpen > 0:
        img = apply_sharpen_level(img, sharpen)

    # 6. Blur
    if blur > 0:
        img = img.filter(ImageFilter.GaussianBlur(radius=blur))

    # 7. Transform (rotate & flip)
    img = _transform(img, rotation, flip_h, flip_v)
    return img


def _transform(img: Image.Image, rotation: int, flip_h: bool, flip_v: bool) -> Image.Image:
    """Rotasi dan flip gambar."""
    if flip_h:
        img = ImageOps.mirror(img)
    if flip_v:
        img = ImageOps.flip(img)
    if rotation != 0:
        img = img.rotate(-rotation, expand=True)
    return img


# ──────────────────────────────────────────────
#  APLIKASI GUI
# ──────────────────────────────────────────────

class PhotoEditorApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Photo Editor Pro — PCD Project")
        self.root.geometry("1100x700")
        self.root.configure(bg="#1e1e2e")
        self.root.resizable(True, True)

        # State
        self.original_image: Image.Image | None = None
        self.working_image: Image.Image | None = None   # setelah crop
        self.display_photo: ImageTk.PhotoImage | None = None
        self.current_preset = "Normal"
        self.rotation = 0
        self.flip_h = False
        self.flip_v = False
        self.crop_mode = False
        self.crop_start = None
        self.crop_rect_id = None

        # Slider vars
        self.var_brightness = tk.DoubleVar(value=1.0)
        self.var_contrast   = tk.DoubleVar(value=1.0)
        self.var_saturation = tk.DoubleVar(value=1.0)
        self.var_blur       = tk.IntVar(value=0)
        self.var_sharpen    = tk.IntVar(value=0)

        self._build_ui()
        self._update_info("Belum ada foto yang diupload")

    # ── UI Builder ──────────────────────────────

    def _build_ui(self):
        # Header
        hdr = tk.Frame(self.root, bg="#1e1e2e")
        hdr.pack(fill="x", padx=16, pady=(12, 6))
        tk.Label(hdr, text="📷 Photo Editor Pro", font=("Segoe UI", 18, "bold"),
                 bg="#1e1e2e", fg="#cdd6f4").pack()
        tk.Label(hdr, text="Filter · Blur · Edge Detection · Rotate · Flip · Crop",
                 font=("Segoe UI", 10), bg="#1e1e2e", fg="#6c7086").pack()

        # Main frame
        main = tk.Frame(self.root, bg="#1e1e2e")
        main.pack(fill="both", expand=True, padx=16, pady=(0, 12))

        # Canvas panel
        self._build_canvas_panel(main)

        # Controls panel
        self._build_controls(main)

    def _build_canvas_panel(self, parent):
        frame = tk.Frame(parent, bg="#181825", bd=1, relief="solid")
        frame.pack(side="left", fill="both", expand=True, padx=(0, 10))

        self.canvas = tk.Canvas(frame, bg="#181825", cursor="arrow",
                                highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=10)

        # Placeholder text
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.canvas.bind("<ButtonPress-1>", self._crop_start)
        self.canvas.bind("<B1-Motion>", self._crop_drag)
        self.canvas.bind("<ButtonRelease-1>", self._crop_end)

        # Info bar
        self.info_var = tk.StringVar()
        tk.Label(frame, textvariable=self.info_var, font=("Segoe UI", 9),
                 bg="#181825", fg="#6c7086").pack(pady=(0, 6))

    def _build_controls(self, parent):
        outer = tk.Frame(parent, bg="#1e1e2e", width=280)
        outer.pack(side="right", fill="y")
        outer.pack_propagate(False)

        # Scrollable
        canvas = tk.Canvas(outer, bg="#1e1e2e", highlightthickness=0, width=280)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        self.ctrl_frame = tk.Frame(canvas, bg="#1e1e2e")
        self.ctrl_frame.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.ctrl_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        ctrl = self.ctrl_frame

        # Upload
        self._section(ctrl, "File")
        tk.Button(ctrl, text="📂  Buka Foto", command=self._open_image,
                  **self._btn_style()).pack(fill="x", pady=2)

        # Filter presets
        self._section(ctrl, "Filter Efek")
        self._build_preset_buttons(ctrl)

        # Sliders
        self._section(ctrl, "Penyesuaian")
        self._slider(ctrl, "☀ Brightness", self.var_brightness, 0.0, 2.0, 0.01, "%.2f")
        self._slider(ctrl, "◑ Contrast",   self.var_contrast,   0.0, 2.0, 0.01, "%.2f")
        self._slider(ctrl, "💧 Saturation", self.var_saturation, 0.0, 2.0, 0.01, "%.2f")
        self._slider(ctrl, "≋ Blur",        self.var_blur,       0,   20,  1,    "%d")
        self._slider(ctrl, "△ Sharpen",     self.var_sharpen,    0,   5,   1,    "%d")

        # Transform
        self._section(ctrl, "Transform")
        row1 = tk.Frame(ctrl, bg="#1e1e2e"); row1.pack(fill="x", pady=2)
        tk.Button(row1, text="↺ Putar Kiri",  command=lambda: self._rotate(-90), **self._btn_style()).pack(side="left", expand=True, fill="x", padx=(0,3))
        tk.Button(row1, text="↻ Putar Kanan", command=lambda: self._rotate(90),  **self._btn_style()).pack(side="right", expand=True, fill="x")
        row2 = tk.Frame(ctrl, bg="#1e1e2e"); row2.pack(fill="x", pady=2)
        tk.Button(row2, text="⇔ Flip H", command=lambda: self._flip("h"), **self._btn_style()).pack(side="left", expand=True, fill="x", padx=(0,3))
        tk.Button(row2, text="⇕ Flip V", command=lambda: self._flip("v"), **self._btn_style()).pack(side="right", expand=True, fill="x")

        # Crop
        self._section(ctrl, "Crop")
        self.btn_crop_start  = tk.Button(ctrl, text="✂ Mulai Crop",  command=self._toggle_crop,  **self._btn_primary())
        self.btn_crop_apply  = tk.Button(ctrl, text="✔ Terapkan Crop", command=self._apply_crop, **self._btn_primary())
        self.btn_crop_cancel = tk.Button(ctrl, text="✖ Batal Crop",  command=self._cancel_crop,  **self._btn_danger())
        self.btn_crop_start.pack(fill="x", pady=2)
        self.crop_hint = tk.Label(ctrl, text="Klik & seret pada gambar untuk memilih area crop",
                                  font=("Segoe UI", 9), bg="#1e1e2e", fg="#f9e2af", wraplength=260)

        # Actions
        self._section(ctrl, "Aksi")
        row3 = tk.Frame(ctrl, bg="#1e1e2e"); row3.pack(fill="x", pady=2)
        tk.Button(row3, text="↺ Reset", command=self._reset_all, **self._btn_danger()).pack(side="left", expand=True, fill="x", padx=(0,3))
        tk.Button(row3, text="💾 Simpan", command=self._save_image, **self._btn_primary()).pack(side="right", expand=True, fill="x")

    def _section(self, parent, label):
        tk.Label(parent, text=label.upper(), font=("Segoe UI", 8, "bold"),
                 bg="#1e1e2e", fg="#6c7086").pack(anchor="w", pady=(10, 3))

    def _btn_style(self):
        return dict(bg="#313244", fg="#cdd6f4", font=("Segoe UI", 9),
                    relief="flat", activebackground="#45475a", activeforeground="#cdd6f4",
                    padx=6, pady=5, cursor="hand2", bd=0)

    def _btn_primary(self):
        return dict(bg="#1e66f5", fg="#ffffff", font=("Segoe UI", 9, "bold"),
                    relief="flat", activebackground="#3b7bf6", activeforeground="#ffffff",
                    padx=6, pady=5, cursor="hand2", bd=0)

    def _btn_danger(self):
        return dict(bg="#f38ba8", fg="#1e1e2e", font=("Segoe UI", 9, "bold"),
                    relief="flat", activebackground="#f5a3b5", activeforeground="#1e1e2e",
                    padx=6, pady=5, cursor="hand2", bd=0)

    def _build_preset_buttons(self, parent):
        grid = tk.Frame(parent, bg="#1e1e2e")
        grid.pack(fill="x", pady=2)
        self.preset_buttons = {}
        presets = list(PRESETS.keys())
        for i, name in enumerate(presets):
            row, col = divmod(i, 2)
            btn = tk.Button(grid, text=name, command=lambda n=name: self._apply_preset(n),
                            bg="#313244", fg="#cdd6f4", font=("Segoe UI", 9),
                            relief="flat", activebackground="#45475a", activeforeground="#cdd6f4",
                            pady=5, cursor="hand2", bd=0)
            btn.grid(row=row, column=col, padx=2, pady=2, sticky="ew")
            grid.columnconfigure(col, weight=1)
            self.preset_buttons[name] = btn
        self._highlight_preset("Normal")

    def _highlight_preset(self, name):
        for n, btn in self.preset_buttons.items():
            if n == name:
                btn.configure(bg="#1e66f5", fg="#ffffff")
            else:
                btn.configure(bg="#313244", fg="#cdd6f4")

    def _slider(self, parent, label, variable, from_, to, resolution, fmt):
        frame = tk.Frame(parent, bg="#313244", padx=8, pady=6)
        frame.pack(fill="x", pady=2)
        header = tk.Frame(frame, bg="#313244")
        header.pack(fill="x")
        tk.Label(header, text=label, font=("Segoe UI", 9), bg="#313244", fg="#cdd6f4").pack(side="left")
        val_lbl = tk.Label(header, text=fmt % variable.get(),
                           font=("Segoe UI", 9, "bold"), bg="#313244", fg="#89b4fa")
        val_lbl.pack(side="right")

        def on_change(*_):
            val_lbl.configure(text=fmt % variable.get())
            self._render()

        scale = ttk.Scale(frame, from_=from_, to=to, variable=variable,
                          orient="horizontal", command=on_change)
        scale.pack(fill="x", pady=(4, 0))

    # ── Image Operations ─────────────────────────

    def _open_image(self):
        path = filedialog.askopenfilename(
            title="Pilih Foto",
            filetypes=[("Gambar", "*.jpg *.jpeg *.png *.webp *.bmp *.gif"), ("Semua", "*.*")]
        )
        if not path:
            return
        try:
            img = Image.open(path).convert("RGBA")
            self.original_image = img
            self.working_image = img.copy()
            self.rotation = 0
            self.flip_h = False
            self.flip_v = False
            self._reset_sliders()
            self._apply_preset("Normal")
            fname = os.path.basename(path)
            self._update_info(f"{fname}  —  {img.width}×{img.height} px")
            self._render()
        except Exception as e:
            messagebox.showerror("Error", f"Gagal membuka gambar:\n{e}")

    def _apply_preset(self, name: str):
        self.current_preset = name
        self._highlight_preset(name)
        p = PRESETS[name]
        self.var_brightness.set(p["brightness"])
        self.var_contrast.set(p["contrast"])
        self.var_saturation.set(p["saturation"])
        self.var_blur.set(p["blur"])
        self.var_sharpen.set(p["sharpen"])
        # Refresh label slider
        self._render()

    def _rotate(self, deg: int):
        if self.working_image is None:
            return
        self.rotation = (self.rotation + deg) % 360
        self._render()

    def _flip(self, direction: str):
        if self.working_image is None:
            return
        if direction == "h":
            self.flip_h = not self.flip_h
        else:
            self.flip_v = not self.flip_v
        self._render()

    def _reset_sliders(self):
        self.var_brightness.set(1.0)
        self.var_contrast.set(1.0)
        self.var_saturation.set(1.0)
        self.var_blur.set(0)
        self.var_sharpen.set(0)

    def _reset_all(self):
        if self.original_image is None:
            return
        self.working_image = self.original_image.copy()
        self.rotation = 0
        self.flip_h = False
        self.flip_v = False
        self._reset_sliders()
        self._apply_preset("Normal")
        w, h = self.original_image.size
        self._update_info(f"Reset ke foto asli — {w}×{h} px")
        self._cancel_crop()
        self._render()

    def _save_image(self):
        if self.working_image is None:
            messagebox.showwarning("Peringatan", "Belum ada foto yang diupload!")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg"), ("WebP", "*.webp")],
            initialfile="foto-edit"
        )
        if not path:
            return
        try:
            result = self._get_processed_image()
            result.convert("RGB").save(path)
            self._update_info(f"Tersimpan: {os.path.basename(path)}")
            messagebox.showinfo("Sukses", f"Foto berhasil disimpan!\n{path}")
        except Exception as e:
            messagebox.showerror("Error", f"Gagal menyimpan:\n{e}")

    def _get_processed_image(self) -> Image.Image:
        """Proses dan kembalikan gambar hasil edit."""
        preset = PRESETS.get(self.current_preset, PRESETS["Normal"])
        return process_image(
            base_img=self.working_image,
            brightness=self.var_brightness.get(),
            contrast=self.var_contrast.get(),
            saturation=self.var_saturation.get(),
            blur=self.var_blur.get(),
            sharpen=self.var_sharpen.get(),
            mode=preset.get("mode"),
            rotation=self.rotation,
            flip_h=self.flip_h,
            flip_v=self.flip_v,
        )

    # ── Crop ────────────────────────────────────

    def _toggle_crop(self):
        if self.working_image is None:
            return
        self.crop_mode = True
        self.crop_start = None
        self.btn_crop_start.pack_forget()
        self.btn_crop_apply.pack(fill="x", pady=2)
        self.btn_crop_cancel.pack(fill="x", pady=2)
        self.crop_hint.pack(fill="x", pady=2)
        self.canvas.configure(cursor="crosshair")

    def _cancel_crop(self):
        self.crop_mode = False
        self.crop_start = None
        if self.crop_rect_id:
            self.canvas.delete(self.crop_rect_id)
            self.crop_rect_id = None
        self.btn_crop_apply.pack_forget()
        self.btn_crop_cancel.pack_forget()
        self.crop_hint.pack_forget()
        self.btn_crop_start.pack(fill="x", pady=2)
        self.canvas.configure(cursor="arrow")

    def _crop_start(self, event):
        if not self.crop_mode:
            return
        self.crop_start = (event.x, event.y)
        if self.crop_rect_id:
            self.canvas.delete(self.crop_rect_id)
            self.crop_rect_id = None

    def _crop_drag(self, event):
        if not self.crop_mode or self.crop_start is None:
            return
        if self.crop_rect_id:
            self.canvas.delete(self.crop_rect_id)
        x0, y0 = self.crop_start
        self.crop_rect_id = self.canvas.create_rectangle(
            x0, y0, event.x, event.y,
            outline="#89b4fa", width=2, dash=(6, 3)
        )
        self.crop_end = (event.x, event.y)

    def _crop_end(self, event):
        if not self.crop_mode:
            return
        self.crop_end = (event.x, event.y)

    def _apply_crop(self):
        if not hasattr(self, "crop_end") or self.crop_start is None or self.working_image is None:
            self._cancel_crop()
            return
        # Koordinat di canvas
        cx0 = min(self.crop_start[0], self.crop_end[0])
        cy0 = min(self.crop_start[1], self.crop_end[1])
        cx1 = max(self.crop_start[0], self.crop_end[0])
        cy1 = max(self.crop_start[1], self.crop_end[1])
        if (cx1 - cx0) < 10 or (cy1 - cy0) < 10:
            self._cancel_crop()
            return

        # Skala dari canvas ke gambar asli
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        processed = self._get_processed_image()
        pw, ph = processed.size
        scale_x = pw / cw
        scale_y = ph / ch

        # Offset jika ada padding (gambar lebih kecil dari canvas)
        offset_x = (cw - pw / max(scale_x, 1)) / 2 if pw < cw else 0
        offset_y = (ch - ph / max(scale_y, 1)) / 2 if ph < ch else 0

        ix0 = max(0, int((cx0 - offset_x) * scale_x))
        iy0 = max(0, int((cy0 - offset_y) * scale_y))
        ix1 = min(pw, int((cx1 - offset_x) * scale_x))
        iy1 = min(ph, int((cy1 - offset_y) * scale_y))

        if (ix1 - ix0) < 5 or (iy1 - iy0) < 5:
            self._cancel_crop()
            return

        cropped = processed.crop((ix0, iy0, ix1, iy1))
        self.working_image = cropped
        # Reset transform karena sudah di-apply
        self.rotation = 0
        self.flip_h = False
        self.flip_v = False
        self._reset_sliders()
        self._apply_preset("Normal")
        self._update_info(f"Crop diterapkan — {cropped.width}×{cropped.height} px")
        self._cancel_crop()
        self._render()

    # ── Render ──────────────────────────────────

    def _render(self, *_):
        if self.working_image is None:
            self._draw_placeholder()
            return
        try:
            result = self._get_processed_image()
            # Fit ke canvas
            cw = self.canvas.winfo_width() or 600
            ch = self.canvas.winfo_height() or 460
            result.thumbnail((cw, ch), Image.LANCZOS)
            self.display_photo = ImageTk.PhotoImage(result)
            self.canvas.delete("all")
            x = cw // 2
            y = ch // 2
            self.canvas.create_image(x, y, anchor="center", image=self.display_photo)
        except Exception as e:
            self._update_info(f"Error render: {e}")

    def _draw_placeholder(self):
        self.canvas.delete("all")
        cw = self.canvas.winfo_width() or 600
        ch = self.canvas.winfo_height() or 460
        self.canvas.create_text(cw//2, ch//2 - 20,
            text="📷", font=("Segoe UI", 48), fill="#45475a")
        self.canvas.create_text(cw//2, ch//2 + 40,
            text="Upload foto untuk memulai\nKlik  📂 Buka Foto  di panel kanan",
            font=("Segoe UI", 11), fill="#6c7086", justify="center")

    def _on_canvas_resize(self, event):
        if self.working_image:
            self._render()
        else:
            self._draw_placeholder()

    def _update_info(self, text: str):
        self.info_var.set(text)


# ──────────────────────────────────────────────
#  ENTRY POINT
# ──────────────────────────────────────────────

if __name__ == "__main__":
    root = tk.Tk()

    # Style
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("Horizontal.TScale",
                    background="#313244",
                    troughcolor="#45475a",
                    sliderlength=14)

    app = PhotoEditorApp(root)
    root.mainloop()
