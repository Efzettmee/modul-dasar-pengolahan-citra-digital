# 📷 Photo Editor Pro — Proyek PCD (Pengolahan Citra Digital)

## Deskripsi
Aplikasi desktop editor foto berbasis Python menggunakan **Tkinter** (GUI) dan **Pillow** (image processing).
Dibuat sebagai implementasi Python dari desain HTML Photo Editor Pro.

---

## Fitur

### Filter Efek (10 preset)
| Filter     | Keterangan |
|------------|------------|
| Normal     | Foto asli tanpa efek |
| Grayscale  | Konversi ke skala abu-abu |
| Sepia      | Tone coklat klasik (matriks transformasi RGB) |
| Invert     | Warna dibalik (negatif foto) |
| Warm       | Tambah merah +20, kurangi biru -15 |
| Cool       | Tambah biru +20, kurangi merah -10 |
| Vivid      | Saturasi & kontras tinggi |
| Edge Detect | Deteksi tepi (Sobel operator) |
| Emboss     | Efek timbul/relief |
| Fade       | Kesan foto pudar/matte |

### Penyesuaian (Sliders)
- **Brightness** — Kecerahan (0.0 – 2.0)
- **Contrast** — Kontras (0.0 – 2.0)
- **Saturation** — Kejenuhan warna (0.0 – 2.0)
- **Blur** — Kekaburan Gaussian (0 – 20)
- **Sharpen** — Ketajaman UnsharpMask (0 – 5)

### Transform
- Rotasi kiri / kanan (90°)
- Flip horizontal / vertikal

### Crop
- Pilih area dengan klik & seret
- Terapkan atau batalkan crop

### File
- Buka: JPG, PNG, WEBP, BMP, GIF
- Simpan: PNG, JPG, WEBP

---

## Cara Menjalankan

### 1. Install dependensi
```bash
pip install -r requirements.txt
```

### 2. Jalankan aplikasi
```bash
python photo_editor_pro.py
```

---

## Struktur Kode

```
photo_editor_pro.py
├── FUNGSI PEMROSESAN CITRA
│   ├── apply_sepia()          # Matriks transformasi warna sepia
│   ├── apply_warm()           # Shift channel R dan B
│   ├── apply_cool()           # Shift channel B dan R
│   ├── apply_sobel_fast()     # Deteksi tepi dengan PIL FIND_EDGES
│   ├── apply_emboss()         # Filter emboss PIL
│   ├── apply_sharpen_level()  # UnsharpMask bertingkat
│   ├── process_image()        # Pipeline pemrosesan utama
│   └── _transform()           # Rotasi & flip
│
└── CLASS PhotoEditorApp (GUI Tkinter)
    ├── _build_ui()            # Membangun antarmuka
    ├── _open_image()          # Membuka file gambar
    ├── _apply_preset()        # Menerapkan preset filter
    ├── _rotate() / _flip()    # Transform gambar
    ├── _toggle_crop()         # Mode crop
    ├── _apply_crop()          # Eksekusi crop
    ├── _render()              # Update tampilan canvas
    └── _save_image()          # Menyimpan hasil edit
```

---

## Konsep PCD yang Diterapkan

1. **Konversi ruang warna** — RGB ↔ Grayscale, transformasi Sepia
2. **Operator Sobel** — Deteksi tepi (gradient magnitude)
3. **Konvolusi kernel** — Emboss, Sharpen (UnsharpMask)
4. **Transformasi geometri** — Rotasi, Flip, Crop
5. **Peningkatan citra** — Brightness, Contrast, Saturation, Blur

---

## Dependensi
- `Python 3.10+`
- `Pillow` — Pemrosesan gambar
- `numpy` — Operasi array untuk filter manual
- `tkinter` — GUI (sudah termasuk di Python standar)
