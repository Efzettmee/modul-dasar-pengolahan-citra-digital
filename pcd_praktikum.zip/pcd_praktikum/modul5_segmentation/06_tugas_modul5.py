import cv2
import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import KMeans
import os

# ============================================
# TUGAS MODUL 5: PRAKTIK MANDIRI
# ============================================
print("=" * 50)
print("TUGAS MODUL 5: PRAKTIK MANDIRI")
print("=" * 50)

# Baca gambar berwarna menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
citra_gray = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# TUGAS 1: Segmentasi Wajah dengan Thresholding
# ============================================
print("\n[TUGAS 1] Segmentasi Area Wajah dengan Thresholding")
print("Mencari nilai T optimal untuk isolasi wilayah wajah...")

thresholds_wajah = [100, 120, 140, 160, 180]
hasil_wajah = []

for T in thresholds_wajah:
    _, thresh = cv2.threshold(citra_gray, T, 255, cv2.THRESH_BINARY)
    hasil_wajah.append(thresh)

plt.figure(figsize=(15, 10))
plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("Original")
plt.axis('off')

for i, (T, hasil) in enumerate(zip(thresholds_wajah, hasil_wajah), 2):
    plt.subplot(2, 3, i)
    plt.imshow(hasil, cmap='gray')
    plt.title(f"Threshold T = {T}")
    plt.axis('off')

plt.suptitle("TUGAS 1: Mencari Threshold Optimal untuk Segmentasi Wajah", fontsize=16)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Threshold berapa yang paling baik memisahkan wajah dari background?")
print("Jawab: T = 120 atau T = 140 (tergantung kondisi pencahayaan foto asli).")
print("Mengapa? Karena nilai pertengahan ini berada di antara intensitas latar belakang")
print("yang redup dan area kulit wajah yang terang. Jika T terlalu rendah (T=100),")
print("latar belakang ikut tersapu menjadi putih. Jika T terlalu tinggi (T=180),")
print("area wajah akan berlubang dan didominasi warna hitam.")

# ============================================
# TUGAS 2: Segmentasi dengan K-Means (Ekstrak Warna Kulit)
# ============================================
print("\n[TUGAS 2] Ekstraksi Warna Kulit dengan K-Means")

h, w, c = citra_rgb.shape
piksel = citra_rgb.reshape(-1, 3)

# Jalankan model Machine Learning K-Means dengan 5 kelompok warna
kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
labels = kmeans.fit_predict(piksel)
centroids = kmeans.cluster_centers_.astype(np.uint8)

# Identifikasi cluster yang paling mendekati standar warna kulit manusia (RGB: 200, 150, 100)
warna_kulit_ref = [200, 150, 100]
# Menghitung jarak Euclidean (L2 Norm) antara pusat klaster dan referensi warna kulit
jarak = [np.linalg.norm(centroid - warna_kulit_ref) for centroid in centroids]
cluster_kulit = np.argmin(jarak)

# Buat masker biner untuk mengisolasi klaster kulit tersebut
mask = (labels == cluster_kulit).reshape(h, w)
kulit_only = np.zeros_like(citra_rgb)
kulit_only[mask] = citra_rgb[mask]

plt.figure(figsize=(12, 8))
plt.subplot(2, 2, 1)
plt.imshow(citra_rgb)
plt.title("Original")
plt.axis('off')

plt.subplot(2, 2, 2)
# Tampilkan palet warna representatif
palet = np.zeros((50, 5 * 50, 3), dtype=np.uint8)
for i, warna in enumerate(centroids):
    palet[:, i * 50:(i + 1) * 50, :] = warna
plt.imshow(palet)
plt.title("Palet 5 Warna Dominan")
plt.axis('off')

plt.subplot(2, 2, 3)
plt.imshow(mask, cmap='gray')
plt.title(f"Mask Warna Kulit (Cluster {cluster_kulit})")
plt.axis('off')

plt.subplot(2, 2, 4)
plt.imshow(kulit_only)
plt.title("Ekstraksi Area Warna Kulit")
plt.axis('off')

plt.suptitle("TUGAS 2: Ekstraksi Warna Kulit dengan K-Means Clustering", fontsize=16)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Apakah ekstraksi warna kulit berhasil?")
print("Jawab: Ya, berhasil dengan sangat baik.")
print("Analisis: Berbeda dengan thresholding grayscale yang mudah terkecoh bayangan,")
print("K-Means mengelompokkan piksel langsung di ruang warna 3D (RGB). Dengan mencari")
print("jarak koordinat terdekat dari pusat klaster ke vektor acuan kulit, AI berhasil")
print("mengisolasi piksel kulit wajah dan tangan secara utuh sekaligus menyingkirkan")
print("warna latar belakang.")

# ============================================
# TUGAS 3: Deteksi dan Hitung Objek Sederhana
# ============================================
print("\n[TUGAS 3] Deteksi dan Hitung Objek Otomatis")

# Pembuatan gambar simulasi koin geometri
gambar_koin = np.zeros((300, 500, 3), dtype=np.uint8)
cv2.circle(gambar_koin, (100, 150), 40, (255, 255, 255), -1)
cv2.circle(gambar_koin, (200, 150), 35, (255, 255, 255), -1)
cv2.circle(gambar_koin, (300, 150), 45, (255, 255, 255), -1)
cv2.circle(gambar_koin, (400, 150), 30, (255, 255, 255), -1)
cv2.rectangle(gambar_koin, (50, 220), (150, 280), (255, 255, 255), -1)
gambar_koin_gray = cv2.cvtColor(gambar_koin, cv2.COLOR_BGR2GRAY)

# Segmentasi biner dan penelusuran garis kontur
_, binary_koin = cv2.threshold(gambar_koin_gray, 127, 255, cv2.THRESH_BINARY)
contours_koin, _ = cv2.findContours(binary_koin, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

hasil_koin = gambar_koin.copy()
for cnt in contours_koin:
    area = cv2.contourArea(cnt)
    if area > 100:  # Filter threshold untuk mengeliminasi noise bintik kecil
        x, y, w_box, h_box = cv2.boundingRect(cnt)
        cv2.rectangle(hasil_koin, (x, y), (x + w_box, y + h_box), (0, 255, 0), 2)
        cv2.putText(hasil_koin, str(int(area)), (x, y - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.imshow(gambar_koin)
plt.title("Gambar Objek (4 Lingkaran + 1 Persegi)")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(hasil_koin)
plt.title(f"Deteksi Objek: {len(contours_koin)} Objek Sukses\n(Luas area ditampilkan)")
plt.axis('off')

plt.suptitle("TUGAS 3: Otomatisasi Object Counting via Kontur", fontsize=16)
plt.tight_layout()
plt.show()

print(f"\nJumlah objek terdeteksi di layar: {len(contours_koin)}")
print("Pertanyaan: Apakah semua objek terdeteksi dengan benar tanpa hitung ganda?")
print("Jawab: Ya, 100% terdeteksi dengan sangat akurat (4 lingkaran dan 1 persegi")
print("panjang terhitung sebagai 5 objek terpisah).")
print("Analisis: Hal ini terjadi karena objek berada di atas latar belakang hitam")
print("kontras dan letaknya saling terpisah (tidak menempel). Mode pencarian")
print("'RETR_EXTERNAL' memastikan hanya batas luar dinding objek saja yang dihitung")
print("sehingga terhindar dari resiko hitung ganda (double counting).")

# ============================================
# TUGAS 4: Simpan hasil segmentasi terbaik
# ============================================
print("\n[TUGAS 4] Simpan Hasil Segmentasi Terbaik")

folder_output = 'hasil_output'
os.makedirs(folder_output, exist_ok=True)

# Rekonstruksi gambar menggunakan hasil KMeans dari Tugas 2 (tanpa fit ulang)
# Ganti setiap piksel dengan warna pusat klasternya
segmented_best = centroids[labels].reshape(h, w, 3)

path_simpan = os.path.join(folder_output, 'modul5_segmentasi_k5.jpg')
# Mengonversi format urutan RGB ke BGR sebelum diekspor ke harddisk via OpenCV
cv2.imwrite(path_simpan, cv2.cvtColor(segmented_best, cv2.COLOR_RGB2BGR))
print(f"Berhasil! Foto kompresi segmentasi disimpan di: {path_simpan}")

plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.imshow(citra_rgb)
plt.title("Original")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(segmented_best)
plt.title("Hasil Segmentasi Terbaik (K-Means K=5)")
plt.axis('off')

plt.suptitle("TUGAS 4: Ekspor Gambar Komputasi Hasil Cluster", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# RINGKASAN MODUL 5
# ============================================
print("\n" + "=" * 50)
print("RINGKASAN MODUL 5")
print("=" * 50)
print("\nKonsep Kompetensi yang Sudah Dikuasai:")
print("1. Thresholding (Global, otomatisasi Otsu, dan lokalisasi Adaptive).")
print("2. K-Means Clustering (Segmentasi berbasis klaster jarak warna RGB 3D).")
print("3. Kontur (Deteksi kalkulasi luas, keliling, dan pusat koordinat objek).")
print("4. Algoritma Watershed (Pemisah cerdas untuk objek bertumpuk/menempel).")

print("\nPanduan Logika Pemilihan Strategi Segmentasi Citra:")
print(" Pencahayaan merata & latar belakang kontras  --> Terapkan Thresholding + Otsu.")
print(" Foto terkena bayangan/pencahayaan buruk      --> Terapkan Adaptive Thresholding.")
print(" Segmentasi objek berdasarkan warna asli      --> Terapkan K-Means Clustering.")
print(" Butuh ekstraksi ukuran bentuk & hitung barang--> Terapkan Kontur + Area Filtering.")
print(" Komponen objek padat dan saling bertumpukan  --> Terapkan Watershed Algorithm.")

print("\nSELURUH MODUL PRAKTIKUM PENGOLAHAN CITRA DIGITAL (PCD) SELESAI!")