import cv2
import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import KMeans

# ============================================
# MODUL 5: K-MEANS CLUSTERING SEGMENTATION
# ============================================
print("=" * 50)
print("MODUL 5: SEGMENTASI DENGAN K-MEANS CLUSTERING")
print("=" * 50)

# Baca gambar berwarna menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
print(f"Dimensi gambar asli: {citra_rgb.shape}")

# ============================================
# KONSEP K-MEANS UNTUK SEGMENTASI
# ============================================
print("\n[KONSEP K-MEANS CLUSTERING]")
print("-" * 40)
print("Setiap piksel memiliki 3 nilai (R, G, B) = titik koordinat dalam ruang 3D")
print("K-Means mengelompokkan piksel yang mirip ke dalam K kelompok (klaster)")
print("Every pixel diganti dengan warna pusat (centroid) klasternya")
print("Hasil: gambar terbagi menjadi K warna dominan murni")

# ============================================
# PERSIAPAN DATA
# ============================================
# Mengubah matriks gambar 3D (H, W, 3) menjadi array 2D (H*W, 3) agar bisa dibaca model ML
h, w, c = citra_rgb.shape
piksel = citra_rgb.reshape(-1, 3)
print(f"\nJumlah total piksel data: {piksel.shape[0]}")
print(f"Setiap komponen piksel memiliki {piksel.shape[1]} nilai fitur (R, G, B)")

# ============================================
# K-MEANS DENGAN BERBAGAI NILAI K
# ============================================
print("\n[EKSPLORASI NILAI K (JUMLAH CLUSTER)]")
K_values = [2, 3, 4, 5, 6, 8, 10]
segmented_images = []
centroids_list = []

for K in K_values:
    print(f"Memproses kalkulasi klaster untuk K={K}...")
    # Jalankan algoritma K-Means Machine Learning
    kmeans = KMeans(n_clusters=K, random_state=42, n_init=10)
    labels = kmeans.fit_predict(piksel)
    centroids = kmeans.cluster_centers_
    
    # Rekonstruksi array kembali ke dimensi gambar asli (H, W, 3)
    segmented = centroids[labels].reshape(h, w, 3).astype(np.uint8)
    segmented_images.append(segmented)
    centroids_list.append(centroids)

# ============================================
# TAMPILKAN HASIL SEGMENTASI (Jendela 1)
# ============================================
plt.figure(figsize=(18, 12))

# Tampilkan foto original pada slot pertama
plt.subplot(2, 4, 1)
plt.imshow(citra_rgb)
plt.title("Original (Full Color)")
plt.axis('off')

# Looping untuk menampilkan ke-7 variasi nilai K pada slot berikutnya
for i, (K, segmented) in enumerate(zip(K_values, segmented_images), 2):
    plt.subplot(2, 4, i)
    plt.imshow(segmented)
    plt.title(f"K-Means K = {K}")
    plt.axis('off')

plt.suptitle("Segmentasi Citra menggunakan K-Means Clustering (Berbagai Nilai K)", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# ANALISIS WARNA DOMINAN (Jendela 2)
# ============================================
print("\n" + "=" * 50)
print("[ANALISIS WARNA DOMINAN]")
print("=" * 50)

# Kita ambil sampel kasus mendalam untuk nilai K = 5
kmeans_5 = KMeans(n_clusters=5, random_state=42, n_init=10)
labels_5 = kmeans_5.fit_predict(piksel)
centroids_5 = kmeans_5.cluster_centers_.astype(np.uint8)

# Menghitung distribusi persentase jumlah piksel yang masuk ke setiap cluster
unique, counts = np.unique(labels_5, return_counts=True)
persentase = counts / counts.sum() * 100

# Mengurutkan index warna dari yang paling mendominasi layar
sorted_idx = np.argsort(persentase)[::-1]

print("\nDaftar 5 Warna Dominan yang Ditemukan AI:")
for i, idx in enumerate(sorted_idx):
    warna = centroids_5[idx]
    persen = persentase[idx]
    print(f" {i+1}. Kode RGB {list(warna)} → Menguasai {persen:.1f}% area gambar")

# Visualisasi Palet dan Diagram Proporsi
plt.figure(figsize=(12, 4))

# Subplot 1: Batang Palet Warna
warna_bar = np.zeros((50, len(centroids_5), 3), dtype=np.uint8)
for i, idx in enumerate(sorted_idx):
    warna_bar[:, i, :] = centroids_5[idx]

plt.subplot(1, 2, 1)
plt.imshow(warna_bar)
plt.title("Palet 5 Warna Paling Dominan")
plt.axis('off')

# Subplot 2: Pie Chart Distribusi
plt.subplot(1, 2, 2)
plt.pie(counts[sorted_idx], labels=[f"Warna {i+1}" for i in range(5)],
        colors=centroids_5[sorted_idx]/255, autopct='%1.1f%%', startangle=90)
plt.title("Proporsi Penyebaran Warna")

plt.suptitle("Ekstraksi Palet Warna Dominan dengan K-Means (K=5)", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# PERBANDINGAN DENGAN THRESHOLDING (Jendela 3)
# ============================================
print("\n" + "=" * 50)
print("[PERBANDINGAN K-MEANS vs THRESHOLDING]")
print("=" * 50)

# Eksekusi thresholding biasa berbasis intensitas abu-abu
citra_gray = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)
ret, thresh = cv2.threshold(citra_gray, 127, 255, cv2.THRESH_BINARY)

# Eksekusi K-Means K=2 (Sama-sama membagi gambar menjadi 2 warna)
kmeans_2 = KMeans(n_clusters=2, random_state=42, n_init=10)
labels_2 = kmeans_2.fit_predict(piksel)
segmented_2 = kmeans_2.cluster_centers_[labels_2].reshape(h, w, 3).astype(np.uint8)

plt.figure(figsize=(14, 5))

plt.subplot(1, 3, 1)
plt.imshow(citra_rgb)
plt.title("1. Original")
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(thresh, cmap='gray')
plt.title("2. Thresholding Global (Grayscale)\n(Berdasarkan gelap-terang cahaya)")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(segmented_2)
plt.title("3. K-Means K=2 (Color Space)\n(Berdasarkan kemiripan warna RGB)")
plt.axis('off')

plt.suptitle("Perbandingan Paradigma: Thresholding vs K-Means Clustering", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN PERBANDINGAN KEDUA METODE]")
print("-" * 50)
print("Metode Thresholding:")
print(" ➡️ Hanya menganalisis 1 channel nilai (Gelap-Terang).")
print(" ➡️ Komputasi sangat kilat dan sangat sederhana.")
print(" ➡️ Kelemahan: Gagal memisahkan dua benda yang warnanya beda tapi kebetulan punya tingkat kusam yang sama.")
print("\nMetode K-Means Clustering:")
print(" ➡️ Menganalisis 3 channel warna sekaligus secara utuh (Red, Green, Blue).")
print(" ➡️ Jauh lebih cerdas dan akurat untuk memisahkan objek berdasarkan klaster warna asli benda.")
print(" ➡️ Sukses memisahkan dua objek sewarna meskipun kondisi pencahayaannya berubah.")
print("\n🎉 Modul 5 - Bagian 3 selesai dengan sempurna! 🎉")