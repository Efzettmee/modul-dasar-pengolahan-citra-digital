import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 5: ADAPTIVE THRESHOLDING
# ============================================
print("=" * 50)
print("MODUL 5: ADAPTIVE THRESHOLDING")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# MENGAPA PERLU ADAPTIVE THRESHOLDING?
# ============================================
print("\n[MASALAH THRESHOLDING GLOBAL]")
print("Thresholding global (satu nilai T untuk seluruh gambar)")
print("Tidak cocok untuk gambar dengan pencahayaan tidak merata")

# Simulasi: Buat efek kerusakan pencahayaan gradien (gelap di kiri, terang di kanan)
gradien = np.linspace(0.3, 1.5, citra.shape[1])
gradien_2d = np.tile(gradien, (citra.shape[0], 1))
citra_gradien = np.clip(citra.astype(np.float32) * gradien_2d, 0, 255).astype(np.uint8)
print("Membuat simulasi gambar dengan pencahayaan tidak merata...")

# Uji coba: Thresholding global standar pada gambar yang rusak pencahayaannya
ret_global, global_thresh = cv2.threshold(citra_gradien, 127, 255, cv2.THRESH_BINARY)

# ============================================
# IMPLEMENTASI ADAPTIVE THRESHOLDING
# ============================================
print("\n[ADAPTIVE THRESHOLDING]")
print("Threshold berbeda untuk setiap region gambar")
print("Berdasarkan rata-rata atau median dari tetangga")

# 1. Adaptive Mean (Ambang batas berdasarkan rata-rata lokal)
adaptive_mean = cv2.adaptiveThreshold(
    citra_gradien, 255,
    cv2.ADAPTIVE_THRESH_MEAN_C,
    cv2.THRESH_BINARY,
    11, # Block Size: Ukuran area bertetangga (wajib ganjil)
    2   # Constant C: Nilai pengurang hasil rata-rata
)

# 2. Adaptive Gaussian (Ambang batas berdasarkan distribusi Gaussian lokal)
adaptive_gaussian = cv2.adaptiveThreshold(
    citra_gradien, 255,
    cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
    cv2.THRESH_BINARY,
    11, # Block Size
    2   # Constant C
)

# ============================================
# PENGARUH BLOCK SIZE
# ============================================
print("\n[PENGARUH BLOCK SIZE]")
block_sizes = [3, 11, 31, 51]
adaptive_variasi = []

for bs in block_sizes:
    hasil = cv2.adaptiveThreshold(
        citra_gradien, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        bs, 2
    )
    adaptive_variasi.append(hasil)

# ============================================
# TAMPILKAN HASIL PERBANDINGAN
# ============================================
plt.figure(figsize=(15, 14))

# Baris 1: Masalah Utama (Global Thresholding Gagal)
plt.subplot(3, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("1. Original (Pencahayaan Normal)")
plt.axis('off')

plt.subplot(3, 3, 2)
plt.imshow(citra_gradien, cmap='gray')
plt.title("2. Simulasi Gradien Cahaya\n(Gelap di kiri, terang di kanan)")
plt.axis('off')

plt.subplot(3, 3, 3)
plt.imshow(global_thresh, cmap='gray')
plt.title("3. Global Threshold (GAGAL!)\n(Kiri terhapus hitam, kanan silau putih)")
plt.axis('off')

# Baris 2: Solusi Adaptive
plt.subplot(3, 3, 4)
plt.imshow(adaptive_mean, cmap='gray')
plt.title("4. Adaptive Mean\n(Berhasil merata, kontur keluar)")
plt.axis('off')

plt.subplot(3, 3, 5)
plt.imshow(adaptive_gaussian, cmap='gray')
plt.title("5. Adaptive Gaussian\n(Garis lebih bersih & halus)")
plt.axis('off')

# Baris 3: Eksplorasi Ukuran Jendela Tetangga (Block Size)
# Perulangan ini otomatis mengisi slot 6, 7, 8, dan 9 pada kanvas 3x3
for i, (bs, hasil) in enumerate(zip(block_sizes, adaptive_variasi)):
    plt.subplot(3, 3, 6 + i)
    plt.imshow(hasil, cmap='gray')
    plt.title(f"Block Size = {bs}")
    plt.axis('off')

plt.suptitle("Adaptive Thresholding: Solusi Pintar untuk Pencahayaan Tidak Merata", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN ADAPTIVE THRESHOLDING]")
print("-" * 40)
print("✅ Sukses mengatasi masalah bayangan/gradien pencahayaan buruk.")
print("✅ Block size kecil : Menangkap detail sangat halus, tapi rentan bercak noise kotor.")
print("✅ Block size besar : Hasil segmentasi lebih bersih, tapi detail kecil mulai pudar.")
print("✅ Adaptive Gaussian terbukti menghasilkan garis kontur yang lebih halus dibanding Adaptive Mean.")
print("\nℹ️ Aturan Parameter:")
print("- Block Size : Harus bernilai ganjil (3, 5, 7, dst.) sebagai ukuran jendela matriks lokal.")
print("- Constant C : Nilai konstanta kompensasi untuk menyaring piksel abu-abu samar.")
print("\n✅ Modul 5 - Bagian 2 selesai!")