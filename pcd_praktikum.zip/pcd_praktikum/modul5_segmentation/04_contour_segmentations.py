import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 5: SEGMENTASI DENGAN KONTUR
# ============================================
print("=" * 50)
print("MODUL 5: SEGMENTASI BERDASARKAN KONTUR")
print("=" * 50)

# Baca gambar berwarna menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

# Fallback: Jika tidak ada foto, buat gambar objek dummy geometri murni
if citra_bgr is None:
    print("Membuat gambar dengan objek sederhana...")
    citra_bgr = np.zeros((400, 400, 3), dtype=np.uint8)
    cv2.circle(citra_bgr, (200, 200), 100, (255, 255, 255), -1)
    cv2.rectangle(citra_bgr, (50, 50), (150, 150), (200, 200, 200), -1)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# LANGKAH SEGMENTASI DENGAN KONTUR
# ============================================
print("\n[LANGKAH-LANGKAH SEGMENTASI DENGAN KONTUR]")
print("1. Pre-processing (blur, thresholding biner)")
print("2. Ekstraksi garis batas dengan cv2.findContours()")
print("3. Analisis fitur kontur (luas, keliling, posisi tengah)")
print("4. Penyaringan (filtering) objek pengganggu")

# ============================================
# TAHAP 1: PRE-PROCESSING
# ============================================
print("\n[PRE-PROCESSING]")
# Blur untuk meredam noise mikro pencahayaan
blur = cv2.GaussianBlur(citra, (5, 5), 0)
# Algoritma kontur wajib menerima gambar biner murni (Otsu binarization)
ret, binary = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
print(f"Batas Ambang Otomatis Otsu: {ret:.2f}")

# ============================================
# TAHAP 2: FIND CONTOURS
# ============================================
print("\n[FIND CONTOURS]")
# contours: list berisi koordinat titik batas dari setiap objek
# RETR_EXTERNAL: mengabaikan lubang/kontur dalam, hanya mengambil batas terluar objek
contours, hierarchy = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
print(f"Jumlah kontur objek yang ditemukan: {len(contours)}")

# ============================================
# TAHAP 3: ANALISIS KONTUR (IMAGE MOMENTS)
# ============================================
print("\n[ANALISIS SETIAP KONTUR]")
citra_kontur = cv2.cvtColor(citra, cv2.COLOR_GRAY2RGB)
kontur_info = []

for i, cnt in enumerate(contours):
    # Hitung luas area di dalam kontur (jumlah piksel objek)
    area = cv2.contourArea(cnt)
    
    # Hitung keliling (perimeter) kontur
    perimeter = cv2.arcLength(cnt, True)
    
    # Dapatkan kotak pembatas (Bounding Box)
    x, y, w, h = cv2.boundingRect(cnt)
    
    # Hitung aspek rasio kotak
    aspect_ratio = w / h if h > 0 else 0
    
    # Hitung momen citra untuk mencari pusat massa (Centroid) objek
    M = cv2.moments(cnt)
    if M["m00"] != 0:
        cx = int(M["m10"] / M["m00"])
        cy = int(M["m01"] / M["m00"])
    else:
        cx, cy = 0, 0
        
    kontur_info.append({
        'index': i,
        'area': area,
        'perimeter': perimeter,
        'bbox': (x, y, w, h),
        'center': (cx, cy),
        'aspect_ratio': aspect_ratio
    })
    
    # BUG FIX: Disatukan dalam satu baris agar tidak memicu syntax error
    print(f"Objek {i}: Luas={area:.0f} px, Keliling={perimeter:.1f} px, Pusat=({cx},{cy})")

# ============================================
# TAHAP 4: VISUALISASI KONTUR AWAL
# ============================================
# Gambar garis luar kontur asli (Hijau)
cv2.drawContours(citra_kontur, contours, -1, (0, 255, 0), 2)

# Gambar komponen bounding box (Biru) dan titik pusat centroid (Merah)
for info in kontur_info:
    x, y, w, h = info['bbox']
    cx, cy = info['center']
    cv2.rectangle(citra_kontur, (x, y), (x+w, y+h), (255, 0, 0), 2)
    cv2.circle(citra_kontur, (cx, cy), 5, (0, 0, 255), -1)

plt.figure(figsize=(15, 10))
plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("1. Original Grayscale")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(blur, cmap='gray')
plt.title("2. Pre-processing: Blur")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(binary, cmap='gray')
plt.title("3. Biner (Otsu Threshold)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(citra_kontur)
plt.title("4. Ekstraksi Fitur Objek\n(Hijau:Kontur, Biru:Box, Merah:Pusat)")
plt.axis('off')

plt.suptitle("Pipeline Utama Segmentasi Deteksi Kontur", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# TAHAP 5: FILTER KONTUR BERDASARKAN LUAS
# ============================================
print("\n" + "=" * 50)
print("[FILTER KONTUR BERDASARKAN LUAS]")
print("=" * 50)

# Menentukan ambang luas minimum untuk menyaring bercak kecil / noise tak diinginkan
min_area = 500
kontur_besar = [cnt for cnt in contours if cv2.contourArea(cnt) > min_area]

print(f"Total kontur mentah      : {len(contours)}")
print(f"Kontur lolos filter (>{min_area}px): {len(kontur_besar)}")

# Gambar ulang hasil jepretan yang sudah bersih dari noise kecil
citra_filtered = cv2.cvtColor(citra, cv2.COLOR_GRAY2RGB)
cv2.drawContours(citra_filtered, kontur_besar, -1, (0, 255, 0), 2)

plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.imshow(citra_kontur)
plt.title("Semua Kontur Terdeteksi (Mentah)")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(citra_filtered)
plt.title(f"Hasil Akhir (Hanya Objek dengan Luas > {min_area} px)")
plt.axis('off')

plt.suptitle("Aplikasi Pembersihan Objek Pengganggu via Analisis Fitur Luas", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN METODE KONTUR]")
print("-" * 40)
print("✅ Kontur = Garis batas matematis pembungkus area putih pada gambar biner.")
print("✅ Bersifat kuantitatif: Bisa mengukur koordinat, luas, keliling secara eksak.")
print("✅ Ampuh untuk filter: Menghilangkan objek pengganggu (*noise*) dengan seleksi ukuran.")
print("➡️ Selesai!")