import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 5: WATERSHED ALGORITHM
# ============================================
print("=" * 50)
print("MODUL 5: WATERSHED ALGORITHM")
print("=" * 50)

# Buat simulasi gambar eksperimen: objek yang saling menempel
print("Membuat gambar dengan objek saling menempel...")
gambar_objek = np.zeros((400, 400, 3), dtype=np.uint8)

# Menggambar 3 lingkaran bertumpukan erat di tengah kanvas
cv2.circle(gambar_objek, (120, 200), 70, (255, 255, 255), -1)
cv2.circle(gambar_objek, (280, 200), 70, (255, 255, 255), -1)
cv2.circle(gambar_objek, (200, 280), 70, (255, 255, 255), -1)

# Tambahkan noise pasir halus agar simulasi terlihat riil
noise = np.random.randint(0, 50, gambar_objek.shape, dtype=np.uint8)
gambar_objek = cv2.add(gambar_objek, noise)
citra = cv2.cvtColor(gambar_objek, cv2.COLOR_BGR2GRAY)
print("Objek uji coba: 3 lingkaran yang saling menempel")

# ============================================
# MASALAH: KONTUR TIDAK BISA MEMISAHKAN OBJEK MENEMPEL
# ============================================
print("\n[MASALAH DENGAN KONTUR]")
print("Kontur biasa tidak bisa memisahkan objek yang saling menempel")

# Thresholding biner biasa
ret, binary = cv2.threshold(citra, 127, 255, cv2.THRESH_BINARY)

# Cari kontur terluar
contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
print(f"Kontur ditemukan: {len(contours)} (Padahal seharusnya ada 3 objek terpisah!)")

citra_kontur = cv2.cvtColor(citra, cv2.COLOR_GRAY2RGB)
cv2.drawContours(citra_kontur, contours, -1, (0, 255, 0), 2)

# ============================================
# SOLUSI: WATERSHED ALGORITHM PIPELINE
# ============================================
print("\n[WATERSHED ALGORITHM EXECUTION]")
print("Menggunakan konsep topografi permukaan bumi: air mengalir ke lembah")

# Langkah 1: Redam noise pasir dengan Gaussian Blur
blur = cv2.GaussianBlur(citra, (5, 5), 0)

# Langkah 2: Lakukan Otsu Thresholding
ret, thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Langkah 3: Menentukan area pasti latar belakang dan latar depan
# Dilasi melebarkan warna putih untuk memastikan batas terjauh background pasti
kernel = np.ones((3, 3), np.uint8)
background = cv2.dilate(thresh, kernel, iterations=3)

# Distance Transform menghitung jarak piksel putih ke piksel hitam terdekat
dist_transform = cv2.distanceTransform(thresh, cv2.DIST_L2, 5)
# Ambil puncak bukit terdalam (pusat core) sebagai objek foreground pasti
ret, foreground = cv2.threshold(dist_transform, 0.5 * dist_transform.max(), 255, 0)
foreground = np.uint8(foreground)

# Langkah 4: Mencari area abu-abu pembatas yang membingungkan (Unknown Region)
unknown = cv2.subtract(background, foreground)

# Langkah 5: Pembuatan penanda bendera (Markers Labeling)
ret, markers = cv2.connectedComponents(foreground)
# Tambah nilai 1 agar area background murni bernilai 1 (bukan 0)
markers = markers + 1
# Tandai daerah perbatasan yang membingungkan dengan nilai angka 0
markers[unknown == 255] = 0

# Langkah 6: Eksekusi Banjir Watershed Lokalisasi
markers = cv2.watershed(gambar_objek, markers)

# ============================================
# TAMPILKAN VISUALISASI PERBANDINGAN
# ============================================
gambar_warna = cv2.cvtColor(citra, cv2.COLOR_GRAY2RGB)
gambar_watershed = gambar_warna.copy()

# BUG FIX KODE LAB: Ubah koordinat [0, 0, 255] (Biru) menjadi [255, 0, 0] agar benar-benar MERAH di layar
gambar_watershed[markers == -1] = [255, 0, 0]

# Hitung jumlah objek riil (Marker bernilai di atas 1, abaikan background=1 dan tepi=-1)
objek_count = len(np.unique(markers)) - 2
print(f"Jumlah objek sukses terpisah (Watershed): {objek_count}")

plt.figure(figsize=(16, 11))

plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("1. Original\n(3 Lingkaran Menempel)")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(binary, cmap='gray')
plt.title("2. Hasil Biner Mentah")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(citra_kontur)
plt.title(f"3. Kontur Biasa: {len(contours)} Objek\n(Gagal memisahkan, menyatu semua)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(background, cmap='gray')
plt.title("4. Wilayah Background Pasti")
plt.axis('off')

plt.subplot(2, 3, 5)
# Menampilkan peta jarak dengan peta warna jet agar degradasi pusat bukit terlihat cantik
plt.imshow(dist_transform, cmap='jet')
plt.title("5. Distance Transform Map\n(Pusat inti objek)")
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(gambar_watershed)
plt.title(f"6. Hasil Akhir Watershed: {objek_count} Objek\n(Garis Merah = Pembatas Pintar)")
plt.axis('off')

plt.suptitle("Modul 5: Implementasi Algoritma Watershed Pemisah Overlapping Objects", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN METODE WATERSHED]")
print("-" * 45)
print("✅ Sukses besar membelah struktur objek yang saling berhimpitan.")
print("✅ Memanfaatkan konsep topografi peta kontur air bumi.")
print("✅ Distance transform krusial untuk menemukan 'jantung' terdalam objek.")
print("✅ Paling direkomendasikan untuk segmentasi medis (sel darah, butiran beras, bakteri).")
print("\n🎉 SELAMAT! SELURUH RANGKAIAN MODUL PRAKTIKUM KAMU SELESAI DENGAN SEMPURNA! 🎉")