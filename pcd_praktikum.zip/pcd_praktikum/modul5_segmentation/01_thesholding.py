import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 5: THRESHOLDING SEDERHANA
# ============================================
print("=" * 50)
print("MODUL 5: THRESHOLDING (Segmentasi Citra)")
print("=" * 50)

# Baca gambar menggunakan Smart Path (Memuat foto saya.jpg)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)
print(f"Dimensi gambar grayscale: {citra.shape}")

# ============================================
# KONSEP THRESHOLDING
# ============================================
print("\n[KONSEP THRESHOLDING]")
print("-" * 40)
print("Thresholding = mengubah gambar grayscale menjadi biner (hitam-putih)")
print("Rumus dasar: jika piksel > T maka putih (255), selain itu hitam (0)")
print("T = nilai threshold (ambang batas)")

# ============================================
# THRESHOLDING MANUAL DENGAN BERBAGAI NILAI T
# ============================================
print("\n[EKSPLORASI NILAI THRESHOLD]")
thresholds = [50, 100, 127, 150, 200]
hasil_threshold = []

for T in thresholds:
    # Menginisialisasi kanvas kosong berwarna hitam murni (0)
    biner = np.zeros_like(citra)
    # Kondisi: Jika nilai piksel citra asli di atas T, ubah menjadi putih (255)
    biner[citra > T] = 255
    hasil_threshold.append(biner)

# ============================================
# THRESHOLDING DENGAN OPENCV
# ============================================
print("\n[THRESHOLDING DENGAN OPENCV]")
print("Menggunakan fungsi bawaan: cv2.threshold(src, thresh, maxval, type)")

# 1. Binary threshold (Standar)
ret, binary = cv2.threshold(citra, 127, 255, cv2.THRESH_BINARY)

# 2. Inverse binary (Kebalikan)
ret, binary_inv = cv2.threshold(citra, 127, 255, cv2.THRESH_BINARY_INV)

# 3. Truncate (Memotong nilai piksel yang berada di atas ambang batas)
ret, trunc = cv2.threshold(citra, 127, 255, cv2.THRESH_TRUNC)

# 4. Tozero (Piksel di bawah ambang batas dipaksa menjadi hitam murni / 0)
ret, tozero = cv2.threshold(citra, 127, 255, cv2.THRESH_TOZERO)

# ============================================
# TAMPILKAN HASIL EKSPERIMEN GLOBAL
# ============================================
plt.figure(figsize=(16, 12))

# Slot 1: Citra Asli
plt.subplot(3, 4, 1)
plt.imshow(citra, cmap='gray')
plt.title("1. Original Grayscale")
plt.axis('off')

# Slot 2 sampai 6: Variasi Threshold Manual
for idx, (T, hasil) in enumerate(zip(thresholds, hasil_threshold), 2):
    plt.subplot(3, 4, idx)
    plt.imshow(hasil, cmap='gray')
    plt.title(f"Manual T = {T}")
    plt.axis('off')

# Slot 7 sampai 10: Hasil Flag Khusus OpenCV (T=127)
plt.subplot(3, 4, 7)
plt.imshow(binary, cmap='gray')
print("Slot 7 dimuat...")
plt.title("2. THRESH_BINARY (T=127)")
plt.axis('off')

plt.subplot(3, 4, 8)
plt.imshow(binary_inv, cmap='gray')
plt.title("3. THRESH_BINARY_INV")
plt.axis('off')

plt.subplot(3, 4, 9)
plt.imshow(trunc, cmap='gray')
plt.title("4. THRESH_TRUNC")
plt.axis('off')

plt.subplot(3, 4, 10)
plt.imshow(tozero, cmap='gray')
plt.title("5. THRESH_TOZERO")
plt.axis('off')

plt.suptitle("Modul 5: Eksplorasi Jenis-Jenis Global Thresholding", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# MENENTUKAN THRESHOLD OTOMATIS (OTSU)
# ============================================
print("\n" + "=" * 50)
print("[OTSU'S METHOD - THRESHOLD OTOMATIS]")
print("=" * 50)
print("Otsu secara otomatis mencari nilai threshold terbaik.")
print("Berdasarkan analisis histogram (meminimalkan variansi dalam kelas).")

# Otsu's thresholding dijalankan dengan melemparkan flag tambahan
ret_otsu, binary_otsu = cv2.threshold(citra, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
print(f"Hasil Kalkulasi Nilai T Optimal (Otsu): {ret_otsu:.2f}")

# Visualisasi hubungan histogram dengan garis potong threshold Otsu
histogram = cv2.calcHist([citra], [0], None, [256], [0, 256])

plt.figure(figsize=(14, 5))

plt.subplot(1, 2, 1)
plt.plot(histogram, color='black')
plt.axvline(x=ret_otsu, color='red', linestyle='--', linewidth=2, label=f'Otsu Threshold = {ret_otsu:.0f}')
plt.title("Analisis Sebaran Histogram")
plt.xlabel("Nilai Intensitas (0-255)")
plt.ylabel("Frekuensi Jumlah Piksel")
plt.legend()
plt.grid(True, alpha=0.3)

plt.subplot(1, 2, 2)
plt.imshow(binary_otsu, cmap='gray')
plt.title(f"Hasil Segmentasi Otsu\n(Binarization T = {ret_otsu:.0f})")
plt.axis('off')

plt.suptitle("Otsu's Method: Penentuan Batas Ambang Optimal Otomatis", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN THRESHOLDING]")
print("-" * 40)
print("➡️ Threshold rendah (T kecil): Mayoritas piksel menjadi PUTIH.")
print("➡️ Threshold tinggi (T besar) : Mayoritas piksel menjadi HITAM.")
print("➡️ Otsu's method: Mencari titik pisah (T) paling seimbang tanpa tebak manual.")
print("➡️ Syarat Otsu   : Berfungsi sangat baik jika histogram bersifat bimodal (punya 2 bukit).")
print("\n✅ Modul 5 - Bagian 1 selesai!")