import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 2: BRIGHTNESS & CONTRAST
# ============================================
print("=" * 50)
print("MODUL 2: MENGATUR KECERAHAN DAN KONTRAST")
print("=" * 50)

# 1. Baca gambar menggunakan Smart Path (Panggil foto saya.jpg)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (300, 300, 3), dtype=np.uint8)

# Konversi ke Grayscale agar efek kontras lebih terlihat jelas
citra_grayscale = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)
print(f"Dimensi gambar grayscale: {citra_grayscale.shape}")

# ============================================
# BRIGHTNESS (KECERAHAN)
# ============================================
print("\n[1. MENGATUR KECERAHAN - BRIGHTNESS]")
print("Brightness = menambah nilai konstan ke semua piksel")
print("Rumus: citra_terang = citra + beta")

# Operasi brightness menggunakan cv2.convertScaleAbs(src, alpha, beta)
# alpha = faktor kontras (1 = tidak berubah)
# beta = nilai yang ditambahkan (brightness)
cahaya_redup = cv2.convertScaleAbs(citra_grayscale, alpha=1, beta=-80)   # Lebih gelap (-80)
cahaya_normal = cv2.convertScaleAbs(citra_grayscale, alpha=1, beta=0)    # Original (0)
cahaya_terang = cv2.convertScaleAbs(citra_grayscale, alpha=1, beta=80)   # Lebih terang (+80)
cahaya_sangat_terang = cv2.convertScaleAbs(citra_grayscale, alpha=1, beta=150) # Sangat terang (+150)

# ============================================
# CONTRAST (KONTRAST)
# ============================================
print("\n[2. MENGATUR KONTRAST - CONTRAST]")
print("Contrast = mengalikan nilai piksel dengan faktor")
print("Rumus: citra_kontras = citra * alpha")
print("alpha > 1 = kontras meningkat")
print("0 < alpha < 1 = kontras menurun")

kontras_rendah = cv2.convertScaleAbs(citra_grayscale, alpha=0.5, beta=0) # Kontras rendah (mendekati abu-abu polos)
kontras_normal = cv2.convertScaleAbs(citra_grayscale, alpha=1, beta=0)   # Original
kontras_tinggi = cv2.convertScaleAbs(citra_grayscale, alpha=1.5, beta=0) # Kontras tinggi
kontras_sangat_tinggi = cv2.convertScaleAbs(citra_grayscale, alpha=2.0, beta=0) # Kontras sangat tinggi

# ============================================
# GABUNGAN BRIGHTNESS + CONTRAST
# ============================================
print("\n[3. GABUNGAN BRIGHTNESS & CONTRAST]")
print("Kombinasi keduanya memberikan efek yang lebih natural")
gabungan_cerah_kontras = cv2.convertScaleAbs(citra_grayscale, alpha=1.3, beta=50)

# ============================================
# EKSPERIMEN: VERSI KUSTOM (EFEK SILUET GELAP)
# ============================================
print("\n[4. EKSPERIMEN KUSTOM]")
# Membuat efek siluet/sinematik gelap dengan kontras sangat tinggi tapi brightness sangat rendah
efek_siluet = cv2.convertScaleAbs(citra_grayscale, alpha=2.5, beta=-100)

# ============================================
# TAMPILKAN HASIL BRIGHTNESS DAN KONTRAST
# ============================================
plt.figure(figsize=(15, 10))

# Baris 1: Brightness
plt.subplot(2, 3, 1)
plt.imshow(cahaya_redup, cmap='gray')
plt.title(f"1. Lebih Gelap\n(beta = -80)")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(cahaya_normal, cmap='gray')
plt.title("2. Original\n(beta = 0)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(cahaya_terang, cmap='gray')
plt.title(f"3. Lebih Terang\n(beta = +80)")
plt.axis('off')

# Baris 2: Contrast
plt.subplot(2, 3, 4)
plt.imshow(kontras_rendah, cmap='gray')
plt.title(f"4. Kontras Rendah\n(alpha = 0.5)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(kontras_normal, cmap='gray')
plt.title("5. Original\n(alpha = 1)")
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(kontras_tinggi, cmap='gray')
plt.title(f"6. Kontras Tinggi\n(alpha = 1.5)")
plt.axis('off')

plt.suptitle("Modul 2: Pengaruh Brightness (Beta) dan Contrast (Alpha)", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# TAMPILKAN HASIL GABUNGAN & EKSPERIMEN
# ============================================
plt.figure(figsize=(15, 5))

plt.subplot(1, 4, 1)
plt.imshow(citra_grayscale, cmap='gray')
plt.title("1. Original")
plt.axis('off')

plt.subplot(1, 4, 2)
plt.imshow(gabungan_cerah_kontras, cmap='gray')
plt.title("2. Gabungan Natural\n(alpha=1.3, beta=50)")
plt.axis('off')

plt.subplot(1, 4, 3)
plt.imshow(cv2.convertScaleAbs(citra_grayscale, alpha=1.8, beta=100), cmap='gray')
plt.title("3. Efek Ekstrim\n(alpha=1.8, beta=100)")
plt.axis('off')

# Menambahkan Gambar Hasil Eksperimen
plt.subplot(1, 4, 4)
plt.imshow(efek_siluet, cmap='gray')
plt.title("4. Eksperimen (Siluet)\n(alpha=2.5, beta=-100)")
plt.axis('off')

plt.suptitle("Kombinasi Brightness dan Contrast + Eksperimen", fontsize=16)
plt.tight_layout()
plt.show()