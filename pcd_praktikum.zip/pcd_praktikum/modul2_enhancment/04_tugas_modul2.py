import cv2
import matplotlib.pyplot as plt
import numpy as np
import os

# ============================================
# TUGAS MODUL 2: PRAKTIK MANDIRI
# ============================================
print("=" * 50)
print("TUGAS MODUL 2")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Buat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_grayscale = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# TUGAS 1: Cari kombinasi brightness & contrast optimal
# ============================================
print("\n[TUGAS 1] Cari kombinasi alpha dan beta terbaik")
print("Coba 5 kombinasi berbeda, pilih yang paling enak dipandang")

kombinasi = [
    {"alpha": 1.2, "beta": 30,  "nama": "Sedikit cerah & kontras"},
    {"alpha": 0.8, "beta": 40,  "nama": "Terang tapi kurang kontras"},
    {"alpha": 1.5, "beta": -20, "nama": "Kontras tinggi, agak gelap"},
    {"alpha": 1.0, "beta": 100, "nama": "Sangat terang"},
    {"alpha": 1.8, "beta": 50,  "nama": "Efek dramatis"},
]

plt.figure(figsize=(15, 10))

# Original
plt.subplot(2, 3, 1)
plt.imshow(citra_grayscale, cmap='gray')
plt.title("Original (Referensi)")
plt.axis('off')

# Coba setiap kombinasi
for i, k in enumerate(kombinasi, 2):
    hasil = cv2.convertScaleAbs(citra_grayscale, alpha=k["alpha"], beta=k["beta"])
    plt.subplot(2, 3, i)
    plt.imshow(hasil, cmap='gray')
    plt.title(f"{k['nama']}\n(alpha={k['alpha']}, beta={k['beta']})")
    plt.axis('off')

plt.suptitle("TUGAS 1: Mencari Kombinasi Brightness & Contrast Terbaik", fontsize=16)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Mana kombinasi yang paling bagus dan natural menurut Anda?")
print("Jawab: Kombinasi 'Sedikit cerah & kontras' (alpha=1.2, beta=30) terlihat paling natural")
print("       karena hanya sedikit meningkatkan kecerahan dan kontras tanpa membuat")
print("       gambar terlihat terlalu gelap, terlalu terang, atau kehilangan detail.")

# ============================================
# TUGAS 2: Efek Ekualisasi pada Berbagai Gambar
# ============================================
print("\n[TUGAS 2] Buat gambar dengan histogram yang Anda inginkan")

# Gambar kontras rendah (abu-abu ditambah sedikit noise acak)
dasar_abu = np.full(citra_grayscale.shape, 128, dtype=np.int16)
noise = np.random.randint(-20, 20, size=citra_grayscale.shape, dtype=np.int16)
gambar_kontras_rendah = np.clip(dasar_abu + noise, 0, 255).astype(np.uint8)

# Gambar sangat gelap
gambar_gelap = (citra_grayscale * 0.4).astype(np.uint8)

# Gambar sangat terang
gambar_terang = np.clip(citra_grayscale * 1.8, 0, 255).astype(np.uint8)

# Terapkan histogram equalization pada ketiganya
gambar_kontras_rendah_eq = cv2.equalizeHist(gambar_kontras_rendah)
gambar_gelap_eq          = cv2.equalizeHist(gambar_gelap)
gambar_terang_eq         = cv2.equalizeHist(gambar_terang)

plt.figure(figsize=(15, 10))

# Kontras rendah
plt.subplot(3, 2, 1)
plt.imshow(gambar_kontras_rendah, cmap='gray')
plt.title("Kontras Rendah (Sebelum)")
plt.axis('off')

plt.subplot(3, 2, 2)
plt.imshow(gambar_kontras_rendah_eq, cmap='gray')
plt.title("Kontras Rendah (Setelah Equalization)")
plt.axis('off')

# Gambar gelap
plt.subplot(3, 2, 3)
plt.imshow(gambar_gelap, cmap='gray')
plt.title("Gambar Gelap (Sebelum)")
plt.axis('off')

plt.subplot(3, 2, 4)
plt.imshow(gambar_gelap_eq, cmap='gray')
plt.title("Gambar Gelap (Setelah Equalization)")
plt.axis('off')

# Gambar terang
plt.subplot(3, 2, 5)
plt.imshow(gambar_terang, cmap='gray')
plt.title("Gambar Terang (Sebelum)")
plt.axis('off')

plt.subplot(3, 2, 6)
plt.imshow(gambar_terang_eq, cmap='gray')
plt.title("Gambar Terang (Setelah Equalization)")
plt.axis('off')

plt.suptitle("TUGAS 2: Efek Equalization pada Berbagai Jenis Gambar", fontsize=16)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Pada kondisi gambar seperti apa metode Equalization ini paling bermanfaat?")
print("Jawab: Histogram Equalization paling bermanfaat pada gambar yang:")
print("       1. Terlalu gelap (under-exposed) sehingga detail di area gelap tidak terlihat.")
print("       2. Memiliki kontras sangat rendah (gambar pudar/abu-abu merata),")
print("          karena equalization akan menyebarkan distribusi intensitas piksel")
print("          ke seluruh rentang 0-255 sehingga detail yang tersembunyi menjadi terlihat.")

# ============================================
# TUGAS 3: Analisis Histogram Gambar Gradien
# ============================================
print("\n[TUGAS 3] Buat gambar gradien dan analisis histogramnya")

# Gradien horizontal (kiri gelap, kanan terang)
gradien_horizontal = np.zeros((300, 500), dtype=np.uint8)
for x in range(500):
    gradien_horizontal[:, x] = int(x * 255 / 500)

# Gradien vertikal (atas gelap, bawah terang)
gradien_vertikal = np.zeros((500, 300), dtype=np.uint8)
for y in range(500):
    gradien_vertikal[y, :] = int(y * 255 / 500)

plt.figure(figsize=(15, 8))

plt.subplot(2, 2, 1)
plt.imshow(gradien_horizontal, cmap='gray')
plt.title("Gradien Horizontal\n(kiri gelap → kanan terang)")
plt.axis('off')

plt.subplot(2, 2, 2)
hist_h = cv2.calcHist([gradien_horizontal], [0], None, [256], [0, 256])
plt.plot(hist_h, color='black')
plt.title("Histogram Gradien Horizontal\n(merata)")
plt.xlabel("Intensitas Piksel")
plt.ylabel("Jumlah Piksel")
plt.grid(True, alpha=0.3)

plt.subplot(2, 2, 3)
plt.imshow(gradien_vertikal, cmap='gray')
plt.title("Gradien Vertikal\n(atas gelap → bawah terang)")
plt.axis('off')

plt.subplot(2, 2, 4)
hist_v = cv2.calcHist([gradien_vertikal], [0], None, [256], [0, 256])
plt.plot(hist_v, color='black')
plt.title("Histogram Gradien Vertikal\n(merata)")
plt.xlabel("Intensitas Piksel")
plt.ylabel("Jumlah Piksel")
plt.grid(True, alpha=0.3)

plt.suptitle("TUGAS 3: Gambar Gradien dan Histogramnya", fontsize=16)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Mengapa grafik histogram dari gambar gradien ini bentuknya lurus merata?")
print("Jawab: Karena pada gambar gradien, setiap nilai intensitas (dari 0 hingga 255)")
print("       muncul dengan jumlah piksel yang hampir sama persis.")
print("       Pada gradien horizontal misalnya, setiap kolom piksel memiliki satu nilai")
print("       intensitas unik, sehingga distribusinya tersebar merata di seluruh rentang.")

# ============================================
# TUGAS 4: Menyimpan Hasil Gambar (I/O)
# ============================================
print("\n[TUGAS 4] Simpan hasil enhancement terbaik")

# Buat folder hasil_output secara otomatis jika belum ada
folder_output = 'hasil_output'
if not os.path.exists(folder_output):
    os.makedirs(folder_output)
    print(f"Folder '{folder_output}' berhasil dibuat.")
else:
    print(f"Folder '{folder_output}' sudah ada.")

# Terapkan CLAHE pada gambar grayscale asli
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
hasil_terbaik = clahe.apply(citra_grayscale)

# Simpan hasil ke folder
path_simpan = os.path.join(folder_output, 'modul2_hasil_enhancement.jpg')
cv2.imwrite(path_simpan, hasil_terbaik)
print(f"✅ Hasil enhancement disimpan di: {path_simpan}")

# Tampilkan perbandingan sebelum dan sesudah CLAHE
plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.imshow(citra_grayscale, cmap='gray')
plt.title("Gambar Asli (Grayscale)")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(hasil_terbaik, cmap='gray')
plt.title("Hasil CLAHE\n(clipLimit=2.0, tileGridSize=8x8)")
plt.axis('off')

plt.suptitle("TUGAS 4: Hasil Enhancement CLAHE yang Disimpan", fontsize=14)
plt.tight_layout()
plt.show()

# ============================================
# RINGKASAN MODUL 2
# ============================================
print("\n" + "=" * 50)
print("RINGKASAN MODUL 2")
print("=" * 50)
print("\n✅ Yang sudah dipelajari:")
print("1. Brightness (kecerahan) → menambah nilai konstan (beta)")
print("2. Contrast (kontras)     → mengalikan nilai piksel (alpha)")
print("3. Histogram              → grafik distribusi intensitas piksel")
print("4. Histogram Equalization → meningkatkan kontras secara otomatis")
print("5. CLAHE                  → versi adaptif dari histogram equalization")

print("\n💡 Tips Praktis:")
print("- Gunakan brightness untuk gambar terlalu gelap atau terlalu terang.")
print("- Gunakan contrast untuk gambar yang kurang tajam atau terlihat kusam.")
print("- Gunakan Histogram Equalization untuk memunculkan detail yang hilang.")
print("- Gunakan CLAHE untuk hasil yang lebih natural dan tidak over-enhanced.")
print("- Jangan over-processing! Gambar alami jauh lebih enak dipandang.")

print("\n🎉 MODUL 2 SELESAI! 🎉")