import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 2: HISTOGRAM EQUALIZATION
# ============================================
print("=" * 50)
print("MODUL 2: HISTOGRAM EQUALIZATION")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy dengan kontras rendah...")
    citra_bgr = np.random.randint(80, 120, (300, 300, 3), dtype=np.uint8)

citra_grayscale = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)
print(f"Dimensi gambar: {citra_grayscale.shape}")

print("\n[KONSEP]")
print("Histogram Equalization = menyebarkan nilai intensitas secara merata")
print("Tujuan: meningkatkan kontras secara otomatis")
print("Cocok untuk gambar yang terlalu gelap/terang/kontras rendah")

# ============================================
# APLIKASI HISTOGRAM EQUALIZATION (GRAYSCALE)
# ============================================
# 1. Metode Dasar OpenCV (Global Equalization)
citra_equalized = cv2.equalizeHist(citra_grayscale)

# 2. Metode CLAHE (Contrast Limited Adaptive Histogram Equalization)
# Versi yang lebih canggih, mencegah noise/bercak berlebihan
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
citra_clahe = clahe.apply(citra_grayscale)

# ============================================
# HITUNG HISTOGRAM
# ============================================
hist_asli = cv2.calcHist([citra_grayscale], [0], None, [256], [0, 256])
hist_equal = cv2.calcHist([citra_equalized], [0], None, [256], [0, 256])
hist_clahe = cv2.calcHist([citra_clahe], [0], None, [256], [0, 256])

# ============================================
# HITUNG STATISTIK
# ============================================
print("\n[STATISTIK SEBELUM vs SESUDAH]")
print("-" * 40)
mean_asli = np.mean(citra_grayscale)
mean_equal = np.mean(citra_equalized)
std_asli = np.std(citra_grayscale)
std_equal = np.std(citra_equalized)

print(f"Rata-rata intensitas (mean):")
print(f" Sebelum: {mean_asli:.2f}")
print(f" Sesudah: {mean_equal:.2f}")

print(f"\nStandar deviasi (penyebaran/kontras):")
print(f" Sebelum: {std_asli:.2f}")
print(f" Sesudah: {std_equal:.2f}")

if std_equal > std_asli:
    print("\n✅ Standar deviasi MENINGKAT → kontras lebih BAIK!")
else:
    print("\n⚠️ Standar deviasi menurun → cek hasil")

# ============================================
# TAMPILKAN HASIL GRAYSCALE
# ============================================
plt.figure(figsize=(15, 10))

# Baris 1: Gambar
plt.subplot(2, 3, 1)
plt.imshow(citra_grayscale, cmap='gray')
plt.title("1. Original\n(Kontras asli)")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(citra_equalized, cmap='gray')
plt.title("2. Histogram Equalization\n(Seringkali terlalu agresif)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(citra_clahe, cmap='gray')
plt.title("3. CLAHE\n(Kontras adaptif & lebih natural)")
plt.axis('off')

# Baris 2: Histogram
plt.subplot(2, 3, 4)
plt.plot(hist_asli, color='black')
plt.title("Histogram Original")
plt.xlabel("Intensitas")
plt.ylabel("Frekuensi")
plt.grid(True, alpha=0.3)

plt.subplot(2, 3, 5)
plt.plot(hist_equal, color='black')
plt.title("Histogram Setelah Equalization")
plt.xlabel("Intensitas")
plt.ylabel("Frekuensi")
plt.grid(True, alpha=0.3)

plt.subplot(2, 3, 6)
plt.plot(hist_clahe, color='black')
plt.title("Histogram CLAHE")
plt.xlabel("Intensitas")
plt.ylabel("Frekuensi")
plt.grid(True, alpha=0.3)

plt.suptitle("Perbandingan Metode Histogram Equalization (Grayscale)", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# EKSPERIMEN BARU: APLIKASI PADA GAMBAR BERWARNA (RGB)
# ============================================
print("\n" + "=" * 50)
print("EKSPERIMEN: CLAHE PADA GAMBAR BERWARNA")
print("=" * 50)
print("Trik: Konversi ke LAB Color Space, lalu terapkan CLAHE hanya pada channel 'L' (Lightness).")

# 1. Konversi BGR (OpenCV) ke ruang warna LAB (Lightness, A-color, B-color)
citra_lab = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2LAB)

# 2. Pisahkan ketiga channel tersebut
l, a, b = cv2.split(citra_lab)

# 3. Terapkan CLAHE HANYA pada channel L (Cahaya/Lightness)
clahe_color = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
l_clahe = clahe_color.apply(l)

# 4. Gabungkan kembali channel yang sudah diperbaiki
lab_gabung = cv2.merge((l_clahe, a, b))

# 5. Konversi kembali dari LAB ke RGB untuk ditampilkan
citra_color_clahe = cv2.cvtColor(lab_gabung, cv2.COLOR_LAB2RGB)
citra_color_asli = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)

# Tampilkan Perbandingan Warna
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(citra_color_asli)
plt.title("Foto Original (Warna Asli)")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(citra_color_clahe)
plt.title("Hasil CLAHE Berwarna\n(Kontras & Detail Meningkat Tajam)")
plt.axis('off')

plt.suptitle("Eksperimen: Contrast Enhancement pada Foto Berwarna", fontsize=16)
plt.tight_layout()
plt.show()

print("\n✅ KESIMPULAN:")
print("- Histogram Equalization (Global) mengubah seluruh gambar sekaligus, kadang bikin 'noise'.")
print("- CLAHE bekerja per-kotak (grid) sehingga hasilnya sangat detail dan natural.")
print("- Untuk gambar warna, JANGAN equalize channel R, G, B satu per satu! Pisahkan dulu channel cahayanya (L/V).")