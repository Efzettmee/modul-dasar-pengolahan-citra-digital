import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 2: HISTOGRAM CITRA
# ============================================
print("=" * 50)
print("MODUL 2: ANALISIS HISTOGRAM")
print("=" * 50)

# 1. Baca gambar dengan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (300, 300, 3), dtype=np.uint8)

citra_grayscale = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# MEMBUAT HISTOGRAM DENGAN OPENCV
# ============================================
# cv2.calcHist(images, channels, mask, histSize, ranges)
histogram = cv2.calcHist([citra_grayscale], [0], None, [256], [0, 256])

# ============================================
# MEMBUAT HISTOGRAM DENGAN MATPLOTLIB (LEBIH MUDAH)
# ============================================
plt.figure(figsize=(15, 5)) # Ukuran disesuaikan

# Tampilkan gambar asli
plt.subplot(1, 3, 1)
plt.imshow(citra_grayscale, cmap='gray')
plt.title("1. Gambar Grayscale")
plt.axis('off')

# Tampilkan histogram dengan matplotlib
plt.subplot(1, 3, 2)
# ravel() meratakan matriks 2D menjadi array 1D
plt.hist(citra_grayscale.ravel(), bins=256, range=(0, 256), color='black')
plt.title("2. Histogram (Matplotlib)")
plt.xlabel("Nilai Intensitas (0-255)")
plt.ylabel("Jumlah Piksel")
plt.grid(True, alpha=0.3)

# Tampilkan histogram dengan OpenCV
plt.subplot(1, 3, 3)
plt.plot(histogram, color='blue')
plt.title("3. Histogram (OpenCV)")
plt.xlabel("Nilai Intensitas (0-255)")
plt.ylabel("Jumlah Piksel")
plt.grid(True, alpha=0.3)

plt.suptitle("Analisis Histogram Citra Asli", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# INTERPRETASI HISTOGRAM
# ============================================
print("\n[INTERPRETASI HISTOGRAM]")
print("-" * 40)
# Analisis histogram secara matematis
nilai_min = np.min(citra_grayscale)
nilai_max = np.max(citra_grayscale)
nilai_mean = np.mean(citra_grayscale)
nilai_median = np.median(citra_grayscale)

print(f"Nilai intensitas terendah: {nilai_min}")
print(f"Nilai intensitas tertinggi: {nilai_max}")
print(f"Rata-rata intensitas: {nilai_mean:.2f}")
print(f"Nilai tengah (median): {nilai_median:.2f}")

# Interpretasi Kecerahan
print("\n[INTERPRETASI]")
if nilai_mean < 85:
    print("➡️ Gambar cenderung GELAP (histogram menumpuk di kiri)")
elif nilai_mean > 170:
    print("➡️ Gambar cenderung TERANG (histogram menumpuk di kanan)")
else:
    print("➡️ Gambar memiliki kecerahan sedang (terdistribusi di tengah)")

# Interpretasi Kontras
rentang = nilai_max - nilai_min
if rentang < 100:
    print("➡️ Kontras RENDAH (grafik sempit/mengumpul di satu titik)")
elif rentang > 200:
    print("➡️ Kontras TINGGI (grafik menyebar luas dari ujung ke ujung)")
else:
    print("➡️ Kontras sedang")

# ============================================
# EKSPERIMEN: MANIPULASI MODEL & FREKUENSI HISTOGRAM
# ============================================
# 1. Buat gambar gelap (histogram digeser paksa ke kiri)
gambar_gelap = (citra_grayscale * 0.5).astype(np.uint8)

# 2. Buat gambar terang (histogram digeser paksa ke kanan)
gambar_terang = np.clip(citra_grayscale * 1.5, 0, 255).astype(np.uint8)

# 3. EKSPERIMEN BARU: Ekualisasi Histogram (Memperlebar frekuensi kontras secara otomatis)
gambar_ekualisasi = cv2.equalizeHist(citra_grayscale)

# Hitung histogram masing-masing menggunakan Matplotlib
plt.figure(figsize=(15, 10))

# Baris 1: Gambar Gelap
plt.subplot(3, 2, 1)
plt.imshow(gambar_gelap, cmap='gray')
plt.title("Gambar Gelap (Dikali 0.5)")
plt.axis('off')

plt.subplot(3, 2, 2)
plt.hist(gambar_gelap.ravel(), bins=256, range=(0, 256), color='black')
plt.title("Histogram Gelap (Menumpuk di nilai 0-128)")
plt.grid(True, alpha=0.3)

# Baris 2: Gambar Terang
plt.subplot(3, 2, 3)
plt.imshow(gambar_terang, cmap='gray')
plt.title("Gambar Terang (Dikali 1.5)")
plt.axis('off')

plt.subplot(3, 2, 4)
plt.hist(gambar_terang.ravel(), bins=256, range=(0, 256), color='black')
plt.title("Histogram Terang (Menumpuk dan terpotong di nilai 255)")
plt.grid(True, alpha=0.3)

# Baris 3: Ekualisasi (Distribusi Frekuensi Merata)
plt.subplot(3, 2, 5)
plt.imshow(gambar_ekualisasi, cmap='gray')
plt.title("Eksperimen: Ekualisasi Histogram (Kontras Maksimal)")
plt.axis('off')

plt.subplot(3, 2, 6)
plt.hist(gambar_ekualisasi.ravel(), bins=256, range=(0, 256), color='black')
plt.title("Histogram Ekualisasi (Frekuensi direntangkan dari 0 ke 255)")
plt.grid(True, alpha=0.3)

plt.suptitle("Eksperimen Modifikasi Model dan Frekuensi Histogram", fontsize=16)
plt.tight_layout()
plt.show()

print("\n✅ Modul 2 - Histogram selesai!")