import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 3: KONSEP DASAR KONVOLUSI
# ============================================
print("=" * 50)
print("MODUL 3: MEMAHAMI KONVOLUSI")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (300, 300, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)
print(f"Dimensi gambar: {citra.shape}")

# ============================================
# APA ITU KERNEL?
# ============================================
print("\n[KONSEP KERNEL]")
print("-" * 40)
print("Kernel = matriks kecil (biasanya 3x3, 5x5) yang berisi bobot")
print("Proses: kernel digeser ke setiap piksel, dikalikan, lalu dijumlahkan")
print("Hasilnya menjadi nilai baru untuk piksel tersebut")

print("\nContoh kernel 3x3:")
kernel_identitas = np.array([
    [0, 0, 0],
    [0, 1, 0],
    [0, 0, 0]
], dtype=np.float32)

print("\nKernel IDENTITAS (tidak mengubah gambar):")
print(kernel_identitas)
# Aplikasikan kernel identitas (tidak berubah)
hasil_identitas = cv2.filter2D(citra, -1, kernel_identitas)

# ============================================
# KERNEL BLUR SEDERHANA (Averaging)
# ============================================
print("\n[KERNEL BLUR]")
print("Mengganti setiap piksel dengan rata-rata tetangganya")
kernel_blur = np.array([
    [1/9, 1/9, 1/9],
    [1/9, 1/9, 1/9],
    [1/9, 1/9, 1/9]
], dtype=np.float32)

print("\nKernel BLUR 3x3 (setiap bobot = 1/9):")
print(kernel_blur)
print("Jumlah bobot:", np.sum(kernel_blur), "(harus 1 untuk menjaga kecerahan)")

# ============================================
# KERNEL SHARPEN (PENAJAMAN)
# ============================================
print("\n[KERNEL SHARPEN]")
print("Memperkuat perbedaan antara piksel dan tetangganya")
kernel_sharpen = np.array([
    [0, -1, 0],
    [-1, 5, -1],
    [0, -1, 0]
], dtype=np.float32)

print("\nKernel SHARPEN 3x3:")
print(kernel_sharpen)
print("Jumlah bobot:", np.sum(kernel_sharpen), "(harus 1)")

# ============================================
# DEMO VISUAL KONVOLUSI (ilustrasi konsep)
# ============================================
print("\n" + "=" * 50)
print("DEMO VISUAL: BAGAIMANA KONVOLUSI BEKERJA")
print("=" * 50)

# Buat ilustrasi sederhana: sebuah kotak putih di tengah
ilustrasi = np.zeros((50, 50), dtype=np.uint8)
ilustrasi[20:30, 20:30] = 255

# Kernel blur ukuran 5x5 untuk efek lebih terlihat
kernel_besar = np.ones((5, 5), dtype=np.float32) / 25

# Aplikasikan konvolusi
hasil_konvolusi = cv2.filter2D(ilustrasi, -1, kernel_besar)

# Tampilkan ilustrasi
plt.figure(figsize=(12, 5))

plt.subplot(1, 3, 1)
plt.imshow(ilustrasi, cmap='gray')
plt.title("1. Original: Kotak Putih\n(nilai 255 di tengah, 0 di tepi)")
plt.axis('off')

plt.subplot(1, 3, 2)
# Tampilkan kernel sebagai gambar
kernel_display = np.zeros((50, 50), dtype=np.uint8)
kernel_display[10:40, 10:40] = 255
plt.imshow(kernel_display, cmap='gray')
plt.title("2. Kernel 5x5 digeser\n(melalui setiap piksel)")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(hasil_konvolusi, cmap='gray')
plt.title("3. Hasil Konvolusi\n(kotak menjadi blur)")
plt.axis('off')

plt.suptitle("Ilustrasi: Bagaimana Konvolusi Mengubah Gambar", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# APLIKASI KERNEL PADA GAMBAR ASLI
# ============================================
print("\n[MENERAPKAN KERNEL PADA GAMBAR ASLI]")
# Aplikasikan berbagai kernel menggunakan filter2D
blur = cv2.filter2D(citra, -1, kernel_blur)
sharpen = cv2.filter2D(citra, -1, kernel_sharpen)
identitas = cv2.filter2D(citra, -1, kernel_identitas)

plt.figure(figsize=(15, 5))

plt.subplot(1, 4, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

plt.subplot(1, 4, 2)
plt.imshow(identitas, cmap='gray')
plt.title("Kernel Identitas\n(Sama seperti asli)")
plt.axis('off')

plt.subplot(1, 4, 3)
plt.imshow(blur, cmap='gray')
plt.title("Kernel Blur\n(Halus/kabur)")
plt.axis('off')

plt.subplot(1, 4, 4)
plt.imshow(sharpen, cmap='gray')
plt.title("Kernel Sharpen\n(Lebih tajam)")
plt.axis('off')

plt.suptitle("Efek Berbagai Matriks Kernel pada Gambar", fontsize=16)
plt.tight_layout()
plt.show()

print("\n✅ Perhatikan perbedaan antara ketiga hasil di atas!")
print(" - Identitas: tidak berubah")
print(" - Blur: gambar terlihat lebih halus/kabur")
print(" - Sharpen: tepi objek terlihat lebih tegas")

# ============================================
# EKSPLORASI: UKURAN KERNEL
# ============================================
print("\n" + "=" * 50)
print("EKSPLORASI: PENGARUH UKURAN KERNEL")
print("=" * 50)

# Kernel blur dengan ukuran berbeda
ukuran_kernel = [3, 7, 15, 31]
plt.figure(figsize=(15, 10))

for i, uk in enumerate(ukuran_kernel, 1):
    # Buat kernel averaging ukuran uk x uk
    kernel_besar_eksperimen = np.ones((uk, uk), dtype=np.float32) / (uk * uk)
    hasil_blur = cv2.filter2D(citra, -1, kernel_besar_eksperimen)

    plt.subplot(2, 2, i)
    plt.imshow(hasil_blur, cmap='gray')
    plt.title(f"Kernel {uk}x{uk}\n(Blur semakin kuat)")
    plt.axis('off')

plt.suptitle("Pengaruh Ukuran Kernel pada Tingkat Blur", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN]")
print("- Kernel kecil (3x3): blur halus, detail masih terlihat")
print("- Kernel besar (31x31): blur sangat kuat, detail hilang")
print("- Semakin besar kernel, semakin banyak piksel tetangga yang dirata-ratakan")
print("\n✅ Modul 3 - Bagian 1 selesai!")