import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 3: SHARPENING (PENAJAMAN GAMBAR)
# ============================================
print("=" * 50)
print("MODUL 3: SHARPENING (PENAJAMAN)")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
citra_gray = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

print("Sharpening = memperkuat tepi dan detail")
print("Prinsip: original + (perbedaan dengan tetangga)")

# ============================================
# BERBAGAI KERNEL SHARPEN
# ============================================
# Kernel sharpen dasar
sharpen_1 = np.array([
    [ 0, -1,  0],
    [-1,  5, -1],
    [ 0, -1,  0]
], dtype=np.float32)

# Kernel sharpen dengan bobot lebih kuat di tengah
sharpen_2 = np.array([
    [-1, -1, -1],
    [-1,  9, -1],
    [-1, -1, -1]
], dtype=np.float32)

# Kernel sharpen lain
sharpen_3 = np.array([
    [ 1, -2,  1],
    [-2,  5, -2],
    [ 1, -2,  1]
], dtype=np.float32)

# Kernel unsharp masking
unsharp = np.array([
    [-1, -1, -1, -1, -1],
    [-1,  2,  2,  2, -1],
    [-1,  2,  9,  2, -1],
    [-1,  2,  2,  2, -1],
    [-1, -1, -1, -1, -1]
], dtype=np.float32) / 9

# ============================================
# APLIKASIKAN SEMUA KERNEL
# ============================================
hasil_sharpen1 = cv2.filter2D(citra, -1, sharpen_1)
hasil_sharpen2 = cv2.filter2D(citra, -1, sharpen_2)
hasil_sharpen3 = cv2.filter2D(citra, -1, sharpen_3)
hasil_unsharp = cv2.filter2D(citra, -1, unsharp)

# Juga untuk grayscale
sharp_gray = cv2.filter2D(citra_gray, -1, sharpen_1)

plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(citra)
plt.title("1. Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(hasil_sharpen1)
plt.title("2. Sharpen Basic\n[[0,-1,0],[-1,5,-1],[0,-1,0]]")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(hasil_sharpen2)
plt.title("3. Sharpen Strong\n[[-1,-1,-1],[-1,9,-1],[-1,-1,-1]]")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(hasil_sharpen3)
plt.title("4. Sharpen Alternatif")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(hasil_unsharp)
plt.title("5. Unsharp Masking (5x5)")
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(sharp_gray, cmap='gray')
plt.title("6. Sharpen pada Grayscale")
plt.axis('off')

plt.suptitle("Berbagai Metode Sharpening", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# SHARPENING + BLUR (UNSHARP MASKING MANUAL)
# ============================================
print("\n[UNSHARP MASKING - METODE MANUAL]")
print("Cara: Original + (Original - Blur) x faktor")

# Langkah unsharp masking manual
blur = cv2.GaussianBlur(citra.astype(np.float32), (15, 15), 0)

# Menghitung Detail (Selisih)
detail = citra.astype(np.float32) - blur

faktor = 1.5
# Menambahkan Detail kembali ke Gambar Asli
unsharp_manual = np.clip(citra.astype(np.float32) + faktor * detail, 0, 255).astype(np.uint8)

plt.figure(figsize=(15, 8))

plt.subplot(2, 3, 1)
plt.imshow(citra)
plt.title("Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(np.clip(blur, 0, 255).astype(np.uint8))
plt.title("Blur (detail dihilangkan)")
plt.axis('off')

plt.subplot(2, 3, 3)
# Normalisasi detail untuk ditampilkan agar piksel negatif tidak error
detail_norm = np.clip((detail + 50) / 100 * 255, 0, 255).astype(np.uint8)
plt.imshow(detail_norm)
plt.title("Detail (Original - Blur)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(unsharp_manual)
plt.title(f"Unsharp Masking (faktor={faktor})")
plt.axis('off')

plt.suptitle("Ilustrasi Unsharp Masking Manual", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[PENJELASAN UNSHARP MASKING]")
print("-" * 40)
print("1. Buat versi blur dari gambar")
print("2. Hitung detail = original - blur")
print("3. Tambahkan detail kembali ke original")
print("4. Hasil: gambar lebih tajam!")
print("\nFaktor pengali detail: 0.5-1.0 (halus), 1.0-2.0 (kuat)")
print("\n✅ Modul 3 - Bagian 4 selesai!")