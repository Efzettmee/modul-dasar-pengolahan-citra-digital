import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 3: EKSPERIMEN MEMBUAT KERNEL SENDIRI
# ============================================
print("=" * 50)
print("MODUL 3: MEMBUAT KERNEL SENDIRI")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

# Konversi ke Grayscale agar fokus pada deteksi bentuk/tepi
citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# KERNEL DETEKSI TEPI (EDGE DETECTION)
# ============================================
print("\n[KERNEL DETEKSI TEPI]")
# Kernel Sobel-X (deteksi tepi vertikal)
sobel_x = np.array([
    [-1, 0, 1],
    [-2, 0, 2],
    [-1, 0, 1]
], dtype=np.float32)

# Kernel Sobel-Y (deteksi tepi horizontal)
sobel_y = np.array([
    [-1, -2, -1],
    [ 0,  0,  0],
    [ 1,  2,  1]
], dtype=np.float32)

# Kernel Laplacian (deteksi tepi segala arah)
laplacian = np.array([
    [ 0, -1,  0],
    [-1,  4, -1],
    [ 0, -1,  0]
], dtype=np.float32)

# Kernel emboss (efek timbul/3D)
emboss = np.array([
    [-2, -1,  0],
    [-1,  1,  1],
    [ 0,  1,  2]
], dtype=np.float32)

# Aplikasikan kernel dengan cv2.CV_64F agar nilai negatif tidak error saat kalkulasi
sobel_x_result = cv2.filter2D(citra, cv2.CV_64F, sobel_x)
sobel_y_result = cv2.filter2D(citra, cv2.CV_64F, sobel_y)
laplacian_result = cv2.filter2D(citra, cv2.CV_64F, laplacian)
emboss_result = cv2.filter2D(citra, -1, emboss) # Emboss aman pakai -1

plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

plt.subplot(2, 3, 2)
# np.abs digunakan untuk memutlakkan nilai negatif agar tampil benar di layar
plt.imshow(np.abs(sobel_x_result), cmap='gray')
plt.title("Sobel X (Tepi Vertikal)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(np.abs(sobel_y_result), cmap='gray')
plt.title("Sobel Y (Tepi Horizontal)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(np.abs(laplacian_result), cmap='gray')
plt.title("Laplacian (Tepi Semua Arah)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(emboss_result, cmap='gray')
plt.title("Emboss (Efek Timbul)")
plt.axis('off')

plt.suptitle("Kernel untuk Deteksi Tepi dan Efek Khusus", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# MEMBUAT KERNEL CUSTOM SENDIRI
# ============================================
print("\n[EKSPERIMEN: MEMBUAT KERNEL CUSTOM]")
print("Anda bisa membuat kernel sesuai keinginan!")

# Contoh: kernel garis horizontal
garis_horizontal = np.array([
    [0, 0, 0],
    [1, 1, 1],
    [0, 0, 0]
], dtype=np.float32) / 3

# Kernel garis vertikal
garis_vertikal = np.array([
    [0, 1, 0],
    [0, 1, 0],
    [0, 1, 0]
], dtype=np.float32) / 3

# Kernel cross (+)
cross = np.array([
    [1, 0, 1],
    [0, 1, 0],
    [1, 0, 1]
], dtype=np.float32) / 4

# Kernel diamond (wajik)
diamond = np.array([
    [0, 1, 0],
    [1, 1, 1],
    [0, 1, 0]
], dtype=np.float32) / 5

hasil_garis_h = cv2.filter2D(citra, -1, garis_horizontal)
hasil_garis_v = cv2.filter2D(citra, -1, garis_vertikal)
hasil_cross = cv2.filter2D(citra, -1, cross)
hasil_diamond = cv2.filter2D(citra, -1, diamond)

plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(hasil_garis_h, cmap='gray')
plt.title("Kernel Garis Horizontal")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(hasil_garis_v, cmap='gray')
plt.title("Kernel Garis Vertikal")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(hasil_cross, cmap='gray')
plt.title("Kernel Cross (+)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(hasil_diamond, cmap='gray')
plt.title("Kernel Diamond ◇")
plt.axis('off')

plt.suptitle("Kernel Custom Buatan Sendiri (Variasi Bentuk Blur)", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[Kesimpulan Eksperimen Kernel]")
print("-" * 40)
print("Anda bisa membuat matriks kernel untuk:")
print("- Blur (semua nilai positif, dan total jumlahnya = 1)")
print("- Sharpen (nilai tengah besar positif, sekeliling negatif, total jumlah = 1)")
print("- Deteksi Tepi (nilai berlawanan yang saling menetralkan, total jumlah = 0)")
print("- Efek Artistik (contohnya Emboss dengan nilai asimetris miring)")
print("\n✅ Modul 3 - Bagian 5 selesai!")