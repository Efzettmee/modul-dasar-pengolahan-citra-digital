import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 3: BERBAGAI METODE BLUR
# ============================================
print("=" * 50)
print("MODUL 3: METODE BLUR (PENGHALUSAN)")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy dengan noise...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# Tambahkan noise (agar terlihat efek blur)
noise = np.random.randint(-50, 50, citra.shape, dtype=np.int16)
citra_bernoise = np.clip(citra.astype(np.int16) + noise, 0, 255).astype(np.uint8)

print("Menambahkan noise acak ke gambar...")
print(f"Gambar original: {citra.shape}")
print(f"Gambar dengan noise: {citra_bernoise.shape}")

# ============================================
# 1. AVERAGING BLUR (cv2.blur)
# ============================================
print("\n[1. AVERAGING BLUR]")
print("Setiap piksel diganti dengan rata-rata tetangganya dalam kotak")
# cv2.blur(src, ksize) - ksize adalah tuple (lebar, tinggi)
blur_averaging_3 = cv2.blur(citra_bernoise, (3, 3))
blur_averaging_5 = cv2.blur(citra_bernoise, (5, 5))
blur_averaging_9 = cv2.blur(citra_bernoise, (9, 9))
print("Ukuran kernel: 3x3, 5x5, 9x9")

# ============================================
# 2. GAUSSIAN BLUR (cv2.GaussianBlur)
# ============================================
print("\n[2. GAUSSIAN BLUR]")
print("Bobot piksel tetangga mengikuti distribusi Gaussian")
print("(piksel tengah punya bobot lebih besar, yang jauh lebih kecil)")
# cv2.GaussianBlur(src, ksize, sigmaX)
# sigmaX = standar deviasi (0 = auto berdasarkan ukuran kernel)
gaussian_blur_3 = cv2.GaussianBlur(citra_bernoise, (3, 3), 0)
gaussian_blur_5 = cv2.GaussianBlur(citra_bernoise, (5, 5), 0)
gaussian_blur_9 = cv2.GaussianBlur(citra_bernoise, (9, 9), 0)
print("Ukuran kernel: 3x3, 5x5, 9x9")

# ============================================
# 3. MEDIAN BLUR (cv2.medianBlur)
# ============================================
print("\n[3. MEDIAN BLUR]")
print("Setiap piksel diganti dengan nilai MEDIAN dari tetangganya")
print("Sangat efektif untuk menghilangkan noise salt-and-pepper")
# cv2.medianBlur(src, ksize) - ksize harus ganjil
median_blur_3 = cv2.medianBlur(citra_bernoise, 3)
median_blur_5 = cv2.medianBlur(citra_bernoise, 5)
median_blur_9 = cv2.medianBlur(citra_bernoise, 9)
print("Ukuran kernel: 3x3, 5x5, 9x9")

# ============================================
# TAMPILKAN PERBANDINGAN (Kernel 5x5)
# ============================================
print("\n[TAMPILKAN HASIL]")
plt.figure(figsize=(15, 10))

# Baris 1: Original vs Noise
plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("1. Original (Tanpa Noise)")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(citra_bernoise, cmap='gray')
plt.title("2. Dengan Noise")
plt.axis('off')

# Baris 2: Berbagai metode blur (kernel 5x5)
plt.subplot(2, 3, 3)
plt.imshow(blur_averaging_5, cmap='gray')
plt.title("3. Averaging Blur (5x5)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(gaussian_blur_5, cmap='gray')
plt.title("4. Gaussian Blur (5x5)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(median_blur_5, cmap='gray')
plt.title("5. Median Blur (5x5)")
plt.axis('off')

plt.suptitle("Perbandingan Metode Blur (Ukuran Kernel = 5x5)", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# PERBANDINGAN EFEKTIVITAS MENGHILANGKAN NOISE
# ============================================
print("\n" + "=" * 50)
print("PERBANDINGAN EFEKTIVITAS MENGHILANGKAN NOISE")
print("=" * 50)

# Tambahkan noise salt-and-pepper khusus
citra_salt_pepper = citra.copy()

# Salt (titik putih)
salt = np.random.random(citra.shape) < 0.01
citra_salt_pepper[salt] = 255

# Pepper (titik hitam)
pepper = np.random.random(citra.shape) < 0.01
citra_salt_pepper[pepper] = 0

# Terapkan berbagai blur
avg_sp = cv2.blur(citra_salt_pepper, (5, 5))
gauss_sp = cv2.GaussianBlur(citra_salt_pepper, (5, 5), 0)
median_sp = cv2.medianBlur(citra_salt_pepper, 5)

plt.figure(figsize=(15, 8))

plt.subplot(2, 3, 1)
plt.imshow(citra, cmap='gray')
plt.title("Original (Bersih)")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(citra_salt_pepper, cmap='gray')
plt.title("Dengan Salt & Pepper Noise")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(avg_sp, cmap='gray')
plt.title("Averaging Blur\n(Titik putih masih terlihat)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(gauss_sp, cmap='gray')
plt.title("Gaussian Blur\n(Titik putih melebar)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(median_sp, cmap='gray')
plt.title("Median Blur\n(NOISE HILANG! TERBAGUS)")
plt.axis('off')

plt.suptitle("Uji Menghilangkan Noise Salt-and-Pepper", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN METODE BLUR]")
print("-" * 40)
print("1. AVERAGING BLUR: cocok untuk blur biasa, cepat")
print("2. GAUSSIAN BLUR: lebih natural, tepi lebih terjaga")
print("3. MEDIAN BLUR: TERBAIK untuk noise salt-and-pepper")
print("   (titik putih/hitam acak)")
print("\n✅ Modul 3 - Bagian 2 selesai!")