import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 3: GAUSSIAN & MEDIAN BLUR (DETAIL)
# ============================================
print("=" * 50)
print("MODUL 3: GAUSSIAN DAN MEDIAN BLUR")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

# Konversi ke RGB agar warna tepat saat ditampilkan di Matplotlib
citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)

# ============================================
# EKSPLORASI GAUSSIAN BLUR
# ============================================
print("\n[GAUSSIAN BLUR - EKSPLORASI]")
print("Parameter penting: ukuran kernel (ksize) dan sigma")

ukuran_kernel = [(3, 3), (7, 7), (15, 15)]
sigma_values = [0.5, 2, 5]

plt.figure(figsize=(15, 12))

# Looping untuk mencoba berbagai kombinasi ukuran kernel dan sigma
for i, ksize in enumerate(ukuran_kernel):
    for j, sigma in enumerate(sigma_values):
        idx = i * len(sigma_values) + j + 1
        hasil = cv2.GaussianBlur(citra, ksize, sigma)
        
        plt.subplot(3, 3, idx)
        plt.imshow(hasil)
        plt.title(f"Kernel {ksize[0]}x{ksize[1]}, sigma={sigma}")
        plt.axis('off')

plt.suptitle("Eksplorasi Gaussian Blur: Pengaruh Ukuran Kernel dan Sigma", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[PENGARUH PARAMETER GAUSSIAN BLUR]")
print("-" * 40)
print("Kernel kecil (3x3): blur halus, detail terjaga")
print("Kernel besar (15x15): blur kuat, detail hilang")
print("Sigma kecil: bobot lebih terpusat di tengah")
print("Sigma besar: penyebaran bobot lebih merata ke tepi")

# ============================================
# EKSPLORASI MEDIAN BLUR
# ============================================
print("\n[MEDIAN BLUR - EKSPLORASI]")

# Buat berbagai jenis noise pada channel V (Value/Brightness) di ruang warna HSV
citra_hsv = cv2.cvtColor(citra, cv2.COLOR_RGB2HSV)
citra_hsv_noise = citra_hsv.copy()

# Noise acak ditambahkan HANYA pada channel kecerahan agar warnanya tidak rusak
noise = np.random.randint(-40, 40, citra_hsv[:,:,2].shape, dtype=np.int16)
citra_hsv_noise[:,:,2] = np.clip(citra_hsv[:,:,2].astype(np.int16) + noise, 0, 255).astype(np.uint8)
citra_noise = cv2.cvtColor(citra_hsv_noise, cv2.COLOR_HSV2RGB)

# Terapkan median blur dengan berbagai ukuran kernel
median_3 = cv2.medianBlur(citra_noise, 3)
median_5 = cv2.medianBlur(citra_noise, 5)
median_7 = cv2.medianBlur(citra_noise, 7)

plt.figure(figsize=(15, 8))

plt.subplot(2, 3, 1)
plt.imshow(citra)
plt.title("Original (Bersih)")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(citra_noise)
plt.title("Dengan Noise Acak")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(median_3)
plt.title("Median Blur 3x3\n(Noise mulai berkurang)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(median_5)
plt.title("Median Blur 5x5\n(Noise hampir hilang)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(median_7)
plt.title("Median Blur 7x7\n(Noise hilang, tapi agak kabur)")
plt.axis('off')

plt.suptitle("Efek Median Blur pada Berbagai Ukuran Kernel", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[PENGARUH UKURAN MEDIAN BLUR]")
print("-" * 40)
print("Kernel 3x3: ringan, cocok untuk noise kecil")
print("Kernel 5x5: seimbang, rekomendasi umum")
print("Kernel 7x7: kuat, tapi gambar jadi lebih kabur (hilang detail)")

# ============================================
# PERBANDINGAN KECEPATAN (untuk info)
# ============================================
print("\n[PERBANDINGAN KECEPATAN - INFORMASI]")
print("Gaussian Blur: lebih cepat untuk kernel besar")
print("Median Blur: lebih lambat karena komputasi perlu menyortir/mengurutkan nilai")
print("Median Blur unggul untuk menghilangkan noise impulsif/bintik")
print("\n✅ Modul 3 - Bagian 3 selesai!")