import cv2
import matplotlib.pyplot as plt
import numpy as np
import os

# ============================================
# TUGAS MODUL 3: PRAKTIK MANDIRI
# ============================================
print("=" * 50)
print("TUGAS MODUL 3")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
citra_gray = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# TUGAS 1: Buat kernel blur berbentuk cross
# ============================================
print("\n[TUGAS 1] Buat kernel blur berbentuk cross (+)")
# Buat kernel cross (nilai di tengah dan atas-bawah-kiri-kanan)
kernel_cross = np.array([
    [0, 1, 0],
    [1, 1, 1],
    [0, 1, 0]
], dtype=np.float32)

kernel_cross = kernel_cross / np.sum(kernel_cross) # Normalisasi
print("Kernel cross:")
print(kernel_cross)

hasil_cross = cv2.filter2D(citra_gray, -1, kernel_cross)

plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.imshow(citra_gray, cmap='gray')
plt.title("Original")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(hasil_cross, cmap='gray')
plt.title("Blur dengan Kernel Cross")
plt.axis('off')

plt.suptitle("Tugas 1: Kernel Custom Cross", fontsize=16)
plt.show()

print("\nPertanyaan: Apa perbedaan dengan blur biasa?")
print("Jawab: Blur kotak biasa merata-ratakan 9 piksel sekaligus. Kernel Cross HANYA meratakan 5 piksel (mengabaikan sudut diagonal). Hasilnya, garis diagonal pada gambar akan sedikit lebih terjaga ketajamannya dibandingkan blur biasa.")

# ============================================
# TUGAS 2: Buat kernel untuk efek "out of focus"
# ============================================
print("\n[TUGAS 2] Buat kernel efek out of focus (lingkaran)")
# Kernel lingkaran 5x5
kernel_lingkaran = np.array([
    [0, 0, 1, 0, 0],
    [0, 1, 1, 1, 0],
    [1, 1, 1, 1, 1],
    [0, 1, 1, 1, 0],
    [0, 0, 1, 0, 0]
], dtype=np.float32)

kernel_lingkaran = kernel_lingkaran / np.sum(kernel_lingkaran)
print("Kernel lingkaran (out of focus effect):")
print(kernel_lingkaran)

hasil_outfocus = cv2.filter2D(citra, -1, kernel_lingkaran)

plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.imshow(citra)
plt.title("Original")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(hasil_outfocus)
plt.title("Efek Out of Focus")
plt.axis('off')

plt.suptitle("Tugas 2: Kernel Out of Focus (Lensa Kamera)", fontsize=16)
plt.show()

# ============================================
# TUGAS 3: Kombinasi blur dan sharpen
# ============================================
print("\n[TUGAS 3] Kombinasi blur lalu sharpen")
# Blur dulu
blur = cv2.GaussianBlur(citra, (7, 7), 0)

# Lalu sharpen
sharpen_kernel = np.array([
    [ 0, -1,  0],
    [-1,  5, -1],
    [ 0, -1,  0]
], dtype=np.float32)

blur_lalu_sharpen = cv2.filter2D(blur, -1, sharpen_kernel)

plt.figure(figsize=(12, 5))

plt.subplot(1, 3, 1)
plt.imshow(citra)
plt.title("Original")
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(blur)
plt.title("Blur Dulu")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(blur_lalu_sharpen)
plt.title("Blur → Sharpen\n(Efek artistic)")
plt.axis('off')

plt.suptitle("Kombinasi Blur + Sharpen", fontsize=16)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Apa yang terjadi? Apakah gambar kembali seperti asli?")
print("Jawab: TIDAK kembali seperti asli. Proses Blur membuang/menghancurkan data detail piksel secara permanen. Ketika kita menajamkannya kembali (Sharpen), komputer hanya menajamkan sisa-sisa warna yang sudah kabur tersebut, sehingga menghasilkan artefak aneh atau efek seperti lukisan cat air (watercolor).")

# ============================================
# TUGAS 4: Simpan hasil terbaik
# ============================================
print("\n[TUGAS 4] Simpan hasil filter terbaik")
# Coba kombinasi: median blur + sharpen
median = cv2.medianBlur(citra, 5)

sharpen_strong = np.array([
    [-1, -1, -1],
    [-1,  9, -1],
    [-1, -1, -1]
], dtype=np.float32)

hasil_terbaik = cv2.filter2D(median, -1, sharpen_strong)

# Simpan dengan aman menggunakan OS Path
folder_output = 'hasil_output'
os.makedirs(folder_output, exist_ok=True)
path_simpan = os.path.join(folder_output, 'modul3_hasil_terbaik.jpg')

# OpenCV menggunakan format BGR saat menyimpan file
cv2.imwrite(path_simpan, cv2.cvtColor(hasil_terbaik, cv2.COLOR_RGB2BGR))
print(f"✅ Hasil terbaik disimpan di: {path_simpan}")

plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.imshow(citra)
plt.title("Original")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(hasil_terbaik)
plt.title("Hasil Terbaik\n(Median Blur + Sharpen)")
plt.axis('off')

plt.suptitle("Tugas 4: Ekspor Gambar", fontsize=16)
plt.show()

# ============================================
# RINGKASAN MODUL 3
# ============================================
print("\n" + "=" * 50)
print("RINGKASAN MODUL 3")
print("=" * 50)
print("\n✅ Yang sudah dipelajari:")
print("1. Konsep konvolusi dan kernel")
print("2. Averaging blur (cv2.blur)")
print("3. Gaussian blur (cv2.GaussianBlur)")
print("4. Median blur (cv2.medianBlur)")
print("5. Sharpening dengan kernel custom")
print("6. Unsharp masking")
print("7. Kernel deteksi tepi (Sobel, Laplacian)")
print("8. Membuat kernel sendiri untuk efek khusus")

print("\n💡 Tips:")
print("- Gunakan Gaussian blur untuk efek natural")
print("- Gunakan Median blur untuk menghilangkan noise")
print("- Sharpen secukupnya (jangan berlebihan)")
print("- Eksperimen dengan kernel custom untuk efek artistik")

print("\n🎉 MODUL 3 SELESAI! 🎉")