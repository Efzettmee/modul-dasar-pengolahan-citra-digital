import cv2
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime
import os

# ============================================
# PROYEK AKHIR: SISTEM DETEKSI OBJEK LENGKAP
# ============================================
print("=" * 60)
print(" PROYEK AKHIR PENGOLAHAN CITRA DIGITAL")
print(" SISTEM DETEKSI OBJEK (OOP)")
print("=" * 60)


class ObjectDetector:
    """Kelas terintegrasi untuk mendeteksi dan menganalisis objek dalam citra."""

    def __init__(self, min_area=500, blur_ksize=(5, 5), morph_kernel=3):
        self.min_area    = min_area
        self.blur_ksize  = blur_ksize
        self.morph_kernel = morph_kernel
        self.results     = {}

    # ----------------------------------------------------------
    # 1. PEMUATAN GAMBAR
    # ----------------------------------------------------------
    def load_image(self, image_path):
        """Memuat gambar dari file sistem dan mengonversi ke RGB."""
        self.image = cv2.imread(image_path)
        if self.image is None:
            raise FileNotFoundError(f"Gambar tidak ditemukan di path: {image_path}")

        self.image_rgb = cv2.cvtColor(self.image, cv2.COLOR_BGR2RGB)
        self.height, self.width = self.image.shape[:2]
        print(f"[1] Gambar dimuat: {self.width} x {self.height} px")
        return self.image_rgb

    # ----------------------------------------------------------
    # 2. PREPROCESSING
    # ----------------------------------------------------------
    def preprocess(self):
        """Pipeline preprocessing: Grayscale -> Blur -> Otsu -> Morfologi."""
        # Grayscale dan Gaussian Blur untuk meredam noise
        gray = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, self.blur_ksize, 0)

        # Otsu Thresholding otomatis
        ret, binary = cv2.threshold(
            blur, 0, 255,
            cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
        )

        # Fallback manual jika nilai threshold Otsu terlalu rendah (< 20)
        if ret < 20:
            ret, binary = cv2.threshold(blur, 127, 255, cv2.THRESH_BINARY_INV)

        # Operasi morfologi: Closing menutup lubang, Opening membuang noda
        kernel = np.ones((self.morph_kernel, self.morph_kernel), np.uint8)
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN,  kernel, iterations=1)

        self.gray      = gray
        self.blur      = blur
        self.binary    = binary
        self.threshold = ret
        print(f"[2] Preprocessing selesai (Threshold Otsu = {ret:.2f})")
        return binary

    # ----------------------------------------------------------
    # 3. DETEKSI OBJEK
    # ----------------------------------------------------------
    def detect_objects(self):
        """Mencari kontur dan mengekstrak parameter geometri setiap objek."""
        contours, _ = cv2.findContours(
            self.binary,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )
        self.objects = []

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < self.min_area:
                continue

            perimeter          = cv2.arcLength(cnt, True)
            x, y, w, h        = cv2.boundingRect(cnt)
            (cx, cy), radius  = cv2.minEnclosingCircle(cnt)

            # Aproksimasi poligon untuk menghitung jumlah sudut
            peri   = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)

            # Pusat massa via momen citra
            M = cv2.moments(cnt)
            if M["m00"] != 0:
                mass_x = int(M["m10"] / M["m00"])
                mass_y = int(M["m01"] / M["m00"])
            else:
                mass_x, mass_y = int(cx), int(cy)

            self.objects.append({
                'contour'     : cnt,
                'area'        : area,
                'perimeter'   : perimeter,
                'bbox'        : (x, y, w, h),
                'center'      : (int(cx), int(cy)),
                'mass_center' : (mass_x, mass_y),
                'radius'      : int(radius),
                'vertices'    : len(approx),
                'aspect_ratio': w / float(h) if h > 0 else 0,
                'solidity'    : area / (w * h) if (w * h) > 0 else 0
            })

        print(f"[3] {len(self.objects)} objek valid terdeteksi")
        return self.objects

    # ----------------------------------------------------------
    # 4. KLASIFIKASI BENTUK
    # ----------------------------------------------------------
    def classify_shape(self, obj):
        """Mesin pengambil keputusan klasifikasi bentuk berdasarkan fitur geometri."""
        vertices = obj['vertices']
        aspect   = obj['aspect_ratio']
        area     = obj['area']
        radius   = obj['radius']
        solidity = obj['solidity']

        # Klasifikasi berbasis jumlah sudut
        if vertices <= 5:
            if vertices == 3:
                return "Segitiga"
            elif vertices == 4:
                return "Persegi" if 0.9 <= aspect <= 1.1 else "Persegi Panjang"
            elif vertices == 5:
                return "Pentagon"

        # Klasifikasi berbasis sirkularitas (Lingkaran vs Elips)
        circle_area = np.pi * (radius ** 2)
        circularity = area / circle_area if circle_area > 0 else 0

        if circularity > 0.8 and solidity > 0.85:
            return "Lingkaran"
        elif solidity > 0.9:
            return "Elips"
        else:
            return "Bentuk Lain"

    # ----------------------------------------------------------
    # 5. ANALISIS & AGREGASI STATISTIK
    # ----------------------------------------------------------
    def analyze_objects(self):
        """Mengklasifikasikan semua objek dan menghitung statistik agregat."""
        self.shapes     = {}
        total_area      = 0

        for obj in self.objects:
            shape              = self.classify_shape(obj)
            obj['shape']       = shape
            self.shapes[shape] = self.shapes.get(shape, 0) + 1
            total_area        += obj['area']

        self.total_area = total_area
        self.avg_area   = total_area / len(self.objects) if self.objects else 0
        print("[4] Analisis klasifikasi bentuk selesai")
        return self.shapes

    # ----------------------------------------------------------
    # 6. ANOTASI VISUAL
    # ----------------------------------------------------------
    def draw_results(self):
        """Menggambar bounding box, centroid, nomor, dan label ke kanvas."""
        result = self.image_rgb.copy()

        # Palet warna per kategori bentuk (format RGB)
        colors = {
            'Lingkaran'      : (0,   255, 0),
            'Persegi'        : (255, 0,   0),
            'Persegi Panjang': (255, 255, 0),
            'Segitiga'       : (0,   0,   255),
            'Elips'          : (255, 128, 0),
            'Pentagon'       : (128, 0,   255),
            'Bentuk Lain'    : (255, 0,   255)
        }

        for i, obj in enumerate(self.objects, 1):
            x, y, w, h = obj['bbox']
            center     = obj['center']
            shape      = obj['shape']
            color      = colors.get(shape, (0, 255, 255))

            # Bounding box
            cv2.rectangle(result, (x, y), (x + w, y + h), color, 2)

            # Titik centroid
            cv2.circle(result, center, 5, (0, 0, 255), -1)

            # Nomor urut objek
            cv2.putText(
                result, str(i),
                (center[0] - 10, center[1] - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2
            )

            # Label nama bentuk
            cv2.putText(
                result, shape,
                (x, y - 5),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1
            )

        self.result = result
        return result

    # ----------------------------------------------------------
    # 7. PEMBUATAN LAPORAN TEKS
    # ----------------------------------------------------------
    def generate_report(self):
        """Menyusun laporan teks terstruktur berisi seluruh hasil analisis."""
        lines = []
        lines.append("=" * 60)
        lines.append("LAPORAN DETEKSI OBJEK")
        lines.append("=" * 60)
        lines.append(f"Waktu Eksekusi  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Ukuran Gambar   : {self.width} x {self.height} px")
        lines.append(f"Threshold Otsu  : {self.threshold:.2f}")
        lines.append(f"Filter Min Area : {self.min_area} px")
        lines.append("-" * 40)
        lines.append(f"Total Objek     : {len(self.objects)}")
        lines.append(f"Total Area      : {self.total_area:.0f} piksel")
        lines.append(f"Rata-rata Area  : {self.avg_area:.0f} piksel")
        lines.append("-" * 40)
        lines.append("DISTRIBUSI KLASIFIKASI BENTUK:")

        for shape, count in self.shapes.items():
            pct = (count / len(self.objects) * 100) if self.objects else 0
            lines.append(f"  {shape:<18}: {count} objek ({pct:.1f}%)")

        lines.append("-" * 40)
        lines.append("DETAIL SETIAP OBJEK:")
        for i, obj in enumerate(self.objects, 1):
            lines.append(
                f"  {i:>2}. {obj['shape']:<18} | "
                f"Area: {obj['area']:<7.0f} | "
                f"Pusat: {obj['center']}"
            )

        lines.append("=" * 60)
        return "\n".join(lines)

    # ----------------------------------------------------------
    # 8. DASHBOARD VISUALISASI & EKSPOR
    # ----------------------------------------------------------
    def show_results(self):
        """Menampilkan dashboard 6-panel dan mengekspor hasil ke disk."""
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))

        # Panel 1 — Original
        axes[0, 0].imshow(self.image_rgb)
        axes[0, 0].set_title("1. Original")
        axes[0, 0].axis('off')

        # Panel 2 — Grayscale
        axes[0, 1].imshow(self.gray, cmap='gray')
        axes[0, 1].set_title("2. Grayscale")
        axes[0, 1].axis('off')

        # Panel 3 — Binary
        axes[0, 2].imshow(self.binary, cmap='gray')
        axes[0, 2].set_title(f"3. Binary (T = {self.threshold:.0f})")
        axes[0, 2].axis('off')

        # Panel 4 — Hasil Anotasi
        axes[1, 0].imshow(self.result)
        axes[1, 0].set_title(f"4. Hasil Deteksi: {len(self.objects)} Objek")
        axes[1, 0].axis('off')

        # Panel 5 — Grafik Batang Distribusi Bentuk
        if self.shapes:
            shapes_list = list(self.shapes.keys())
            counts_list = list(self.shapes.values())
            bar_colors  = ['#2ecc71', '#3498db', '#e74c3c',
                           '#f39c12', '#9b59b6', '#1abc9c', '#e91e63']
            axes[1, 1].bar(shapes_list, counts_list,
                           color=bar_colors[:len(shapes_list)])
            axes[1, 1].set_title("5. Distribusi Klasifikasi Bentuk")
            axes[1, 1].set_xlabel("Kategori Bentuk")
            axes[1, 1].set_ylabel("Jumlah Objek")
            plt.setp(axes[1, 1].xaxis.get_majorticklabels(), rotation=45, ha='right')
        else:
            axes[1, 1].text(0.5, 0.5, "Tidak ada objek", ha='center', va='center')
            axes[1, 1].axis('off')

        # Panel 6 — Quick Info
        info = (
            f"Total Objek    : {len(self.objects)}\n"
            f"Total Area     : {self.total_area:.0f} px\n"
            f"Rata-rata Area : {self.avg_area:.0f} px\n"
            f"\nSampel Detail (maks 5):\n"
            f"{'-' * 28}\n"
        )
        for i, obj in enumerate(self.objects[:5], 1):
            info += f"{i}. {obj['shape']:<18} ({obj['area']:.0f} px)\n"
        if len(self.objects) > 5:
            info += f"   ... dan {len(self.objects) - 5} objek lainnya"

        axes[1, 2].text(
            0.05, 0.95, info,
            fontsize=10, family='monospace',
            verticalalignment='top',
            transform=axes[1, 2].transAxes,
            bbox=dict(boxstyle="round,pad=0.5", facecolor="#ecf0f1", alpha=0.8)
        )
        axes[1, 2].set_title("6. Quick Info Panel")
        axes[1, 2].axis('off')

        plt.suptitle(
            "DASHBOARD: SISTEM DETEKSI & KLASIFIKASI OBJEK",
            fontsize=16, fontweight='bold'
        )
        plt.tight_layout()
        plt.show()

        # Cetak laporan ke terminal
        print("\n" + self.generate_report())

        # Ekspor gambar hasil ke disk
        os.makedirs('hasil_output', exist_ok=True)
        out_path = 'hasil_output/proyek_akhir_final.jpg'
        cv2.imwrite(out_path, cv2.cvtColor(self.result, cv2.COLOR_RGB2BGR))
        print(f"[OK] Hasil disimpan di: {out_path}")

    # ----------------------------------------------------------
    # 9. ORKESTRASI PIPELINE UTAMA
    # ----------------------------------------------------------
    def run(self, image_path):
        """Menjalankan seluruh pipeline dari awal hingga akhir."""
        print("\n" + "=" * 40)
        print("  MENJALANKAN PIPELINE DETEKTOR OBJEK")
        print("=" * 40)
        self.load_image(image_path)
        self.preprocess()
        self.detect_objects()
        self.analyze_objects()
        self.draw_results()
        self.show_results()
        return self.results


# ============================================
# MAIN PROGRAM EXECUTION
# ============================================
if __name__ == "__main__":

    # Inisialisasi engine detector
    detector = ObjectDetector(
        min_area=500,
        blur_ksize=(5, 5),
        morph_kernel=3
    )

    # Smart Path: prioritaskan foto saya.jpg
    target_image = 'images/saya.jpg'
    if not os.path.exists(target_image):
        target_image = '../images/saya.jpg'

    try:
        detector.run(target_image)

    except FileNotFoundError as e:
        print(f"\n[!] {e}")
        print("Membuat gambar demo geometri otomatis...\n")

        # Buat gambar demo dengan 5 bentuk geometri beragam
        os.makedirs('images', exist_ok=True)
        demo = np.full((500, 700, 3), (240, 240, 240), dtype=np.uint8)

        # Lingkaran biru
        cv2.circle(demo, (150, 150), 60, (100, 100, 255), -1)

        # Persegi hijau
        cv2.rectangle(demo, (300, 90), (420, 210), (100, 255, 100), -1)

        # Segitiga merah
        pts_segitiga = np.array([[550, 100], [480, 230], [620, 230]], np.int32)
        cv2.fillPoly(demo, [pts_segitiga], (255, 100, 100))

        # Lingkaran kecil orange
        cv2.circle(demo, (180, 370), 50, (255, 190, 80), -1)

        # Persegi panjang ungu
        cv2.rectangle(demo, (430, 310), (620, 430), (180, 80, 255), -1)

        demo_path = 'images/demo_objek_akhir.jpg'
        cv2.imwrite(demo_path, demo)
        print(f"Gambar demo disimpan di: {demo_path}")

        detector.run(demo_path)

    print("\n" + "=" * 60)
    print("  PRAKTIKUM PENGOLAHAN CITRA DIGITAL SELESAI!")
    print("  Terima kasih telah mengikuti seluruh modul.")
    print("=" * 60)