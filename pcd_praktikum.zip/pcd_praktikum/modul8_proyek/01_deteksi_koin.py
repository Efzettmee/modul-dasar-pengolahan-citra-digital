import cv2
import matplotlib.pyplot as plt
import numpy as np
import os

# ============================================
# PROYEK AKHIR: DETEKSI DAN HITUNG KOIN
# ============================================
print("=" * 50)
print("PROYEK 1: DETEKSI DAN PENGHITUNGAN KOIN")
print("=" * 50)

# ============================================
# LANGKAH 1: MEMBUAT GAMBAR SIMULASI KOIN
# ============================================
print("\n[LANGKAH 1] Membuat gambar simulasi koin...")
# Buat gambar kosong (latar belakang abu-abu)
gambar = np.zeros((500, 700, 3), dtype=np.uint8)
gambar[:] = (200, 200, 200) # Background abu-abu

# Buat beberapa koin (lingkaran) dengan ukuran dan posisi berbeda
koin = [
    (100, 200, 40, (180, 180, 50)), # (x, y, radius, warna)
    (200, 150, 35, (200, 200, 60)),
    (300, 250, 45, (160, 160, 40)),
    (450, 200, 30, (190, 190, 55)),
    (550, 300, 38, (170, 170, 45)),
    (150, 400, 32, (185, 185, 52)),
    (400, 380, 42, (175, 175, 48)),
    (600, 150, 28, (195, 195, 58)),
]

for x, y, r, warna in koin:
    cv2.circle(gambar, (x, y), r, warna, -1)
    # Tambahkan highlight agar koin terlihat sedikit timbul (3D)
    cv2.circle(gambar, (x-10, y-10), r//5, (255, 255, 255), -1)

# Simpan gambar simulasi ke dalam folder images
os.makedirs('images', exist_ok=True)
cv2.imwrite('images/koin_simulasi.jpg', gambar)
print("Gambar simulasi koin disimpan di: images/koin_simulasi.jpg")

# ============================================
# LANGKAH 2: PREPROCESSING
# ============================================
print("\n[LANGKAH 2] Preprocessing gambar...")
# Baca gambar
citra = cv2.imread('images/koin_simulasi.jpg')
if citra is None:
    print("Gambar tidak ditemukan, menggunakan matriks gambar yang baru dibuat")
    citra = gambar

citra_rgb = cv2.cvtColor(citra, cv2.COLOR_BGR2RGB)
citra_gray = cv2.cvtColor(citra, cv2.COLOR_BGR2GRAY)

# Gaussian blur untuk mengurangi noise dan menghaluskan tepi koin
blur = cv2.GaussianBlur(citra_gray, (9, 9), 0)

# ============================================
# LANGKAH 3: SEGMENTASI (THRESHOLDING)
# ============================================
print("\n[LANGKAH 3] Segmentasi dengan thresholding...")
# Gunakan Otsu threshold untuk mencari nilai batas secara otomatis
ret, binary = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
print(f"Threshold Otsu yang terpilih: {ret:.2f}")

# ============================================
# LANGKAH 4: OPERASI MORFOLOGI
# ============================================
print("\n[LANGKAH 4] Membersihkan hasil segmentasi dengan morfologi...")
kernel = np.ones((5, 5), np.uint8)

# Closing untuk menutup lubang/cacat di dalam objek koin
closing = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)
# Opening untuk menghilangkan bintik noise kecil di luar koin
opening = cv2.morphologyEx(closing, cv2.MORPH_OPEN, kernel, iterations=1)

# ============================================
# LANGKAH 5: DETEKSI KONTUR
# ============================================
print("\n[LANGKAH 5] Deteksi kontur objek...")
# Cari kerangka batas luar objek
contours, hierarchy = cv2.findContours(opening, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
print(f"Jumlah kontur awal yang tertangkap: {len(contours)}")

# Filter kontur berdasarkan luas (abaikan objek yang terlalu kecil / debu)
min_area = 500
koin_terdeteksi = []
for cnt in contours:
    area = cv2.contourArea(cnt)
    if area > min_area:
        koin_terdeteksi.append(cnt)
print(f"Jumlah koin tervalidasi: {len(koin_terdeteksi)}")

# ============================================
# LANGKAH 6: ANALISIS DAN VISUALISASI
# ============================================
print("\n[LANGKAH 6] Analisis dan visualisasi hasil...")
hasil = citra_rgb.copy()
warna_box = (0, 255, 0) # Warna Hijau

for i, cnt in enumerate(koin_terdeteksi, 1):
    # Hitung luas area
    area = cv2.contourArea(cnt)
    
    # Buat Bounding Circle (Lingkaran Pembungkus)
    (x, y), radius = cv2.minEnclosingCircle(cnt)
    center = (int(x), int(y))
    radius = int(radius)
    
    # Gambar lingkaran pembatas luar
    cv2.circle(hasil, center, radius, warna_box, 2)
    # Gambar titik pusat koordinat
    cv2.circle(hasil, center, 5, (255, 0, 0), -1)
    
    # Tulis teks nomor seri dan luas area
    cv2.putText(hasil, f"#{i}", (center[0]-20, center[1]-radius-5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    cv2.putText(hasil, f"Area:{area:.0f}", (center[0]-20, center[1]+radius+15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1)
    
    print(f"Koin {i}: Posisi=({center[0]}, {center[1]}), Radius={radius}, Area={area:.0f} px")

# ============================================
# LANGKAH 7: TAMPILKAN HASIL
# ============================================
print("\n[LANGKAH 7] Menampilkan hasil visual...")
plt.figure(figsize=(15, 12))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("1. Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(citra_gray, cmap='gray')
plt.title("2. Grayscale")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(blur, cmap='gray')
plt.title("3. Gaussian Blur")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(binary, cmap='gray')
plt.title("4. Binary (Otsu Threshold)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(opening, cmap='gray')
plt.title("5. Cleaned (Morfologi)")
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(hasil)
plt.title(f"6. HASIL AKHIR: {len(koin_terdeteksi)} Koin Terdeteksi")
plt.axis('off')

plt.suptitle("PROYEK AKHIR: Pipeline Deteksi dan Penghitungan Koin", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# LANGKAH 8: SIMPAN HASIL
# ============================================
print("\n[LANGKAH 8] Menyimpan hasil eksperimen...")
os.makedirs('hasil_output', exist_ok=True)
path_simpan = 'hasil_output/proyek_koin_hasil.jpg'
cv2.imwrite(path_simpan, cv2.cvtColor(hasil, cv2.COLOR_RGB2BGR))
print(f"✅ Hasil deteksi koin berhasil disimpan di: {path_simpan}")

# ============================================
# KESIMPULAN
# ============================================
print("\n" + "=" * 50)
print("PROYEK 1 SELESAI!")
print("=" * 50)
print("\n📊 LAPORAN HASIL:")
print(f"  Jumlah koin terdeteksi: {len(koin_terdeteksi)}")
print(f"  Ukuran gambar: {citra_rgb.shape[1]} x {citra_rgb.shape[0]}")
print(f"  Threshold Otsu: {ret:.2f}")

print("\n✅ Urutan Pipeline (Alur Kerja) yang digunakan:")
print("  1. Gambar Original")
print("  2. Konversi Grayscale (Hitam Putih Dasar)")
print("  3. GaussianBlur (Menghaluskan Permukaan)")
print("  4. Otsu Threshold (Segmentasi Siluet Otomatis)")
print("  5. Morphology Closing (Menambal Lubang)")
print("  6. Morphology Opening (Menghapus Debu)")
print("  7. FindContours (Deteksi Batas Objek)")
print("  8. Filter Area (Seleksi Objek Valid)")
print("  9. Draw Bounding Circle (Visualisasi Hasil)")

print("\n🎉 Selamat! Anda berhasil membuat aplikasi Computer Vision pendeteksi koin! 🎉")