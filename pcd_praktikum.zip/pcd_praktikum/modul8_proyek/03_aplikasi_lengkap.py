import cv2
import matplotlib.pyplot as plt
import numpy as np
import os
from datetime import datetime

# ============================================
# PROYEK AKHIR: APLIKASI DETEKSI OBJEK LENGKAP
# ============================================
print("=" * 50)
print("PROYEK 3: APLIKASI DETEKSI OBJEK LENGKAP")
print("=" * 50)

# ============================================
# FUNGSI-FUNGSI UTAMA (Modular Programming)
# ============================================
def preprocess_image(gambar):
    """Preprocessing gambar: grayscale, blur, threshold"""
    gray = cv2.cvtColor(gambar, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Coba Otsu dulu untuk mencari nilai threshold optimal secara otomatis
    ret, binary = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    
    # Fallback ke binary manual jika Otsu gagal (nilai terlalu rendah)
    if ret < 10: 
        ret, binary = cv2.threshold(blur, 127, 255, cv2.THRESH_BINARY_INV)
        
    # Morfologi untuk membersihkan gambar dari noise
    kernel = np.ones((3, 3), np.uint8)
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)
    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=1)
    
    return gray, binary, ret

def detect_objects(binary, min_area=500):
    """Deteksi dan ekstraksi fitur objek dari citra biner"""
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    objects = []
    
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > min_area:
            # Hitung properti geometri
            perimeter = cv2.arcLength(cnt, True)
            x, y, w, h = cv2.boundingRect(cnt)
            (cx, cy), radius = cv2.minEnclosingCircle(cnt)
            
            # Approximate untuk klasifikasi bentuk (Ramer-Douglas-Peucker)
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
            
            objects.append({
                'contour': cnt,
                'area': area,
                'perimeter': perimeter,
                'bbox': (x, y, w, h),
                'center': (int(cx), int(cy)),
                'radius': int(radius),
                'vertices': len(approx),
                'aspect_ratio': float(w) / h if h > 0 else 0
            })
    return objects

def classify_shape(obj):
    """Klasifikasikan bentuk objek berdasarkan vertex dan rasio"""
    vertices = obj['vertices']
    aspect_ratio = obj['aspect_ratio']
    area = obj['area']
    radius = obj['radius']
    
    if vertices == 3:
        return "Segitiga"
    elif vertices == 4:
        if 0.9 <= aspect_ratio <= 1.1:
            return "Persegi"
        else:
            return "Persegi Panjang"
    else:
        # Cek apakah kepadatan area mendekati lingkaran sempurna
        circle_area = np.pi * (radius ** 2)
        if area / circle_area > 0.8:
            return "Lingkaran"
        else:
            return "Lainnya"

def draw_results(gambar, objects):
    """Gambar bounding box dan informasi hasil deteksi pada kanvas"""
    hasil = gambar.copy()
    
    # Mapping warna berdasarkan bentuk (Format BGR/RGB)
    colors = {
        'Lingkaran': (0, 255, 0),         # Hijau
        'Persegi': (255, 0, 0),           # Biru
        'Persegi Panjang': (255, 255, 0), # Cyan/Kuning
        'Segitiga': (0, 0, 255),          # Merah
        'Lainnya': (255, 0, 255)          # Magenta
    }
    
    for i, obj in enumerate(objects, 1):
        x, y, w, h = obj['bbox']
        center = obj['center']
        bentuk = classify_shape(obj)
        color = colors.get(bentuk, (0, 255, 255))
        
        # Gambar kotak pembatas dan titik pusat koordinat
        cv2.rectangle(hasil, (x, y), (x+w, y+h), color, 2)
        cv2.circle(hasil, center, 4, (0, 0, 255), -1)
        
        # Tulis label informasi
        info = f"{i}. {bentuk} ({obj['area']:.0f})"
        cv2.putText(hasil, info, (x, y-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        
    return hasil

# ============================================
# MAIN PROGRAM
# ============================================
print("\n[MEMUAT GAMBAR]")
# Baca gambar menggunakan Smart Path
citra = cv2.imread('images/saya.jpg')
if citra is None:
    citra = cv2.imread('../images/saya.jpg')

if citra is None:
    print("Gambar asli tidak ditemukan, membuat gambar dummy...")
    citra = np.random.randint(0, 255, (500, 500, 3), dtype=np.uint8)
    cv2.circle(citra, (200, 200), 80, (255, 255, 255), -1)
    cv2.rectangle(citra, (300, 300), (420, 380), (200, 200, 200), -1)

citra_rgb = cv2.cvtColor(citra, cv2.COLOR_BGR2RGB)
print(f"Dimensi gambar: {citra.shape[1]} x {citra.shape[0]}")

# ============================================
# PROSES DETEKSI
# ============================================
print("\n[PROSES DETEKSI]")
# 1. Preprocessing
gray, binary, threshold = preprocess_image(citra)
print(f"Threshold yang digunakan: {threshold:.2f}")

# 2. Ekstraksi Objek
objects = detect_objects(binary, min_area=500)
print(f"Jumlah objek terdeteksi: {len(objects)}")

# 3. Kalkulasi Data
total_area = sum(obj['area'] for obj in objects)
print(f"Total area objek: {total_area:.0f} piksel")

# ============================================
# VISUALISASI HASIL
# ============================================
print("\n[VISUALISASI]")
hasil = draw_results(citra_rgb, objects)

plt.figure(figsize=(16, 10))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("1. Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(gray, cmap='gray')
plt.title("2. Grayscale")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(binary, cmap='gray')
plt.title(f"3. Binary (Threshold={threshold:.0f})")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(hasil)
plt.title(f"4. HASIL: {len(objects)} Objek Terdeteksi")
plt.axis('off')

# Panel Tabel Informasi Objek
info_text = f"Total Objek: {len(objects)}\n"
info_text += f"Total Area : {total_area:.0f} px\n\n"
info_text += "Detail Objek:\n"
for i, obj in enumerate(objects, 1):
    bentuk = classify_shape(obj)
    info_text += f"{i}. {bentuk} (Area: {obj['area']:.0f})\n"

plt.subplot(2, 3, 5)
plt.text(0.1, 0.5, info_text, fontsize=11, family='monospace', verticalalignment='center', bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgray"))
plt.title("Informasi Detail Objek")
plt.axis('off')

# Panel Grafik Bar Ringkasan Bentuk
shape_summary = {}
for obj in objects:
    bentuk = classify_shape(obj)
    shape_summary[bentuk] = shape_summary.get(bentuk, 0) + 1

plt.subplot(2, 3, 6)
# Memastikan urutan data ter-passing dengan baik ke dalam list untuk grafik
plt.bar(list(shape_summary.keys()), list(shape_summary.values()), color=['green', 'blue', 'cyan', 'red', 'magenta'])
plt.title("Ringkasan Statistik Bentuk")
plt.xticks(rotation=45)

plt.suptitle("PROYEK 3: Sistem Aplikasi Deteksi Objek Lengkap", fontsize=16, fontweight='bold')
plt.tight_layout()
plt.show()

# ============================================
# SIMPAN HASIL
# ============================================
print("\n[MENYIMPAN HASIL]")
os.makedirs('hasil_output', exist_ok=True)
cv2.imwrite('hasil_output/proyek_lengkap_hasil.jpg', cv2.cvtColor(hasil, cv2.COLOR_RGB2BGR))
print("✅ Hasil disimpan di: hasil_output/proyek_lengkap_hasil.jpg")

# ============================================
# LAPORAN AKHIR
# ============================================
print("\n" + "=" * 50)
print("PROYEK 3 SELESAI!")
print("=" * 50)
print(f"\n📊 LAPORAN DETEKSI:")
print(f"  Tanggal       : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print(f"  Ukuran gambar : {citra.shape[1]} x {citra.shape[0]} px")
print(f"  Threshold Otsu: {threshold:.2f}")
print(f"  Jumlah objek  : {len(objects)}")
print(f"  Total area    : {total_area:.0f} px")

print("\n📋 Detail Koordinat & Geometri:")
for i, obj in enumerate(objects, 1):
    bentuk = classify_shape(obj)
    print(f"  {i}. {bentuk:<15} | Area: {obj['area']:<7.0f} | Pusat: {obj['center']}")

print("\n🎉 SELAMAT! SISTEM APLIKASI DETEKSI OBJEK BERHASIL DIJALANKAN! 🎉")