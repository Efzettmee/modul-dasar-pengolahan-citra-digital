import cv2
import matplotlib.pyplot as plt
import numpy as np
import os

# ============================================
# PROYEK AKHIR: DETEKSI BERBAGAI BENTUK
# ============================================
print("=" * 50)
print("PROYEK 2: DETEKSI BENTUK (Persegi, Lingkaran, Segitiga)")
print("=" * 50)

# ============================================
# LANGKAH 1: MEMBUAT GAMBAR DENGAN BERBAGAI BENTUK
# ============================================
print("\n[LANGKAH 1] Membuat gambar simulasi bentuk...")
gambar = np.zeros((500, 700, 3), dtype=np.uint8)
gambar[:] = (240, 240, 240) # Background putih terang

# Buat berbagai bentuk geometri dasar
# 1. Persegi
cv2.rectangle(gambar, (50, 100), (150, 200), (100, 100, 255), -1)

# 2. Lingkaran
cv2.circle(gambar, (300, 150), 50, (100, 255, 100), -1)

# 3. Segitiga
pts = np.array([[500, 100], [450, 200], [550, 200]], np.int32)
cv2.fillPoly(gambar, [pts], (255, 100, 100))

# 4. Persegi panjang
cv2.rectangle(gambar, (100, 350), (250, 450), (100, 100, 255), -1)

# 5. Elips
cv2.ellipse(gambar, (450, 400), (60, 40), 0, 0, 360, (255, 200, 100), -1)

# 6. Bintang (Segitiga terbalik)
pts2 = np.array([[600, 350], [550, 450], [650, 450]], np.int32)
cv2.fillPoly(gambar, [pts2], (255, 150, 150))

os.makedirs('images', exist_ok=True)
cv2.imwrite('images/bentuk_simulasi.jpg', gambar)
print("Gambar simulasi bentuk disimpan di: images/bentuk_simulasi.jpg")

# ============================================
# LANGKAH 2: PREPROCESSING
# ============================================
print("\n[LANGKAH 2] Preprocessing...")
citra = cv2.imread('images/bentuk_simulasi.jpg')
if citra is None:
    print("Gambar tidak ditemukan, menggunakan matriks di memori.")
    citra = gambar

citra_rgb = cv2.cvtColor(citra, cv2.COLOR_BGR2RGB)
citra_gray = cv2.cvtColor(citra, cv2.COLOR_BGR2GRAY)

# Blur untuk menghaluskan tepi
blur = cv2.GaussianBlur(citra_gray, (5, 5), 0)

# Thresholding Inverse (Mengubah background putih menjadi hitam 0, objek menjadi putih 255)
ret, binary = cv2.threshold(blur, 127, 255, cv2.THRESH_BINARY_INV)

# Morfologi untuk menutup kecacatan/lubang kecil
kernel = np.ones((3, 3), np.uint8)
binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)

# ============================================
# LANGKAH 3: DETEKSI KONTUR DAN KLASIFIKASI BENTUK
# ============================================
print("\n[LANGKAH 3] Deteksi dan klasifikasi bentuk...")
contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
hasil = citra_rgb.copy()

def klasifikasi_bentuk(cnt):
    """Klasifikasikan bentuk berdasarkan jumlah titik sudut (vertex)"""
    # Menghitung keliling kontur
    peri = cv2.arcLength(cnt, True)
    
    # Polygon Approximation: menyederhanakan lekukan kontur menjadi poligon bersudut
    approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
    
    # Jumlah sudut (vertex) menentukan bentuk
    vertices = len(approx)
    
    if vertices == 3:
        return "Segitiga"
    elif vertices == 4:
        # Cek apakah persegi sempurna atau persegi panjang menggunakan Aspect Ratio
        x, y, w, h = cv2.boundingRect(cnt)
        aspect_ratio = w / float(h)
        if 0.95 <= aspect_ratio <= 1.05:
            return "Persegi"
        else:
            return "Persegi Panjang"
    else:
        # Cek apakah lingkaran atau elips menggunakan perbandingan luas
        (x, y), radius = cv2.minEnclosingCircle(cnt)
        area = cv2.contourArea(cnt)
        circle_area = np.pi * radius * radius
        if area / circle_area > 0.85:
            return "Lingkaran"
        else:
            return "Elips / Lainnya"

bentuk_terdeteksi = []

for i, cnt in enumerate(contours):
    area = cv2.contourArea(cnt)
    if area > 500: # Filter noise ukuran kecil
        bentuk = klasifikasi_bentuk(cnt)
        bentuk_terdeteksi.append(bentuk)
        
        # Gambar Bounding Box
        x, y, w, h = cv2.boundingRect(cnt)
        cv2.rectangle(hasil, (x, y), (x+w, y+h), (0, 255, 0), 2)
        
        # Tulis nama bentuk di atas kotak
        cv2.putText(hasil, bentuk, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
        print(f"Bentuk {i+1}: {bentuk}, area={area:.0f} px")

# ============================================
# LANGKAH 4: TAMPILKAN HASIL VISUAL
# ============================================
plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("1. Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(citra_gray, cmap='gray')
plt.title("2. Grayscale")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(binary, cmap='gray')
plt.title("3. Binary Segmented")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(hasil)
plt.title(f"4. HASIL: {len(bentuk_terdeteksi)} Bentuk Terdeteksi")
plt.axis('off')

# Buat grafik summary
summary = {}
for b in bentuk_terdeteksi:
    summary[b] = summary.get(b, 0) + 1

plt.subplot(2, 3, 5)
plt.bar(summary.keys(), summary.values(), color=['red', 'blue', 'green', 'orange', 'purple', 'cyan'])
plt.title("Ringkasan Statistik Bentuk")
plt.xticks(rotation=45)

plt.suptitle("PROYEK 2: Sistem Cerdas Klasifikasi Bentuk Geometri", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# LAPORAN AKHIR
# ============================================
print("\n" + "=" * 50)
print("PROYEK 2 SELESAI!")
print("=" * 50)
print("\n📊 HASIL KLASIFIKASI:")
for bentuk, jumlah in summary.items():
    print(f"  ➡️ {bentuk}: {jumlah} objek")