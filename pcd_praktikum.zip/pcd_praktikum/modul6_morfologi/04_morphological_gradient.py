import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 6: MORPHOLOGICAL GRADIENT
# ============================================
print("=" * 50)
print("MODUL 6: MORPHOLOGICAL GRADIENT")
print("=" * 50)

# ============================================
# APA ITU MORPHOLOGICAL GRADIENT?
# ============================================
print("\n[MORPHOLOGICAL GRADIENT]")
print("-" * 40)
print("Rumus dasar: Gradient = Dilasi - Erosi")
print("Efek        : Menampilkan 'tepi' sketsa dari objek")
print("Sifat       : Seperti deteksi tepi, khusus dioptimasikan untuk citra biner")

# Buat gambar geometri sederhana untuk demo dasar
gambar = np.zeros((200, 200), dtype=np.uint8)
cv2.circle(gambar, (100, 100), 60, 255, -1)
cv2.rectangle(gambar, (120, 120), (180, 180), 255, -1)
print("Gambar Demo: Kombinasi lingkaran + persegi yang saling bertumpuk.")

# ============================================
# HITUNG GRADIENT (PROSES UTAMA)
# ============================================
kernel = np.ones((5, 5), np.uint8)

# Metode Manual (Pengurangan Matriks Dasar)
dilated = cv2.dilate(gambar, kernel, iterations=1)
eroded = cv2.erode(gambar, kernel, iterations=1)
gradient_manual = dilated - eroded

# Metode Resmi OpenCV (Hasilnya persis sama)
gradient_cv = cv2.morphologyEx(gambar, cv2.MORPH_GRADIENT, kernel)

# ============================================
# BERBAGAI VARIASI JENIS GRADIENT
# ============================================
print("\n[BERBAGAI JENIS GRADIENT]")

# 1. Internal Gradient (Garis sketsa terbentuk di SISI DALAM batas asli objek)
internal_gradient = gambar - eroded

# 2. External Gradient (Garis sketsa terbentuk di SISI LUAR batas asli objek)
external_gradient = dilated - gambar

# ============================================
# TAMPILKAN HASIL EKSPERIMEN GEOMETRI (Jendela 1)
# ============================================
plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(gambar, cmap='gray')
plt.title("1. Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(eroded, cmap='gray')
plt.title("2. Hasil Erosi\n(Objek mengecil)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(dilated, cmap='gray')
plt.title("3. Hasil Dilasi\n(Objek membesar)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(gradient_cv, cmap='gray')
plt.title("4. Morphological Gradient\n(Dilasi - Erosi)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(internal_gradient, cmap='gray')
plt.title("5. Internal Gradient\n(Original - Erosi)")
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(external_gradient, cmap='gray')
plt.title("6. External Gradient\n(Dilasi - Original)")
plt.axis('off')

plt.suptitle("Morphological Gradient: Deteksi Tepi Berbasis Teori Himpunan Biner", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# PERBANDINGAN REAL: MORPHOLOGICAL GRADIENT vs SOBEL (Jendela 2)
# ============================================
print("\n" + "=" * 50)
print("[PERBANDINGAN MORPHOLOGICAL GRADIENT vs SOBEL]")
print("=" * 50)

# Memanggil foto saya.jpg menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_gray = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# Thresholding biner dasar
ret, binary = cv2.threshold(citra_gray, 127, 255, cv2.THRESH_BINARY)

# Jalankan Morphological Gradient pada citra biner
kernel_real = np.ones((3, 3), np.uint8)
morph_gradient = cv2.morphologyEx(binary, cv2.MORPH_GRADIENT, kernel_real)

# Jalankan Sobel Edge Detection pada citra grayscale asli
sobel_x = cv2.Sobel(citra_gray, cv2.CV_64F, 1, 0, ksize=3)
sobel_y = cv2.Sobel(citra_gray, cv2.CV_64F, 0, 1, ksize=3)
sobel_magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
sobel_out = np.clip(sobel_magnitude, 0, 255).astype(np.uint8)

plt.figure(figsize=(12, 8))

plt.subplot(2, 2, 1)
plt.imshow(citra_gray, cmap='gray')
plt.title("1. Original Grayscale")
plt.axis('off')

plt.subplot(2, 2, 2)
plt.imshow(binary, cmap='gray')
plt.title("2. Binary (Threshold T=127)")
plt.axis('off')

plt.subplot(2, 2, 3)
plt.imshow(morph_gradient, cmap='gray')
plt.title("3. Morphological Gradient\n(Sketsa Tepi dari Lapisan Biner)")
plt.axis('off')

plt.subplot(2, 2, 4)
plt.imshow(sobel_out, cmap='gray')
plt.title("4. Sobel Edge Detection\n(Sketsa Tepi dari Lapisan Grayscale)")
plt.axis('off')

plt.suptitle("Analisis Komparatif: Morphological Gradient vs Sobel", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN EVALUASI]")
print("-" * 40)
print("✅ Morphological Gradient sukses menggambar outline objek dengan ketebalan konstan sesuai ukuran kernel.")
print("✅ Keunggulan Jenis Variant:")
print("   - Standard Gradient: Garis tepi berpusat tepat membelah dinding asli objek.")
print("   - Internal Gradient: Garis tepi mengembang ke dalam tubuh objek (tidak merusak latar luar).")
print("   - External Gradient: Garis tepi mengembang keluar membungkus objek (halo effect).")
print("\n✅ Modul 6 - Bagian 4 selesai!")