import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 6: STRUCTURING ELEMENT (KERNEL MORFOLOGI)
# ============================================
print("=" * 50)
print("MODUL 6: STRUCTURING ELEMENT")
print("=" * 50)

# ============================================
# APA ITU STRUCTURING ELEMENT?
# ============================================
print("\n[STRUCTURING ELEMENT - SE]")
print("-" * 40)
print("Structuring Element = kernel yang digunakan untuk operasi morfologi")
print("Bentuk SE menentukan efek operasi pada objek")
print("\nOperasi morfologi: SE 'berjalan' di atas gambar seperti konvolusi")
print("Tapi bukan perkalian, melainkan operasi logika / teori himpunan (AND/OR atau MIN/MAX)")

# ============================================
# MEMBUAT STRUCTURING ELEMENT DENGAN OPENCV
# ============================================
print("\n[MEMBUAT SE DENGAN cv2.getStructuringElement()]")

# Bentuk-bentuk SE standar
ukuran = (5, 5) # Dimensi matriks 5x5 piksel

# 1. Rectangle (Persegi panjang/kotak penuh)
se_rect = cv2.getStructuringElement(cv2.MORPH_RECT, ukuran)
print("\n1. Rectangle SE (5x5):")
print(se_rect)

# 2. Ellipse / Circle (Lingkaran/elips)
se_ellipse = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, ukuran)
print("\n2. Ellipse SE (5x5):")
print(se_ellipse)

# 3. Cross (Silang/tanda tambah +)
se_cross = cv2.getStructuringElement(cv2.MORPH_CROSS, ukuran)
print("\n3. Cross SE (5x5):")
print(se_cross)

# ============================================
# MEMBUAT STRUCTURING ELEMENT CUSTOM SENDIRI
# ============================================
print("\n[SE CUSTOM - BUAT SENDIRI MATRIKSNYA]")

# Diamond (Wajik)
se_diamond = np.array([
    [0, 0, 1, 0, 0],
    [0, 1, 1, 1, 0],
    [1, 1, 1, 1, 1],
    [0, 1, 1, 1, 0],
    [0, 0, 1, 0, 0]
], dtype=np.uint8)
print("\nDiamond SE (5x5):")
print(se_diamond)

# Horizontal line (Garis tidur horizontal)
se_horizontal = np.array([
    [0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0]
], dtype=np.uint8)
print("\nHorizontal Line SE (3x5):")
print(se_horizontal)

# Vertical line (Garis tegak vertikal)
se_vertical = np.array([
    [0, 1, 0],
    [0, 1, 0],
    [0, 1, 0],
    [0, 1, 0],
    [0, 1, 0]
], dtype=np.uint8)
print("\nVertical Line SE (5x3):")
print(se_vertical)

# ============================================
# VISUALISASI STRUCTURING ELEMENT
# ============================================
print("\n[VISUALISASI SE]")

# Fungsi untuk memperbesar SE agar kotak pikselnya terlihat jelas saat di-plot
def display_se(se):
    # Skala matriks biner (0 dan 1) ke format citra hitam-putih (0 dan 255)
    se_display = (se * 255).astype(np.uint8)
    h, w = se_display.shape
    # Interpolasi NEAREST digunakan agar kotak piksel tetap tajam saat diperbesar
    se_resized = cv2.resize(se_display, (w * 30, h * 30), interpolation=cv2.INTER_NEAREST)
    return se_resized

plt.figure(figsize=(15, 8))

# 1. Rectangle
plt.subplot(2, 3, 1)
plt.imshow(display_se(se_rect), cmap='gray')
plt.title("Rectangle SE (5x5)")
plt.axis('off')

# 2. Ellipse
plt.subplot(2, 3, 2)
plt.imshow(display_se(se_ellipse), cmap='gray')
plt.title("Ellipse SE (5x5)")
plt.axis('off')

# 3. Cross
plt.subplot(2, 3, 3)
plt.imshow(display_se(se_cross), cmap='gray')
plt.title("Cross SE (5x5)")
plt.axis('off')

# 4. Diamond (Custom)
plt.subplot(2, 3, 4)
plt.imshow(display_se(se_diamond), cmap='gray')
plt.title("Diamond SE Custom (5x5)")
plt.axis('off')

# 5. Horizontal Line
plt.subplot(2, 3, 5)
h_h, w_h = se_horizontal.shape
se_h_resized = cv2.resize((se_horizontal * 255).astype(np.uint8), (w_h * 30, h_h * 30), interpolation=cv2.INTER_NEAREST)
plt.imshow(se_h_resized, cmap='gray')
plt.title("Horizontal Line SE (3x5)")
plt.axis('off')

# 6. Vertical Line
plt.subplot(2, 3, 6)
h_v, w_v = se_vertical.shape
se_v_resized = cv2.resize((se_vertical * 255).astype(np.uint8), (w_v * 30, h_v * 30), interpolation=cv2.INTER_NEAREST)
plt.imshow(se_v_resized, cmap='gray')
plt.title("Vertical Line SE (5x3)")
plt.axis('off')

plt.suptitle("Modul 6: Berbagai Bentuk Structuring Element (Kernel Morfologi)", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[PENJELASAN TARGET OPERASI]")
print("-" * 40)
print("➡️ Rectangle SE       : Memberikan efek pelebaran/pengikisan merata ke segala arah.")
print("➡️ Ellipse SE         : Memberikan efek melingkar, sangat bagus untuk menjaga bentuk alami objek.")
print("➡️ Cross/Diamond SE   : Efek manipulasi fokus pada arah mata angin utama (mempertahankan sudut tajam).")
print("➡️ Horiz/Vert Line SE : Hanya memanipulasi objek ke satu arah spesifik (ampuh menghapus garis pengganggu).")
print("\n✅ Modul 6 - Bagian 1 selesai!")