import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 6: OPENING DAN CLOSING
# ============================================
print("=" * 50)
print("MODUL 6: OPENING DAN CLOSING")
print("=" * 50)

# ============================================
# MEMBUAT GAMBAR GEOMETRI DENGAN NOISE
# ============================================
print("\n[MEMBUAT GAMBAR DENGAN NOISE]")
# Buat gambar dasar: kotak putih di atas kanvas hitam
gambar = np.zeros((200, 200), dtype=np.uint8)
cv2.rectangle(gambar, (50, 50), (150, 150), 255, -1)

# Tambahkan noise: titik putih kecil di luar objek (Salt Noise)
np.random.seed(42) # Mengunci seed agar noise acak konsisten
salt = np.random.random(gambar.shape) < 0.005
gambar[salt] = 255

# Tambahkan lubang kecil di dalam objek putih (Pepper Noise)
pepper = np.random.random(gambar.shape) < 0.005
gambar[pepper] = 0

print("Gambar buatan berhasil dimuat: Kotak putih dengan gangguan Salt & Pepper noise.")

# Kernel Kotak 5x5 untuk pemrosesan geometri
kernel = np.ones((5, 5), np.uint8)

# ============================================
# 1. OPERASI OPENING = EROSI ➡️ DILASI
# ============================================
print("\n[OPENING - Menghilangkan Noise di Luar Objek]")
print("Rumus: Opening = Dilasi(Erosi(gambar))")
opening = cv2.morphologyEx(gambar, cv2.MORPH_OPEN, kernel)

# Proses manual untuk verifikasi alur logika
eroded = cv2.erode(gambar, kernel, iterations=1)
opening_manual = cv2.dilate(eroded, kernel, iterations=1)

# ============================================
# 2. OPERASI CLOSING = DILASI ➡️ EROSI
# ============================================
print("\n[CLOSING - Menutup Lubang di Dalam Objek]")
print("Rumus: Closing = Erosi(Dilasi(gambar))")
closing = cv2.morphologyEx(gambar, cv2.MORPH_CLOSE, kernel)

# Proses manual untuk verifikasi alur logika
dilated = cv2.dilate(gambar, kernel, iterations=1)
closing_manual = cv2.erode(dilated, kernel, iterations=1)

# ============================================
# TAMPILKAN HASIL EKSPERIMEN GEOMETRI (Jendela 1)
# ============================================
plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(gambar, cmap='gray')
plt.title("1. Original\n(Kotak + Salt & Pepper Noise)")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(eroded, cmap='gray')
plt.title("2. Erosi (Langkah 1 Opening)\n(Noise putih hilang, kotak mengecil)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(opening, cmap='gray')
plt.title("3. HASIL OPENING\n(Noise luar hilang, ukuran normal)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(dilated, cmap='gray')
plt.title("4. Dilasi (Langkah 1 Closing)\n(Lubang menutup, kotak membesar)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(closing, cmap='gray')
plt.title("5. HASIL CLOSING\n(Lubang dalam tertutup, ukuran normal)")
plt.axis('off')

plt.suptitle("Mekanisme Opening vs Closing dalam Membersihkan Noise", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[PERBANDINGAN HASIL STATISTIK]")
print("-" * 40)
# BUG FIX: Memperbaiki baris string conditional print kode lab yang terpotong
status_salt = 'HILANG SEMPURNA' if not np.any(opening[salt] == 255) else 'MASIH ADA'
print(f"Status titik putih (salt) di luar setelah OPENING: {status_salt}")

status_pepper = 'TERTUTUP RAPAT' if closing[pepper].sum() > gambar[pepper].sum() else 'MASIH ADA'
print(f"Status lubang hitam (pepper) di dalam setelah CLOSING: {status_pepper}")

# ============================================
# DEMO PADA CITRA REAL / FOTO (Jendela 2)
# ============================================
print("\n" + "=" * 50)
print("[DEMO PADA FOTO DENGAN GANGGUAN NOISE]")
print("=" * 50)

# Memanggil foto saya.jpg menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_gray = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# Thresholding biner dasar
ret, binary = cv2.threshold(citra_gray, 127, 255, cv2.THRESH_BINARY)

# Beri gangguan noise tiruan secara acak pada citra biner
noise_map = np.random.random(binary.shape)
binary_noise = binary.copy()
binary_noise[noise_map < 0.02] = 0    # Pepper noise (Membuat lubang-lubang hitam)
binary_noise[noise_map > 0.98] = 255  # Salt noise (Membuat bintik-bintik putih)

# Terapkan fungsi filter morfologi khusus OpenCV (cv2.morphologyEx)
kernel_foto = np.ones((3, 3), np.uint8)
opening_result = cv2.morphologyEx(binary_noise, cv2.MORPH_OPEN, kernel_foto)
closing_result = cv2.morphologyEx(binary_noise, cv2.MORPH_CLOSE, kernel_foto)

plt.figure(figsize=(15, 10))

plt.subplot(2, 2, 1)
plt.imshow(binary, cmap='gray')
plt.title("1. Citra Biner Bersih")
plt.axis('off')

plt.subplot(2, 2, 2)
plt.imshow(binary_noise, cmap='gray')
plt.title("2. Citra Biner + Kerusakan Noise\n(Salt & Pepper Pasir)")
plt.axis('off')

plt.subplot(2, 2, 3)
plt.imshow(opening_result, cmap='gray')
plt.title("3. Filter OPENING\n(Bintik putih pasir di luar hilang)")
plt.axis('off')

plt.subplot(2, 2, 4)
plt.imshow(closing_result, cmap='gray')
plt.title("4. Filter CLOSING\n(Lubang pasir di dalam tubuh tertutup)")
plt.axis('off')

plt.suptitle("Aplikasi Real Pembersihan Citra via Opening & Closing", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN OPENING & CLOSING]")
print("-" * 40)
print("📌 OPENING (Erosi ➡️ Dilasi):")
print("   ✅ Sangat ampuh menghapus bintik putih pengganggu (Salt) yang bertebaran di latar belakang.")
print("   ✅ Sukses memutuskan jembatan/sambungan tipis yang tidak sengaja menghubungkan dua objek.")
print("   ⚠️ Catatan: Sama sekali tidak berpengaruh pada lubang hitam di dalam objek.")
print("\n📌 CLOSING (Dilasi ➡️ Erosi):")
print("   ✅ Sangat ampuh menyumbat lubang-lubang hitam (Pepper) yang merusak bagian dalam objek.")
print("   ✅ Sukses menyatukan kembali patahan atau retakan tipis pada objek struktur.")
print("   ⚠️ Catatan: Sama sekali tidak berpengaruh pada bintik putih di luar objek.")
print("\n✅ Modul 6 - Bagian 3 selesai!")