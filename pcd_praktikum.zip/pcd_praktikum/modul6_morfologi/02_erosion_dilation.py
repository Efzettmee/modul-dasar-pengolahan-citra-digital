import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 6: EROSI DAN DILASI
# ============================================
print("=" * 50)
print("MODUL 6: EROSI DAN DILASI")
print("=" * 50)

# ============================================
# MEMBUAT GAMBAR SEDERHANA UNTUK DEMO
# ============================================
print("\n[MEMBUAT GAMBAR DEMO]")
# Buat gambar biner sederhana (Kanvas hitam)
gambar = np.zeros((200, 200), dtype=np.uint8)
# Gambar kotak putih padat di tengah
cv2.rectangle(gambar, (50, 50), (150, 150), 255, -1) 
# Lubangi tengah kotak dengan lingkaran hitam (0)
cv2.circle(gambar, (100, 100), 40, 0, -1) 
print("Gambar Demo: Kotak putih 100x100 dengan lubang lingkaran di tengah berhasil dibuat.")

# ============================================
# EROSI (Erosion)
# ============================================
print("\n[EROSI - Penipisan / Menghilangkan Piksel Batas]")
print("Prinsip: Piksel bernilai 1 jika SEMUA elemen di bawah SE bernilai 1")
print("Efek   : Objek putih mengecil, lubang hitam membesar, noise putih hilang")

# Buat Structuring Element (SE) kotak penuh ukuran 5x5
kernel = np.ones((5, 5), np.uint8)

# Proses Erosi dengan berbagai variasi jumlah iterasi (pengulangan)
erosion_1 = cv2.erode(gambar, kernel, iterations=1)
erosion_3 = cv2.erode(gambar, kernel, iterations=3)
erosion_5 = cv2.erode(gambar, kernel, iterations=5)
erosion_10 = cv2.erode(gambar, kernel, iterations=10)

# ============================================
# DILASI (Dilation)
# ============================================
print("\n[DILASI - Penebalan / Menambah Piksel Batas]")
print("Prinsip: Piksel bernilai 1 jika MINIMAL ADA SATU elemen di bawah SE bernilai 1")
print("Efek   : Objek putih membesar, lubang hitam mengecil, menyambung retakan")

# Proses Dilasi dengan berbagai variasi jumlah iterasi
dilation_1 = cv2.dilate(gambar, kernel, iterations=1)
dilation_3 = cv2.dilate(gambar, kernel, iterations=3)
dilation_5 = cv2.dilate(gambar, kernel, iterations=5)
dilation_10 = cv2.dilate(gambar, kernel, iterations=10)

# ============================================
# TAMPILKAN HASIL DEMO GEOMETRI (Jendela 1)
# ============================================
plt.figure(figsize=(18, 12))

# Slot 1: Gambar Asli
plt.subplot(3, 4, 1)
plt.imshow(gambar, cmap='gray')
plt.title("Original (Kotak berlubang)")
plt.axis('off')

# Slot 2 s.d 5: Efek Erosi yang Semakin Mengikis
plt.subplot(3, 4, 2)
plt.imshow(erosion_1, cmap='gray')
plt.title("Erosi (iterasi=1)")
plt.axis('off')

plt.subplot(3, 4, 3)
plt.imshow(erosion_3, cmap='gray')
plt.title("Erosi (iterasi=3)")
plt.axis('off')

plt.subplot(3, 4, 4)
plt.imshow(erosion_5, cmap='gray')
plt.title("Erosi (iterasi=5)")
plt.axis('off')

plt.subplot(3, 4, 5)
plt.imshow(erosion_10, cmap='gray')
plt.title("Erosi (iterasi=10)\n(Objek hampir hilang!)")
plt.axis('off')

# Slot 6 s.d 9: Efek Dilasi yang Semakin Menggelembung
plt.subplot(3, 4, 6)
plt.imshow(dilation_1, cmap='gray')
plt.title("Dilasi (iterasi=1)")
plt.axis('off')

plt.subplot(3, 4, 7)
plt.imshow(dilation_3, cmap='gray')
plt.title("Dilasi (iterasi=3)")
plt.axis('off')

plt.subplot(3, 4, 8)
plt.imshow(dilation_5, cmap='gray')
plt.title("Dilasi (iterasi=5)")
plt.axis('off')

plt.subplot(3, 4, 9)
plt.imshow(dilation_10, cmap='gray')
plt.title("Dilasi (iterasi=10)\n(Lubang hitam menutup)")
plt.axis('off')

plt.suptitle("Perbandingan Erosi vs Dilasi dengan Berbagai Tingkat Iterasi", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# DEMO PADA GAMBAR ASLI / FOTO (Jendela 2)
# ============================================
print("\n[DEMO PADA GAMBAR ASLI]")

# Memanggil foto saya.jpg menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_gray = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# Thresholding biner untuk memisahkan warna padat
ret, binary = cv2.threshold(citra_gray, 127, 255, cv2.THRESH_BINARY)

# Terapkan erosi dan dilasi dasar sebanyak 1 iterasi
eroded = cv2.erode(binary, kernel, iterations=1)
dilated = cv2.dilate(binary, kernel, iterations=1)

plt.figure(figsize=(15, 8))

plt.subplot(1, 4, 1)
plt.imshow(citra_gray, cmap='gray')
plt.title("1. Original Grayscale")
plt.axis('off')

plt.subplot(1, 4, 2)
plt.imshow(binary, cmap='gray')
plt.title("2. Binary (Threshold T=127)")
plt.axis('off')

plt.subplot(1, 4, 3)
plt.imshow(eroded, cmap='gray')
plt.title("3. Hasil Erosi\n(Area putih mengecil)")
plt.axis('off')

plt.subplot(1, 4, 4)
plt.imshow(dilated, cmap='gray')
plt.title("4. Hasil Dilasi\n(Area putih membesar)")
plt.axis('off')

plt.suptitle("Eksperimen Erosi dan Dilasi pada Citra Real", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN EROSI & DILASI]")
print("-" * 40)
print("OPERASI EROSI:")
print("  ✅ Sangat ampuh menghilangkan 'noise' berupa bintik-bintik putih kecil.")
print("  ✅ Sukses memisahkan dua objek bertumpuk yang hampir menempel.")
print("  ❌ Efek samping: Ukuran asli objek utama ikut mengecil.")
print("\nOPERASI DILASI:")
print("  ✅ Sangat ampuh menutup lubang-lubang kecil (hole) di dalam objek.")
print("  ✅ Sukses menyambung garis atau retakan yang putus.")
print("  ❌ Efek samping: Ukuran objek membengkak, noise bintik putih ikut membesar.")
print("\n✅ Modul 6 - Bagian 2 selesai!")