import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 6: APLIKASI MORFOLOGI
# ============================================
print("=" * 50)
print("MODUL 6: APLIKASI MORFOLOGI")
print("=" * 50)

# ============================================
# APLIKASI 1: MENGHILANGKAN GARIS TIPIS (HITAM PADA LATAR BELAKANG)
# ============================================
print("\n[APLIKASI 1: MENGHILANGKAN GARIS TIPIS]")

# Buat gambar dengan garis tipis horizontal pengganggu
gambar_garis = np.zeros((200, 200), dtype=np.uint8)
cv2.rectangle(gambar_garis, (50, 50), (150, 150), 255, -1)
cv2.line(gambar_garis, (20, 100), (180, 100), 0, 2) # Garis tipis hitam (0) memotong objek

# Gunakan opening dengan kernel vertikal/persegi panjang tegak untuk memotong garis tidur
kernel_horizontal = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 5))
opening_horizontal = cv2.morphologyEx(gambar_garis, cv2.MORPH_OPEN, kernel_horizontal)

plt.figure(figsize=(12, 4))
plt.subplot(1, 3, 1)
plt.imshow(gambar_garis, cmap='gray')
plt.title("Original\n(Kotak + garis potong tipis)")
plt.axis('off')

plt.subplot(1, 3, 2)
# Perbesar kernel agar visualisasinya terlihat jelas di plot
k_h, k_w = kernel_horizontal.shape
plt.imshow(cv2.resize(kernel_horizontal * 255, (k_w*30, k_h*30), interpolation=cv2.INTER_NEAREST), cmap='gray')
plt.title("Kernel Matriks (1x5)")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(opening_horizontal, cmap='gray')
plt.title("Opening Horizontal\n(Garis hitam sukses terhapus!)")
plt.axis('off')

plt.suptitle("Aplikasi 1: Menghilangkan Garis Tipis dengan Opening", fontsize=14)
plt.tight_layout()
plt.show()

# ============================================
# APLIKASI 2: MENYAMBUNG OBJEK TERPUTUS
# ============================================
print("\n[APLIKASI 2: MENYAMBUNG OBJEK TERPUTUS]")

# Buat objek dummy dua lingkaran yang hampir menempel tapi ada celah putus
gambar_putus = np.zeros((200, 200), dtype=np.uint8)
cv2.circle(gambar_putus, (80, 100), 30, 255, -1)
cv2.circle(gambar_putus, (120, 100), 30, 255, -1)

# Gunakan closing dengan kernel tebal 10x10 untuk menjembatani celah
kernel_tebal = np.ones((10, 10), np.uint8)
closing_putus = cv2.morphologyEx(gambar_putus, cv2.MORPH_CLOSE, kernel_tebal)

plt.figure(figsize=(12, 4))
plt.subplot(1, 3, 1)
plt.imshow(gambar_putus, cmap='gray')
plt.title("Objek Terputus\n(Dua lingkaran terpisah)")
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(cv2.resize(kernel_tebal * 255, (10*15, 10*15), interpolation=cv2.INTER_NEAREST), cmap='gray')
plt.title("Kernel Tebal (10x10)")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(closing_putus, cmap='gray')
plt.title("Hasil CLOSING\n(Lingkaran berhasil tersambung!)")
plt.axis('off')

plt.suptitle("Aplikasi 2: Menyambung Struktur Terputus via Closing", fontsize=14)
plt.tight_layout()
plt.show()

# ============================================
# APLIKASI 3: EKSTRAKSI KERANGKA (SKELETONIZATION)
# ============================================
print("\n[APLIKASI 3: EKSTRAKSI KERANGKA - SKELETON]")

# Buat bentuk geometri: kotak putih berlubang lingkaran hitam di tengah
gambar_bentuk = np.zeros((200, 200), dtype=np.uint8)
cv2.rectangle(gambar_bentuk, (50, 50), (150, 150), 255, -1)
cv2.circle(gambar_bentuk, (100, 100), 40, 0, -1) 

# Proses perulangan algoritma penipisan (Skeletonization Loop)
skeleton = np.zeros_like(gambar_bentuk)
temp = gambar_bentuk.copy()
kernel_3x3 = np.ones((3, 3), np.uint8)
iterasi = 0

while True:
    eroded = cv2.erode(temp, kernel_3x3)
    opened = cv2.morphologyEx(eroded, cv2.MORPH_OPEN, kernel_3x3)
    # Ambil selisih struktur hasil kikis untuk disimpan ke dalam peta kerangka
    skeleton_segment = eroded - opened
    skeleton = cv2.bitwise_or(skeleton, skeleton_segment)
    temp = eroded.copy()
    iterasi += 1
    # Berhenti otomatis jika seluruh objek putih sudah habis terkikis (tinggal kerangka)
    if cv2.countNonZero(temp) == 0:
        break

print(f"Jumlah putaran iterasi untuk skeletonization: {iterasi}")

plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(gambar_bentuk, cmap='gray')
plt.title("Original (Kotak berlubang)")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(skeleton, cmap='gray')
plt.title("Hasil Skeleton / Kerangka\n(Garis tengah topologi objek)")
plt.axis('off')

plt.suptitle("Aplikasi 3: Ekstraksi Kerangka Geometri (Skeletonization)", fontsize=14)
plt.tight_layout()
plt.show()

# ============================================
# APLIKASI 4: TOP HAT DAN BLACK HAT
# ============================================
print("\n[APLIKASI 4: TOP HAT DAN BLACK HAT]")
print("Mengekstrak elemen noise mikro pencahayaan...")

# BUG FIX KODE LAB: Mengubah input dari 'gambar' (tidak ada) menjadi 'gambar_bentuk' agar tidak crash
# Top Hat = Original - Opening (Menyaring komponen terang yang lebih kecil dari ukuran kernel)
tophat = cv2.morphologyEx(gambar_bentuk, cv2.MORPH_TOPHAT, kernel_3x3)

# Black Hat = Closing - Original (Menyaring komponen lubang gelap yang lebih kecil dari ukuran kernel)
blackhat = cv2.morphologyEx(gambar_bentuk, cv2.MORPH_BLACKHAT, kernel_3x3)

plt.figure(figsize=(14, 5))
plt.subplot(1, 3, 1)
plt.imshow(gambar_bentuk, cmap='gray')
plt.title("Original Reference")
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(tophat, cmap='gray')
plt.title("Top Hat\n(Isolasi elemen putih mikro)")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(blackhat, cmap='gray')
plt.title("Black Hat\n(Isolasi elemen lubang hitam)")
plt.axis('off')

plt.suptitle("Aplikasi 4: Morfologi Lanjutan Top Hat & Black Hat", fontsize=14)
plt.tight_layout()
plt.show()

# ============================================
# RINGKASAN RELEVANSI INDUSTRI
# ============================================
print("\n[APLIKASI MORFOLOGI DALAM DUNIA NYATA]")
print("-" * 45)
print("1. OCR (Optical Character Recognition): Membersihkan noda debu hitam pada scan dokumen teks.")
print("2. Sistem Biometrik: Menggunakan Skeletonization untuk mengambil garis tengah alur sidik jari.")
print("3. Industri Manufaktur: Penggunaan Closing untuk menyambung jalur sirkuit PCB yang retak rambut.")
print("4. Analisis Citra Satelit: Menghilangkan bayangan jembatan kecil menggunakan Opening.")
print("\n✅ Modul 6 - Bagian 5 selesai!")