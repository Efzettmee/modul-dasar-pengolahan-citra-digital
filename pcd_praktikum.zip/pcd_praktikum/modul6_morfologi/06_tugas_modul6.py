import cv2
import matplotlib.pyplot as plt
import numpy as np
import os

# ============================================
# TUGAS MODUL 6: PRAKTIK MANDIRI
# ============================================
print("=" * 50)
print("TUGAS MODUL 6: PRAKTIK MANDIRI")
print("=" * 50)

# Baca gambar berwarna menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_gray = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2GRAY)

# ============================================
# TUGAS 1: Eksperimen berbagai bentuk SE
# ============================================
print("\n[TUGAS 1] Eksperimen Berbagai Bentuk Structuring Element")

# Buat binary dengan threshold Otsu otomatis
ret, binary = cv2.threshold(citra_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Berbagai variasi bentuk Structuring Element (SE) ukuran 5x5
se_rect    = cv2.getStructuringElement(cv2.MORPH_RECT,    (5, 5))
se_ellipse = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
se_cross   = cv2.getStructuringElement(cv2.MORPH_CROSS,   (5, 5))

# Aplikasikan operasi opening menggunakan masing-masing bentuk SE
opening_rect    = cv2.morphologyEx(binary, cv2.MORPH_OPEN, se_rect)
opening_ellipse = cv2.morphologyEx(binary, cv2.MORPH_OPEN, se_ellipse)
opening_cross   = cv2.morphologyEx(binary, cv2.MORPH_OPEN, se_cross)

plt.figure(figsize=(15, 10))

plt.subplot(2, 2, 1)
plt.imshow(binary, cmap='gray')
plt.title("Binary (Hasil Otsu)")
plt.axis('off')

plt.subplot(2, 2, 2)
plt.imshow(opening_rect, cmap='gray')
plt.title("Opening dengan Rectangle SE (5x5)")
plt.axis('off')

plt.subplot(2, 2, 3)
plt.imshow(opening_ellipse, cmap='gray')
plt.title("Opening dengan Ellipse SE (5x5)")
plt.axis('off')

plt.subplot(2, 2, 4)
plt.imshow(opening_cross, cmap='gray')
plt.title("Opening dengan Cross SE (5x5)")
plt.axis('off')

plt.suptitle("TUGAS 1: Pengaruh Bentuk Structuring Element terhadap Kontur Objek", fontsize=14)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Bagaimana pengaruh bentuk SE terhadap hasil?")
print("Jawab: Bentuk SE menentukan arah pengikisan dan pengembangan geometri objek.")
print("Analisis:")
print("  - Rectangle SE mengikis sudut secara kaku dan mempertahankan bentuk kotak.")
print("  - Ellipse SE memotong sudut dengan halus melingkar, optimal menjaga kontur")
print("    alami tubuh/wajah karena mengikuti bentuk kurva organik.")
print("  - Cross SE hanya fokus mengikis pada 4 arah mata angin utama (+), sehingga")
print("    sudut-sudut diagonal objek tetap tajam dan tidak terpotong.")

# ============================================
# TUGAS 2: Membersihkan gambar dari noise
# ============================================
print("\n[TUGAS 2] Membersihkan Gambar dari Noise")

# Buat gambar dengan noda noise tiruan Salt & Pepper sebesar 2% masing-masing
binary_noise = binary.copy()
np.random.seed(42)  # Mengunci seed agar hasil reproducible
noise_salt   = np.random.random(binary.shape) < 0.02   # 2% piksel jadi putih
noise_pepper = np.random.random(binary.shape) < 0.02   # 2% piksel jadi hitam
binary_noise[noise_salt]   = 255
binary_noise[noise_pepper] = 0

# Kernel 3x3 untuk operasi morfologi
kernel = np.ones((3, 3), np.uint8)

# Opening mandiri: menghapus bintik putih (salt) di luar objek
opening_result = cv2.morphologyEx(binary_noise, cv2.MORPH_OPEN, kernel)

# Closing mandiri: menutup lubang hitam (pepper) di dalam objek
closing_result = cv2.morphologyEx(binary_noise, cv2.MORPH_CLOSE, kernel)

# Pipeline: Opening terlebih dahulu, lalu langsung Closing (pembersihan total)
opening_then_closing = cv2.morphologyEx(opening_result, cv2.MORPH_CLOSE, kernel)

plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(binary, cmap='gray')
plt.title("Original Bersih")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(binary_noise, cmap='gray')
plt.title("+ Salt & Pepper Noise (2%+2%)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(opening_result, cmap='gray')
plt.title("Opening Mandiri\n(Hilangkan salt/bintik putih)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(closing_result, cmap='gray')
plt.title("Closing Mandiri\n(Hilangkan pepper/lubang hitam)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(opening_then_closing, cmap='gray')
plt.title("Pipeline: Opening -> Closing\n(Bersih total dari kedua noise!)")
plt.axis('off')

plt.suptitle("TUGAS 2: Restorasi Citra dari Gangguan Salt & Pepper via Opening & Closing",
             fontsize=14)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Metode mana yang paling efektif membersihkan noise?")
print("Jawab: Kombinasi sekuensial OPENING dilanjutkan CLOSING (pipeline berlapis).")
print("Analisis:")
print("  - Opening mandiri hanya mampu melenyapkan bintik putih luar (Salt).")
print("  - Closing mandiri hanya mampu menyumbat lubang hitam dalam (Pepper).")
print("  - Pipeline Opening -> Closing menggabungkan keduanya, sehingga citra biner")
print("    dapat dikembalikan ke kondisi mulus asli secara utuh dan bebas dari")
print("    kedua jenis noise sekaligus.")

# ============================================
# TUGAS 3: Memisahkan objek yang menempel
# ============================================
print("\n[TUGAS 3] Memisahkan Objek yang Menempel")

# Buat citra simulasi 300x300 dengan 3 lingkaran putih yang saling menempel
gambar_menempel = np.zeros((300, 300), dtype=np.uint8)
cv2.circle(gambar_menempel, (100, 150), 50, 255, -1)  # Lingkaran kiri
cv2.circle(gambar_menempel, (200, 150), 50, 255, -1)  # Lingkaran kanan
cv2.circle(gambar_menempel, (150, 100), 50, 255, -1)  # Lingkaran atas tengah

# Kernel 5x5 untuk operasi tebal
kernel_split = np.ones((5, 5), np.uint8)

# Langkah 1: Erosi tebal iterations=4 untuk memutus jembatan penghubung
eroded = cv2.erode(gambar_menempel, kernel_split, iterations=4)

# Langkah 2: Dilasi iterations=4 untuk mengembalikan ukuran asli (tidak menyambung ulang)
dilated = cv2.dilate(eroded, kernel_split, iterations=4)

plt.figure(figsize=(12, 5))

plt.subplot(1, 3, 1)
plt.imshow(gambar_menempel, cmap='gray')
plt.title("3 Lingkaran Saling Menempel")
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(eroded, cmap='gray')
plt.title("Setelah Erosi (iterations=4)\nJembatan terputus, objek mengecil")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(dilated, cmap='gray')
plt.title("Setelah Dilasi (iterations=4)\nUkuran kembali, tetap terpisah!")
plt.axis('off')

plt.suptitle("TUGAS 3: Pemisahan Objek Menempel dengan Erosi Tebal + Dilasi", fontsize=14)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Apakah erosi berhasil memisahkan objek yang menempel?")
print("Jawab: Ya, berhasil dengan rapi menggunakan kombinasi Erosi tebal lalu Dilasi.")
print("Analisis:")
print("  - Bagian jembatan/leher penghubung antar lingkaran lebih tipis dari badan inti.")
print("  - Erosi iterations=4 memotong habis jembatan tersebut sehingga objek terbelah.")
print("  - Dilasi iterations=4 mengembangkan kembali sisa badan inti masing-masing")
print("    tanpa menyatukannya kembali, karena koordinat piksel penghubungnya")
print("    sudah bernilai 0 dan tidak ada lagi yang bisa dikembangkan ke arah sana.")

# ============================================
# TUGAS 4: Simpan hasil terbaik
# ============================================
print("\n[TUGAS 4] Simpan Hasil Morfologi Terbaik")

# Alur prapemrosesan morfologi terbaik: Otsu -> Opening -> Closing
ret, binary_clean = cv2.threshold(citra_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
kernel_best = np.ones((3, 3), np.uint8)
opened      = cv2.morphologyEx(binary_clean, cv2.MORPH_OPEN,  kernel_best)
hasil_akhir = cv2.morphologyEx(opened,       cv2.MORPH_CLOSE, kernel_best)

# Buat folder output otomatis
folder_output = 'hasil_output'
os.makedirs(folder_output, exist_ok=True)

# Ekspor hasil akhir ke disk
path_simpan = os.path.join(folder_output, 'modul6_hasil_morfologi.jpg')
cv2.imwrite(path_simpan, hasil_akhir)
print(f"Berhasil! Hasil morfologi disimpan di: {path_simpan}")

plt.figure(figsize=(12, 8))

plt.subplot(2, 2, 1)
plt.imshow(citra_gray, cmap='gray')
plt.title("1. Original Grayscale")
plt.axis('off')

plt.subplot(2, 2, 2)
plt.imshow(binary_clean, cmap='gray')
plt.title("2. Binary (Otsu Thresholding)")
plt.axis('off')

plt.subplot(2, 2, 3)
plt.imshow(opened, cmap='gray')
plt.title("3. Setelah Opening\n(Noise salt dihapus)")
plt.axis('off')

plt.subplot(2, 2, 4)
plt.imshow(hasil_akhir, cmap='gray')
plt.title("4. Hasil Akhir: Opening + Closing\n(Bersih dan tersimpan)")
plt.axis('off')

plt.suptitle("TUGAS 4: Alur Ekspor Hasil Morfologi Terbaik (Otsu -> Opening -> Closing)",
             fontsize=14)
plt.tight_layout()
plt.show()

# ============================================
# RINGKASAN MODUL 6
# ============================================
print("\n" + "=" * 50)
print("RINGKASAN MODUL 6")
print("=" * 50)
print("\nKompetensi yang Sudah Dipelajari:")
print("1. Structuring Element (Bentuk cetakan penentu arah manipulasi biner).")
print("2. Erosi   : Pengikisan dinding luar objek, memusnahkan noda salt.")
print("3. Dilasi  : Penebalan dinding objek, menyumbat lubang pepper.")
print("4. Opening = Erosi -> Dilasi  (Hapus bintik luar, ukuran tetap).")
print("5. Closing = Dilasi -> Erosi  (Tutup lubang dalam, ukuran tetap).")
print("6. Morphological Gradient = Dilasi - Erosi (Outline biner konstan).")
print("7. Top Hat   = Original - Opening (Isolasi noda terang mikro).")
print("8. Black Hat = Closing - Original (Isolasi retakan/lubang gelap).")

print("\nCheat-Sheet Pemilihan Operasi:")
print("  Ada bintik/pasir putih di luar objek  --> OPENING")
print("  Ada rongga/lubang hitam di dalam objek --> CLOSING")
print("  Objek biner terlalu melar/gemuk        --> EROSI")
print("  Objek biner terlalu kurus/tipis        --> DILASI")
print("  Butuh kerangka outline luar            --> GRADIENT")
print("  Objek saling menempel                  --> EROSI tebal + DILASI")

print("\nMODUL 6 SELESAI!")