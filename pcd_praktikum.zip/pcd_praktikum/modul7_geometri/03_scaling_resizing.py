import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 7: SCALING DAN RESIZING
# ============================================
print("=" * 50)
print("MODUL 7: SCALING DAN RESIZING")
print("=" * 50)

# Baca gambar menggunakan Smart Path (Memuat foto saya.jpg)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
h, w = citra_rgb.shape[:2]
print(f"Dimensi asli gambar: {h} x {w}")

# ============================================
# KONSEP SCALING
# ============================================
print("\n[KONSEP SCALING]")
print("-" * 40)
print("Scaling = mengubah resolusi dimensi spasial citra")
print("Algoritma matematika interpolasi menentukan kualitas piksel hasil rekonstruksi")
print("\nMetode Interpolation:")
print("- INTER_NEAREST  : Mengambil piksel terdekat. Tercepat, tapi patah-patah/piksulasi")
print("- INTER_LINEAR   : Interpolasi bilinear standar. Seimbang antara kecepatan & kualitas")
print("- INTER_CUBIC    : Interpolasi bikubik 4x4 piksel sekitar. Lebih halus, tajam, agak lambat")
print("- INTER_LANCZOS4 : Interpolasi berbasis sinc 8x8 piksel sekitar. Kualitas tertinggi, paling lambat")

# ============================================
# SCALING DENGAN BERBAGAI FAKTOR SKALA
# ============================================
print("\n[SCALING DENGAN BERBAGAI FAKTOR]")
scale_factors = [(0.25, 0.25), (0.5, 0.5), (0.75, 0.75), (1.5, 1.5), (2.0, 2.0), (0.5, 2.0)]
scaled_images = []

for fx, fy in scale_factors:
    w_baru = int(w * fx)
    h_baru = int(h * fy)
    # Jika fx dan fy dimasukkan, parameter dsize diisi (0,0) atau sebaliknya
    scaled = cv2.resize(citra_rgb, (w_baru, h_baru), interpolation=cv2.INTER_LINEAR)
    scaled_images.append(scaled)

# ============================================
# PERBANDINGAN METODE INTERPOLASI (UP_SCALE)
# ============================================
print("\n[PERBANDINGAN METODE INTERPOLASI]")
# Perbesar ekstrem sebanyak 5 kali lipat untuk membandingkan performa rekonstruksi piksel
w_besar = w * 5
h_besar = h * 5

nearest = cv2.resize(citra_rgb, (w_besar, h_besar), interpolation=cv2.INTER_NEAREST)
linear = cv2.resize(citra_rgb, (w_besar, h_besar), interpolation=cv2.INTER_LINEAR)
cubic = cv2.resize(citra_rgb, (w_besar, h_besar), interpolation=cv2.INTER_CUBIC)
lanczos = cv2.resize(citra_rgb, (w_besar, h_besar), interpolation=cv2.INTER_LANCZOS4)

# ============================================
# RESIZE KE UKURAN TARGET TERTENTU (ASPECT RATIO BEBAS)
# ============================================
print("\n[RESIZE KE UKURAN TERTENTU]")
ukuran_target = [(200, 200), (100, 300), (300, 100), (500, 500)]
resized_images = []

for target_w, target_h in ukuran_target:
    resized = cv2.resize(citra_rgb, (target_w, target_h), interpolation=cv2.INTER_LINEAR)
    resized_images.append(resized)

# ============================================
# TAMPILKAN HASIL JENDELA 1: BERBAGAI FAKTOR SKALA RATIO
# ============================================
plt.figure(figsize=(15, 10))

plt.subplot(2, 4, 1)
plt.imshow(citra_rgb)
plt.title(f"Original ({w}x{h})")
plt.axis('off')

for i, ((fx, fy), img) in enumerate(zip(scale_factors, scaled_images), 2):
    plt.subplot(2, 4, i)
    plt.imshow(img)
    plt.title(f"Scale ({fx}, {fy})\n{img.shape[1]}x{img.shape[0]}")
    plt.axis('off')

plt.suptitle("Scaling: Eksperimen Memperbesar/Memperkecil Dimensi Gambar", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# TAMPILKAN JENDELA 2: PERBANDINGAN STRUKTUR PIKSEL INTERPOLASI
# ============================================
plt.figure(figsize=(15, 10))

# Ambil cuplikan area koordinat tengah (100x100 piksel) agar perbedaan komparasi terlihat jelas
mid_h, mid_w = h // 2, w // 2
detail_region = slice(max(0, mid_h - 50), min(h, mid_h + 50)), slice(max(0, mid_w - 50), min(w, mid_w + 50))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb[detail_region])
plt.title("Original Reference (Detail)")
plt.axis('off')

# Sinkronisasi perkalian indeks daerah pembesaran 5x lipat
h_start, h_stop = detail_region[0].start * 5, detail_region[0].stop * 5
w_start, w_stop = detail_region[1].start * 5, detail_region[1].stop * 5

plt.subplot(2, 3, 2)
plt.imshow(nearest[h_start:h_stop, w_start:w_stop])
plt.title("INTER_NEAREST\n(Efek jaggies/kotak-kotak tajam)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(linear[h_start:h_stop, w_start:w_stop])
plt.title("INTER_LINEAR\n(Bilinear - Halus standar)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(cubic[h_start:h_stop, w_start:w_stop])
plt.title("INTER_CUBIC\n(Bikubik - Lebih tajam & rata)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(lanczos[h_start:h_stop, w_start:w_stop])
plt.title("INTER_LANCZOS4\n(Sinc 8x8 - Kualitas rekonstruksi terbaik)")
plt.axis('off')

plt.suptitle("Analisis Mikro: Komparasi Kualitas Algoritma Interpolasi Spasial (Magnifikasi 5x)", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# TAMPILKAN JENDELA 3: RESIZE STRETCHING
# ============================================
plt.figure(figsize=(15, 8))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title(f"Original ({w}x{h})")
plt.axis('off')

for i, ((tw, th), img) in enumerate(zip(ukuran_target, resized_images), 2):
    plt.subplot(2, 3, i)
    plt.imshow(img)
    plt.title(f"Resize Paksa ke {tw}x{th}")
    plt.axis('off')

plt.suptitle("Resize Spasial: Penyesuaian Kanvas ke Ukuran Target Statis", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN EVALUASI SCALING]")
print("-" * 45)
print("✅ Gambar ditarik tidak proporsional (stretching) jika rasio fx dan fy berbeda (contoh: Scale 0.5, 2.0).")
print("✅ Karakteristik Hasil Interpolasi:")
print("   - NEAREST : Menjaga nilai asli piksel tanpa modifikasi warna baru, sangat bagus untuk pixel-art/citra biner lab.")
print("   - LINEAR  : Pilihan default paling aman untuk komputasi real-time.")
print("   - CUBIC/LANCZOS4: Menghasilkan kurva gradasi warna baru yang sangat halus saat memperbesar foto potret.")
print("\n✅ Modul 7 - Bagian 3 selesai!")