import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 7: AFFINE TRANSFORMATION
# ============================================
print("=" * 50)
print("MODUL 7: AFFINE TRANSFORMATION")
print("=" * 50)

# Baca gambar menggunakan Smart Path (Memuat foto saya.jpg)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
h, w = citra_rgb.shape[:2]
print(f"Dimensi gambar: {h} x {w}")

# ============================================
# KONSEP AFFINE TRANSFORMATION
# ============================================
print("\n[KONSEP AFFINE TRANSFORMATION]")
print("-" * 40)
print("Affine = transformasi linear (rotasi, scale, shear) + translasi")
print("Metode: Memetakan 3 titik koordinat jangkar input ke 3 titik tujuan output")
print("Sifat mutlak: Garis sejajar pada gambar asli AKAN TETAP SEJAJAR setelah ditransformasi")

# ============================================
# AFFINE DENGAN 3 TITIK
# ============================================
print("\n[AFFINE DENGAN 3 TITIK]")
# Tentukan segitiga koordinat 3 titik jangkar asal pada gambar asli (Top-Left, Top-Right, Bottom-Left)
pts1 = np.float32([[50, 50], [200, 50], [50, 200]])

# Tentukan 3 titik baru tujuan (Digeser sedemikian rupa untuk menciptakan efek tarikan miring/distorsi)
pts2 = np.float32([[10, 100], [200, 50], [100, 250]])

# Hitung matriks Affine 2x3 secara otomatis berdasarkan pemetaan 3 koordinat segitiga tersebut
M_3pts = cv2.getAffineTransform(pts1, pts2)

# Terapkan transformasi spasial
affine_3pts = cv2.warpAffine(citra_rgb, M_3pts, (w, h))

# ============================================
# AFFINE UNTUK SHEAR (MENGEFEK MIRING)
# ============================================
print("\n[AFFINE UNTUK SHEAR - MIRING KANAN/BAWAH]")

# 1. Shear Horizontal (Mendorong piksel baris atas secara linear sesuai ketinggian Y)
M_shear_x = np.float32([[1, 0.5, 0], [0, 1, 0]])
# Kanvas output dilebarkan 1.5x agar hasil tarikan miring tidak terpotong bingkai
shear_x = cv2.warpAffine(citra_rgb, M_shear_x, (int(w * 1.5), h))

# 2. Shear Vertikal (Mendorong piksel kolom samping secara linear sesuai lebar X)
M_shear_y = np.float32([[1, 0, 0], [0.5, 1, 0]])
shear_y = cv2.warpAffine(citra_rgb, M_shear_y, (w, int(h * 1.5)))

# ============================================
# AFFINE UNTUK REFLEKSI (MENCERMINKAN/MIRROR)
# ============================================
print("\n[AFFINE UNTUK REFLEKSI]")

# 1. Refleksi Horizontal (Membalik sumbu X ke arah negatif, lalu didorong dx sejauh lebar w)
M_reflect_h = np.float32([[-1, 0, w], [0, 1, 0]])
reflect_h = cv2.warpAffine(citra_rgb, M_reflect_h, (w, h))

# 2. Refleksi Vertikal (Membalik sumbu Y ke arah negatif, lalu didorong dy sejauh tinggi h)
M_reflect_v = np.float32([[1, 0, 0], [0, -1, h]])
reflect_v = cv2.warpAffine(citra_rgb, M_reflect_v, (w, h))

# ============================================
# KOMBINASI AFFINE SIMULTAN
# ============================================
print("\n[KOMBINASI TRANSFORMASI]")
# Ambil matriks dasar rotasi 15 derajat + perbesaran scale 1.2 kali lipat
M_combined = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), 15, 1.2)

# Modifikasi matriks secara langsung pada index shear horizontal (Baris 0, Kolom 1)
M_combined[0, 1] += 0.3
combined = cv2.warpAffine(citra_rgb, M_combined, (w, h))

# ============================================
# TAMPILKAN HASIL JENDELA UTAMA (Jendela 1)
# ============================================
plt.figure(figsize=(15, 12))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("1. Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(affine_3pts)
plt.title("2. Affine via 3 Titik Segitiga\n(Efek distorsi bebas)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(shear_x)
plt.title("3. Shear Horizontal")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(shear_y)
plt.title("4. Shear Vertical")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(reflect_h)
plt.title("5. Refleksi Horizontal\n(Mirror Kiri-Kanan)")
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(reflect_v)
plt.title("6. Refleksi Vertical\n(Mirror Atas-Bawah)")
plt.axis('off')

plt.suptitle("Affine Transformation: Shear, Refleksi, dan Pemetaan Spasial", fontsize=16)
plt.tight_layout()
plt.show()

# Tampilkan hasil kombinasi simultan (Jendela 2)
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(citra_rgb)
plt.title("Original Reference")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(combined)
plt.title("Hasil Gabungan simultan\n(Rotasi + Scale + Shear)")
plt.axis('off')

plt.suptitle("Kombinasi Multi-Transformasi Affine dalam Satu Langkah", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN EVALUASI AFFINE]")
print("-" * 40)
print("✅ Transformasi Affine menjamin garis lurus yang sejajar akan TETAP SEJAJAR.")
print("✅ Teknik 3-titik segitiga sangat ampuh untuk meluruskan dokumen miring hasil jepretan kamera ponsel.")
print("✅ Shear memiringkan koordinat gambar dengan menggeser baris secara proporsional.")
print("✅ Refleksi biner menggunakan koefisien negatif pada elemen diagonal utama matriks.")
print("\nAugmentasi Data: Sangat vital untuk melatih model AI (Deep Learning) agar kebal posisi!")
print("\n✅ Modul 7 - Bagian 4 selesai!")