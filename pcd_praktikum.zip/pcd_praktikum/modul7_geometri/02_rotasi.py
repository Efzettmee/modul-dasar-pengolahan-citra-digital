import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 7: ROTASI (MEMUTAR GAMBAR)
# ============================================
print("=" * 50)
print("MODUL 7: ROTASI - MEMUTAR GAMBAR")
print("=" * 50)

# Baca gambar menggunakan Smart Path (Memuat foto saya.jpg)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
h, w = citra_rgb.shape[:2]
print(f"Dimensi gambar: {h} x {w}")

# ============================================
# KONSEP ROTASI
# ============================================
print("\n[KONSEP ROTASI]")
print("-" * 40)
print("Rotasi = memutar gambar di sekitar titik pusat poros tertentu")
print("Fungsi pencari matriks: M = cv2.getRotationMatrix2D(center, angle, scale)")

# ============================================
# ROTASI DENGAN BERBAGAI SUDUT
# ============================================
print("\n[ROTASI DENGAN BERBAGAI SUDUT]")
sudut = [15, 30, 45, 60, 90, 135, 180, 270]
rotasi_hasil = []

for angle in sudut:
    # Dapatkan matriks transformasi rotasi (Pusat dipasang tepat di tengah gambar)
    M = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, 1.0)
    rotated = cv2.warpAffine(citra_rgb, M, (w, h))
    rotasi_hasil.append(rotated)

# ============================================
# ROTASI DENGAN UKURAN OUTPUT YANG DIPERBESAR
# ============================================
print("\n[ROTASI DENGAN OUTPUT DIPERBESAR AGAR TIDAK TERPOTONG]")

# Hitung dimensi baru secara matematis menggunakan proyeksi bounding box sinus cosinus
angle_test = 45
rad = np.radians(angle_test)
sin = np.sin(rad)
cos = np.cos(rad)

w_baru = int((h * abs(sin)) + (w * abs(cos)))
h_baru = int((h * abs(cos)) + (w * abs(sin)))

# Bangun kembali matriks rotasi awal
M_unclip = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle_test, 1.0)

# Koreksi translasi matriks (Menambahkan pergeseran agar gambar terdorong ke tengah kanvas baru)
M_unclip[0, 2] += (w_baru - w) / 2.0
M_unclip[1, 2] += (h_baru - h) / 2.0

rotasi_tidak_terpotong = cv2.warpAffine(citra_rgb, M_unclip, (w_baru, h_baru))

# ============================================
# TAMPILKAN HASIL JENDELA UTAMA (Jendela 1)
# ============================================
plt.figure(figsize=(15, 12))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("1. Original")
plt.axis('off')

# Looping otomatis mengisi slot 2 sampai 6 untuk variasi sudut pertama
for i, (angle, hasil) in enumerate(zip(sudut[:5], rotasi_hasil[:5]), 2):
    plt.subplot(2, 3, i)
    plt.imshow(hasil)
    plt.title(f"Rotasi {angle}°")
    plt.axis('off')

plt.suptitle("Rotasi Gambar dengan Berbagai Sudut Spasial", fontsize=16)
plt.tight_layout()
plt.show()

# Tampilkan rotasi sudut ekstrem dan hasil anti-potong (Jendela 2)
plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1)
plt.imshow(rotasi_hasil[5]) # Sudut 135°
plt.title("Rotasi 135° (Terpotong)")
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(rotasi_hasil[6]) # Sudut 180° (Terbalik)
plt.title("Rotasi 180°")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(rotasi_tidak_terpotong)
plt.title("Rotasi 45° (Kanvas Diperbesar/Utuh)")
plt.axis('off')

plt.suptitle("Analisis Rotasi Lanjutan dan Output Tanpa Clipping", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# ROTASI DENGAN SCALE / COMBINED TRANSFORM (Jendela 3)
# ============================================
print("\n[ROTASI + SCALING]")
scale_values = [0.5, 0.75, 1.0, 1.25] # Dikurangi ke 4 elemen agar muat grid 2x3 sempurna

plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("Original Reference")
plt.axis('off')

# BUG FIX KODE LAB: Ukuran output warpAffine dikunci ke (w,h) agar pusat perputaran matriks tetap presisi di tengah
for i, scale in enumerate(scale_values, 2):
    M_scaled = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), 30, scale)
    rotated_scaled = cv2.warpAffine(citra_rgb, M_scaled, (w, h))
    plt.subplot(2, 3, i)
    plt.imshow(rotated_scaled)
    plt.title(f"Rotasi 30°, Scale = {scale}")
    plt.axis('off')

plt.suptitle("Kombinasi Affine Simultan: Rotasi + Scaling Berpusat", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN OPERASI ROTASI]")
print("-" * 40)
print("✅ Nilai sudut POSITIF = Memutar gambar BERLAWANAN arah jarum jam (Counter-Clockwise).")
print("✅ Nilai sudut NEGATIF = Memutar gambar SEARAH jarum jam (Clockwise).")
print("✅ Pojok bingkai yang berputar keluar frame akan terkena clipping (terpotong hitam).")
print("✅ Formula bounding box sinus-cosinus sukses menghitung ukuran kanvas anti-potong.")
print("✅ Parameter scale > 1.0 memperbesar objek, scale < 1.0 memperkecil objek secara internal.")
print("\n✅ Modul 7 - Bagian 2 selesai!")