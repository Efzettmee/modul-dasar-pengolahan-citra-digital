import cv2
import matplotlib.pyplot as plt
import numpy as np
import os

# ============================================
# TUGAS MODUL 7: PRAKTIK MANDIRI
# ============================================
print("=" * 50)
print("TUGAS MODUL 7: PRAKTIK MANDIRI")
print("=" * 50)

# Baca gambar menggunakan Smart Path
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
h, w = citra_rgb.shape[:2]

# ============================================
# TUGAS 1: Kombinasi Translasi, Rotasi, Scale
# ============================================
print("\n[TUGAS 1] Kombinasi Translasi + Rotasi + Scale")

# Buat matriks rotasi: sudut 20 derajat, skala 1.2x, berpusat di tengah gambar
M_rotate = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), 20, 1.2)

# Gabungkan translasi dx=30, dy=30 langsung ke kolom ketiga matriks Affine
M_combined = M_rotate.copy()
M_combined[0, 2] += 30   # geser kanan 30 piksel
M_combined[1, 2] += 30   # geser bawah 30 piksel

# Terapkan transformasi gabungan
kombinasi = cv2.warpAffine(citra_rgb, M_combined, (w, h))

plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.imshow(citra_rgb)
plt.title("Original")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(kombinasi)
plt.title("Kombinasi: Geser(30,30) + Rotasi(20°) + Scale(1.2x)")
plt.axis('off')

plt.suptitle("TUGAS 1: Transformasi Kombinasi Affine (Translasi + Rotasi + Scale)", fontsize=14)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Bagaimana cara menggabungkan beberapa transformasi sekaligus?")
print("Jawab: Dengan memodifikasi elemen kolom ketiga matriks Affine secara langsung.")
print("Analisis:")
print("  - Matriks Affine 2x3 dari cv2.getRotationMatrix2D() sudah berisi informasi")
print("    rotasi dan skala di kolom 1 dan 2.")
print("  - Nilai translasi (dx, dy) cukup ditambahkan ke elemen [0,2] dan [1,2]")
print("    sehingga satu kali panggil cv2.warpAffine() menghasilkan ketiga efek sekaligus.")
print("  - Pendekatan ini lebih efisien daripada memanggil warpAffine() berkali-kali.")

# ============================================
# TUGAS 2: Efek Zoom In pada Area Tertentu
# ============================================
print("\n[TUGAS 2] Efek Zoom In pada Area Tertentu")

# Pelindung dinamis agar koordinat tidak melampaui batas resolusi gambar
zoom_x = min(200, w // 2)
zoom_y = min(200, h // 2)
zoom_w = min(150, w - zoom_x)
zoom_h = min(150, h - zoom_y)

print(f"Koordinat Zoom-In: X={zoom_x}, Y={zoom_y}, Ukuran={zoom_w}x{zoom_h} piksel")

# Crop sub-area menggunakan slicing NumPy
area_zoom = citra_rgb[zoom_y:zoom_y + zoom_h, zoom_x:zoom_x + zoom_w]

# Perbesar 3x menggunakan interpolasi INTER_LANCZOS4 (kualitas tertinggi)
zoom_factor = 3
zoom_in = cv2.resize(
    area_zoom,
    (zoom_w * zoom_factor, zoom_h * zoom_factor),
    interpolation=cv2.INTER_LANCZOS4
)

# Tandai area zoom pada gambar referensi dengan kotak biru
citra_tanda = citra_rgb.copy()
cv2.rectangle(
    citra_tanda,
    (zoom_x, zoom_y),
    (zoom_x + zoom_w, zoom_y + zoom_h),
    (0, 0, 255),   # Biru dalam format RGB
    3
)

plt.figure(figsize=(15, 6))

plt.subplot(1, 3, 1)
plt.imshow(citra_tanda)
plt.title("Original + Kotak Area Zoom (Biru)")
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(area_zoom)
plt.title(f"Area Crop ({zoom_w}x{zoom_h} px)")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(zoom_in)
plt.title(f"Hasil Zoom {zoom_factor}x\n({zoom_in.shape[1]}x{zoom_in.shape[0]} px)")
plt.axis('off')

plt.suptitle("TUGAS 2: Efek Zoom In via Crop + Interpolasi INTER_LANCZOS4", fontsize=14)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Apa yang terjadi pada kualitas gambar setelah di-zoom?")
print("Jawab: Kualitas sedikit menurun (agak buram) karena keterbatasan data piksel asli.")
print("Analisis:")
print("  - Saat diperbesar 3x, setiap 1 piksel asli harus diregangkan menjadi 9 piksel baru.")
print("  - INTER_LANCZOS4 menyisipkan piksel baru dengan kurva transisi paling halus,")
print("    namun tetap tidak bisa memunculkan detail frekuensi tinggi yang tidak ada")
print("    di data sensor kamera aslinya. Hasilnya terlihat smooth namun sedikit blur.")

# ============================================
# TUGAS 3: Efek Collage Foto dengan Rotasi
# ============================================
print("\n[TUGAS 3] Efek Collage Foto (4 Variasi Rotasi)")

# Buat 4 variasi orientasi menggunakan cv2.rotate()
rotasi_0   = citra_rgb
rotasi_90  = cv2.rotate(citra_rgb, cv2.ROTATE_90_CLOCKWISE)
rotasi_180 = cv2.rotate(citra_rgb, cv2.ROTATE_180)
rotasi_270 = cv2.rotate(citra_rgb, cv2.ROTATE_90_COUNTERCLOCKWISE)

# Resize semua ke ukuran seragam 150x150 agar bisa di-stack
h_small, w_small = 150, 150
r0   = cv2.resize(rotasi_0,   (w_small, h_small))
r90  = cv2.resize(rotasi_90,  (w_small, h_small))
r180 = cv2.resize(rotasi_180, (w_small, h_small))
r270 = cv2.resize(rotasi_270, (w_small, h_small))

# Susun grid 2x2 dengan hstack dan vstack
baris1  = np.hstack([r0,   r90])    # baris atas: 0° dan 90°
baris2  = np.hstack([r180, r270])   # baris bawah: 180° dan 270°
collage = np.vstack([baris1, baris2])

plt.figure(figsize=(8, 8))
plt.imshow(collage)
plt.title("Collage 2x2: Rotasi 0° | 90° | 180° | 270°", fontsize=13)
plt.axis('off')
plt.suptitle("TUGAS 3: Grid Collage Foto dengan 4 Variasi Rotasi cv2.rotate()", fontsize=14)
plt.tight_layout()
plt.show()

print("\nPertanyaan: Apa perbedaan cv2.rotate() dengan cv2.getRotationMatrix2D()?")
print("Jawab: cv2.rotate() lebih cepat namun terbatas pada 90/180/270 derajat saja.")
print("Analisis:")
print("  - cv2.rotate() bekerja dengan membalik/menukar sumbu dimensi matriks array")
print("    secara langsung tanpa interpolasi, sehingga sangat cepat dan tanpa loss piksel.")
print("  - cv2.getRotationMatrix2D() menghasilkan matriks Affine untuk sudut bebas")
print("    (misalnya 20°, 45°, 73°) dengan interpolasi bilinear, namun lebih lambat")
print("    dan bisa menghasilkan area hitam di sudut karena canvas tidak ikut berputar.")

# ============================================
# TUGAS 4: Transformasi Perspektif & Ekspor
# ============================================
print("\n[TUGAS 4] Simpan Hasil Transformasi Perspektif Terbaik")

# Definisikan 4 titik sumber (sudut normal) dan 4 titik tujuan (efek 3D artistik)
pts_normal   = np.float32([[0, 0], [w, 0], [0, h], [w, h]])
pts_artistik = np.float32([
    [30,      50     ],   # sudut kiri atas sedikit bergeser
    [w - 40,  30     ],   # sudut kanan atas
    [10,      h - 60 ],   # sudut kiri bawah
    [w - 20,  h - 40 ]    # sudut kanan bawah
])

# Hitung matriks perspektif dan terapkan
M_perspektif  = cv2.getPerspectiveTransform(pts_normal, pts_artistik)
hasil_artistik = cv2.warpPerspective(citra_rgb, M_perspektif, (w, h))

# Buat folder output dan ekspor hasil
folder_output = 'hasil_output'
os.makedirs(folder_output, exist_ok=True)

path_simpan = os.path.join(folder_output, 'modul7_hasil_transformasi.jpg')
cv2.imwrite(path_simpan, cv2.cvtColor(hasil_artistik, cv2.COLOR_RGB2BGR))
print(f"Berhasil! Transformasi perspektif disimpan di: {path_simpan}")

plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.imshow(citra_rgb)
plt.title("Original")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(hasil_artistik)
plt.title("Hasil Transformasi Perspektif Artistik 3D")
plt.axis('off')

plt.suptitle("TUGAS 4: Ekspor Hasil Transformasi Perspektif (getPerspectiveTransform)", fontsize=14)
plt.tight_layout()
plt.show()

# ============================================
# RINGKASAN MODUL 7
# ============================================
print("\n" + "=" * 50)
print("RINGKASAN MODUL 7")
print("=" * 50)
print("\nKompetensi yang Sudah Dipelajari:")
print("1. Translasi   : Geser posisi piksel via delta dx dan dy di matriks Affine.")
print("2. Rotasi      : Putar koordinat piksel via matriks trigonometri getRotationMatrix2D.")
print("3. Scaling     : Ubah resolusi spasial dengan berbagai mode interpolasi.")
print("4. Affine      : Gabungan Rotasi + Scale + Shear + Translasi dalam 1 matriks 2x3.")
print("5. Perspektif  : Proyeksi sudut pandang 3D menggunakan matriks homogen 3x3.")

print("\nCheat-Sheet Pemilihan Fungsi Transformasi:")
print("  Geser posisi objek              --> np.float32 + cv2.warpAffine()")
print("  Rotasi sudut bebas + scale      --> cv2.getRotationMatrix2D() + warpAffine()")
print("  Rotasi cepat 90/180/270 derajat --> cv2.rotate()")
print("  Perbesar/perkecil gambar        --> cv2.resize() + pilih interpolasi")
print("  Efek distorsi 3D / scan dokumen --> cv2.getPerspectiveTransform() + warpPerspective()")

print("\nMODUL 7 SELESAI!")