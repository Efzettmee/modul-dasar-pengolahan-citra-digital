import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 7: TRANSLASI (MENGGESER GAMBAR)
# ============================================
print("=" * 50)
print("MODUL 7: TRANSLASI - MENGGESER GAMBAR")
print("=" * 50)

# Baca gambar menggunakan Smart Path (Membuat foto saya.jpg)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
h, w = citra_rgb.shape[:2]
print(f"Dimensi gambar asli: {h} x {w}")

# ============================================
# KONSEP TRANSLASI
# ============================================
print("\n[KONSEP TRANSLASI]")
print("-" * 40)
print("Translasi = memindahkan setiap piksel gambar ke posisi baru")
print("Rumus matriks: [x', y'] = [x, y] + [dx, dy]")
print("\nMatriks transformasi Translasi 2x3 Affine:")
print("[[1, 0, dx],")
print(" [0, 1, dy]]")

# ============================================
# BERBAGAI JENIS TRANSLASI
# ============================================
print("\n[MEMBUAT MATRIKS TRANSLASI]")

# Translasi ke kanan 50 piksel (dx = 50, dy = 0)
M_kanan = np.float32([[1, 0, 50], [0, 1, 0]])
print("\nGeser kanan 50 piksel Matriks:")
print(M_kanan)

# Translasi ke kiri 50 piksel (dx = -50, dy = 0)
M_kiri = np.float32([[1, 0, -50], [0, 1, 0]])
print("\nGeser kiri 50 piksel Matriks:")
print(M_kiri)

# Translasi ke bawah 50 piksel (dx = 0, dy = 50)
M_bawah = np.float32([[1, 0, 0], [0, 1, 50]])
print("\nGeser bawah 50 piksel Matriks:")
print(M_bawah)

# Translasi ke kanan bawah (dx = 50, dy = 50)
M_kanan_bawah = np.float32([[1, 0, 50], [0, 1, 50]])

# ============================================
# APLIKASIKAN TRANSLASI
# ============================================
print("\n[MENERAPKAN TRANSLASI DENGAN WARPAFFINE]")
# cv2.warpAffine(src, M, dsize) menerima matriks float32 2x3
geser_kanan = cv2.warpAffine(citra_rgb, M_kanan, (w, h))
geser_kiri = cv2.warpAffine(citra_rgb, M_kiri, (w, h))
geser_bawah = cv2.warpAffine(citra_rgb, M_bawah, (w, h))
geser_kanan_bawah = cv2.warpAffine(citra_rgb, M_kanan_bawah, (w, h))

# ============================================
# TRANSLASI DENGAN UKURAN OUTPUT YANG DIPERBESAR
# ============================================
print("\n[TRANSLASI DENGAN OUTPUT DIPERBESAR]")
# Perbesar ukuran kanvas output (dsize) agar gambar tidak terpotong terbuang
w_baru = w + 100
h_baru = h + 100
M_perbesar = np.float32([[1, 0, 50], [0, 1, 50]])
geser_dengan_padding = cv2.warpAffine(citra_rgb, M_perbesar, (w_baru, h_baru))

# ============================================
# TAMPILKAN HASIL UTAMA (Jendela 1)
# ============================================
plt.figure(figsize=(15, 12))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("1. Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(geser_kanan)
plt.title("2. Geser Kanan 50px\n(Sisi kiri kosong/hitam)")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(geser_kiri)
plt.title("3. Geser Kiri 50px\n(Sisi kiri terpotong)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(geser_bawah)
plt.title("4. Geser Bawah 50px")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(geser_kanan_bawah)
plt.title("5. Geser Kanan+Bawah 50px")
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(geser_dengan_padding)
plt.title("6. Geser + Padding Kanvas\n(Ukuran output diperbesar)")
plt.axis('off')

plt.suptitle("Translasi Spasial: Menggeser Koordinat Posisi Gambar", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# EKSPERIMEN DENGAN NILAI BERBEDA (Jendela 2)
# ============================================
print("\n[EKSPERIMEN: GESER DENGAN NILAI BERBEDA]")
nilai_geser = [(0, 0), (30, 30), (80, 20), (-50, 100), (100, -30)]

plt.figure(figsize=(15, 8))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("Original (0,0)")
plt.axis('off')

# Iterasi otomatis untuk menampilkan sisa variasi nilai pergeseran dx dan dy
for i, (dx, dy) in enumerate(nilai_geser[1:], 2):
    M = np.float32([[1, 0, dx], [0, 1, dy]])
    hasil = cv2.warpAffine(citra_rgb, M, (w, h))
    plt.subplot(2, 3, i)
    plt.imshow(hasil)
    plt.title(f"Geser (dx={dx}, dy={dy})")
    plt.axis('off')

plt.suptitle("Eksperimen Morfologi Geometri: Berbagai Kombinasi Nilai Translasi", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN OPERASI TRANSLASI]")
print("-" * 40)
print("✅ dx bernilai positif = Gambar bergeser ke KANAN.")
print("✅ dx bernilai negatif = Gambar bergeser ke KIRI.")
print("✅ dy bernilai positif = Gambar bergeser ke BAWAH.")
print("✅ dy bernilai negatif = Gambar bergeser ke ATAS.")
print("✅ Area kosong baru hasil pergeseran secara default diisi warna HITAM (0).")
print("✅ Piksel objek yang terdorong keluar batas dimensi frame akan terpotong (hilang).")
print("✅ Solusi anti-potong: Naikkan resolusi dimensi target (dsize) pada parameter warpAffine.")
print("\n✅ Modul 7 - Bagian 1 selesai!")