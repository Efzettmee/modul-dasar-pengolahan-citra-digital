import cv2
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# MODUL 7: PERSPECTIVE TRANSFORMATION
# ============================================
print("=" * 50)
print("MODUL 7: PERSPECTIVE TRANSFORMATION")
print("=" * 50)

# Baca gambar menggunakan Smart Path (Memuat foto saya.jpg)
citra_bgr = cv2.imread('images/saya.jpg')
if citra_bgr is None:
    citra_bgr = cv2.imread('../images/saya.jpg')

if citra_bgr is None:
    print("Membuat gambar dummy...")
    citra_bgr = np.random.randint(0, 255, (400, 400, 3), dtype=np.uint8)

citra_rgb = cv2.cvtColor(citra_bgr, cv2.COLOR_BGR2RGB)
h, w = citra_rgb.shape[:2]
print(f"Dimensi gambar asli: {h} x {w}")

# ============================================
# KONSEP PERSPECTIVE TRANSFORMATION
# ============================================
print("\n[KONSEP PERSPECTIVE TRANSFORMATION]")
print("-" * 40)
print("Perspective = mengubah sudut pandang proyeksi ruang (3D ke 2D)")
print("Metode: Memetakan 4 titik sudut input ke 4 titik sudut output")
print("Sifat mutlak: Garis lurus tetap lurus (tapi tidak harus sejajar)")

# ============================================
# PERSPECTIVE UNTUK KOREKSI DOKUMEN
# ============================================
print("\n[PERSPECTIVE: KOREKSI DOKUMEN MIRING]")
# Tentukan 4 titik sudut acak dokumen yang tampak miring pada gambar input
pts1 = np.float32([[50, 100], [300, 80], [30, 350], [350, 370]])

# Tentukan 4 titik tujuan mendatar (persegi panjang normal rata air)
w_doc = 300
h_doc = 250
pts2 = np.float32([[0, 0], [w_doc, 0], [0, h_doc], [w_doc, h_doc]])

# Dapatkan matriks perspektif homogen 3x3
M_doc = cv2.getPerspectiveTransform(pts1, pts2)

# Terapkan transformasi dengan cv2.warpPerspective
perspective_doc = cv2.warpPerspective(citra_rgb, M_doc, (w_doc, h_doc))

# ============================================
# VISUALISASI TITIK-2 INPUT/OUTPUT
# ============================================
print("\n[VISUALISASI TRANSFORMASI]")
# Gambar lingkaran titik penanda pada citra asli untuk visualisasi letak koordinat pts1
citra_dengan_titik = citra_rgb.copy()
for (x, y) in pts1.astype(int):
    cv2.circle(citra_dengan_titik, (x, y), 8, (255, 0, 0), -1)

# ============================================
# PERSPECTIVE UNTUK EFEK "FLYING"
# ============================================
print("\n[PERSPECTIVE: EFEK FLYING/LAYANG-LAYANG]")
# Ambil 4 koordinat ujung bingkai normal gambar asli
pts1_normal = np.float32([[0, 0], [w, 0], [0, h], [w, h]])

# Tarik ujung koordinat tujuan untuk membuat efek distorsi 3D menjauh/melayang
pts_flying = np.float32([[50, 50], [w - 80, 80], [0, h - 50], [w - 50, h - 100]])
M_flying = cv2.getPerspectiveTransform(pts1_normal, pts_flying)
flying = cv2.warpPerspective(citra_rgb, M_flying, (w, h))

# ============================================
# PERSPECTIVE UNTUK EFEK "CURVED" (SEDERHANA)
# ============================================
print("\n[PERSPECTIVE: EFEK PERSPECTIVE LANJUTAN]")
# Menguncupkan bagian bawah gambar untuk mensimulasikan efek lengkung/sudut kamera bawah
pts_curved = np.float32([[0, 0], [w, 0], [50, h], [w - 50, h]])
M_curved = cv2.getPerspectiveTransform(pts1_normal, pts_curved)
curved = cv2.warpPerspective(citra_rgb, M_curved, (w, h))

# ============================================
# TAMPILKAN HASIL UTAMA (Jendela 1)
# ============================================
plt.figure(figsize=(15, 12))

plt.subplot(2, 3, 1)
plt.imshow(citra_rgb)
plt.title("1. Original")
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(citra_dengan_titik)
plt.title("2. Original dengan 4 Titik Referensi")
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(perspective_doc)
plt.title("3. Hasil Koreksi Perspektif\n(Dokumen Rata Tegak)")
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(flying)
plt.title("4. Efek Flying (Melayang 3D)")
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(curved)
plt.title("5. Efek Curved (Trapesium Kuncup)")
plt.axis('off')

plt.suptitle("Perspective Transformation: Simulasi Manipulasi Sudut Pandang 3D", fontsize=16)
plt.tight_layout()
plt.show()

# ============================================
# DEMO: KOREKSI GAMBAR MIRING (SIMULASI - Jendela 2)
# ============================================
print("\n[DEMO: KOREKSI GAMBAR MIRING SIMULASI]")
# Langkah A: Buat gambar yang dimiringkan secara sengaja (Simulasi jepretan kamera rusak)
M_simulate = cv2.getPerspectiveTransform(pts1_normal, pts1)
simulasi_miring = cv2.warpPerspective(citra_rgb, M_simulate, (w, h))

# Langkah B: Hitung balik matriks inversi untuk meluruskan kembali citra miring tersebut
M_correct = cv2.getPerspectiveTransform(pts1, pts1_normal)
terkoreksi = cv2.warpPerspective(simulasi_miring, M_correct, (w, h))

plt.figure(figsize=(15, 8))

plt.subplot(1, 3, 1)
plt.imshow(citra_rgb)
plt.title("A. Original (Normal)")
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(simulasi_miring)
plt.title("B. Hasil Simulasi Kamera Miring")
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(terkoreksi)
plt.title("C. Hasil Scan Pemulihan Perspektif\n(Kembali Normal & Lurus!)")
plt.axis('off')

plt.suptitle("Aplikasi Nyata PCD: Algoritma Pelurusan Scan Dokumen Otomatis", fontsize=16)
plt.tight_layout()
plt.show()

print("\n[KESIMPULAN EVALUASI PERSPEKTIF]")
print("-" * 45)
print("✅ Transformasi Perspektif memanipulasi kedalaman proyeksi visual gambar biner.")
print("✅ Operasi ini membutuhkan minimal 4 titik jangkar (Quadrilateral) yang tidak boleh segaris.")
print("✅ Matriks transformasi berbentuk koordinat homogen berukuran 3x3.")
print("✅ Sangat vital untuk aplikasi industri seperti CamScanner, OCR, Augmented Reality, dan Scan QR Code.")
print("\n✅ Modul 7 - Seluruh Materi Transformasi Geometri Selesai!")